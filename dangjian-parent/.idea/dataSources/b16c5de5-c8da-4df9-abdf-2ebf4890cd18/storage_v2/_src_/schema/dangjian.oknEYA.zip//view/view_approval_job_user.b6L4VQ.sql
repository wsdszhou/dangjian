create view view_approval_job_user as
  select `gw`.`spgw_id`       AS `spgw_id`,
         `gw`.`spgw_spgwmc`   AS `spgw_spgwmc`,
         `ry`.`spry_id`       AS `spry_id`,
         `yh`.`user_mc`       AS `user_mc`,
         `xx`.`yhxx_xm`       AS `yhxx_xm`,
         `yh`.`user_id`       AS `user_id`,
         `bm`.`bm_id`         AS `bm_id`,
         `bm`.`bm_mc`         AS `bm_mc`,
         `jd`.`spjd_id`       AS `spjd_id`,
         `jd`.`spjd_mc`       AS `spjd_mc`,
         `jd`.`spjd_dqspzt`   AS `spjd_dqspzt`,
         `jd`.`spjd_xyspjddm` AS `spjd_xyspjdId`,
         `jd`.`spjd_xyjdmc`   AS `spjd_xyjdmc`
  from (((((`dangjian`.`sp_spgwb` `gw` join `dangjian`.`sp_ryb` `ry`) join `dangjian`.`yhb` `yh`) join `dangjian`.`yh_xxb` `xx`) join `dangjian`.`bmb` `bm`) join `dangjian`.`sp_spjdb` `jd`)
  where ((`ry`.`spry_spgwdm` = `gw`.`spgw_id`) and (`jd`.`spjd_gwdm` = `gw`.`spgw_id`) and
         (`ry`.`spry_bmdm` = `bm`.`bm_id`) and (`ry`.`spry_yh` = `yh`.`user_id`) and
         (`yh`.`user_yhxxdm` = `xx`.`yhxx_id`));


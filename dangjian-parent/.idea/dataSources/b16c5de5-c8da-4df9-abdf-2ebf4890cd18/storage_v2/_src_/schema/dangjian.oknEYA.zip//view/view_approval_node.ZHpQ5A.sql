create view view_approval_node as
  select `jd`.`spjd_id`       AS `spjd_id`,
         `jd`.`spjd_mc`       AS `spjd_mc`,
         `jd`.`spjd_dqspzt`   AS `spjd_dqspzt`,
         `jd`.`spjd_xyspjddm` AS `spjd_xyspjdId`,
         `jd`.`spjd_xyjdmc`   AS `spjd_xyjdmc`,
         `jd`.`spjd_isFirst`  AS `spjd_isFirst`,
         `lc`.`splc_id`       AS `splc_id`,
         `lc`.`splc_state`    AS `splc_state`,
         `lc`.`splc_mc`       AS `splc_mc`,
         `lc`.`splc_ywdm`     AS `splc_ywdm`,
         `gw`.`spgw_id`       AS `spgw_id`,
         `gw`.`spgw_spgwmc`   AS `spgw_spgwmc`
  from ((`dangjian`.`sp_spjdb` `jd` join `dangjian`.`sp_splcb` `lc`) join `dangjian`.`sp_spgwb` `gw`)
  where ((`jd`.`spjd_lcdm` = `lc`.`splc_id`) and (`jd`.`spjd_gwdm` = `gw`.`spgw_id`));


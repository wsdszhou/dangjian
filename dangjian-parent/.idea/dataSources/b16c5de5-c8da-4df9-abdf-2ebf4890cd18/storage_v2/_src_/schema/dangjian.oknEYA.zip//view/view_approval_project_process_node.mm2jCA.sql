create view view_approval_project_process_node as
  select `xm`.`lcxm_id`       AS `lcxm_id`,
         `xm`.`lcxm_mc`       AS `lcxm_mc`,
         `xm`.`lcxm_xmms`     AS `lcxm_xmms`,
         `xm`.`lcxm_dqspzt`   AS `lcxm_dqspzt`,
         `xm`.`lcxm_resulte`  AS `lcxm_resulte`,
         `xm`.`lcxm_xgsj`     AS `lcxm_xgsj`,
         `xm`.`lcxm_dxId`     AS `lcxm_dxId`,
         `jd`.`spjd_id`       AS `spjd_id`,
         `jd`.`spjd_mc`       AS `spjd_mc`,
         `jd`.`spjd_dqspzt`   AS `spjd_dqspzt`,
         `jd`.`spjd_xyspjddm` AS `spjd_xyspjddm`,
         `jd`.`spjd_xyjdmc`   AS `spjd_xyjdmc`,
         `jd`.`spjd_isFirst`  AS `spjd_isFirst`,
         `lc`.`splc_id`       AS `splc_id`,
         `lc`.`splc_mc`       AS `splc_mc`,
         `lc`.`splc_state`    AS `splc_state`,
         `lc`.`splc_ywdm`     AS `splc_ywdm`,
         `gw`.`spgw_id`       AS `spgw_id`,
         `gw`.`spgw_spgwmc`   AS `spgw_spgwmc`
  from (((`dangjian`.`sp_lcxmb` `xm` join `dangjian`.`sp_spjdb` `jd`) join `dangjian`.`sp_splcb` `lc`) join `dangjian`.`sp_spgwb` `gw`)
  where ((`xm`.`lcxm_splcdm` = `lc`.`splc_id`) and (`xm`.`lcxm_dqjddm` = `jd`.`spjd_id`) and
         (`jd`.`spjd_gwdm` = `gw`.`spgw_id`));


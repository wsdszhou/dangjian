create view view_branch as
select `zb`.`zb_id`                  AS `zb_id`,
       `zb`.`zb_mc`                  AS `zb_mc`,
       `zb`.`zb_ms`                  AS `zb_ms`,
       `zb`.`zb_xgsj`                AS `zb_xgsj`,
       `dangjian`.`bmb`.`bm_id`      AS `bm_id`,
       `dangjian`.`bmb`.`bm_mc`      AS `bm_mc`,
       `dangjian`.`zb_lxb`.`zblx_id` AS `zblx_id`,
       `dangjian`.`zb_lxb`.`zblx_mc` AS `zblx_mc`,
       `yhxx1`.`user_id`             AS `sjId`,
       `yhxx1`.`yhxx_xm`             AS `sjXm`,
       `yhxx2`.`user_id`             AS `zzwyId`,
       `yhxx2`.`yhxx_xm`             AS `zzwyXm`,
       `yhxx3`.`user_id`             AS `xcwyId`,
       `yhxx3`.`yhxx_xm`             AS `xcwyXm`
from (((((`dangjian`.`zbb` `zb` left join `dangjian`.`view_yhxx` `yhxx1` on ((`zb`.`zb_sj` = `yhxx1`.`user_id`))) left join `dangjian`.`view_yhxx` `yhxx2` on ((`zb`.`zb_zzwy` = `yhxx2`.`user_id`))) left join `dangjian`.`view_yhxx` `yhxx3` on ((`zb`.`zb_xcwy` = `yhxx3`.`user_id`))) left join `dangjian`.`bmb` on ((`zb`.`zb_ssbmdm` = `dangjian`.`bmb`.`bm_id`)))
       left join `dangjian`.`zb_lxb` on ((`zb`.`zb_lxdm` = `dangjian`.`zb_lxb`.`zblx_id`)));


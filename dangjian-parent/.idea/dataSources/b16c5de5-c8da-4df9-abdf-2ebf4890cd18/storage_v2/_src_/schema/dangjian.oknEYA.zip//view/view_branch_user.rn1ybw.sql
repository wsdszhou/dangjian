create view view_branch_user as
select `dangjian`.`yhb`.`user_id`      AS `user_id`,
       `dangjian`.`yhb`.`user_mc`      AS `user_mc`,
       `dangjian`.`yh_xxb`.`yhxx_xm`   AS `yhxx_xm`,
       `dangjian`.`yh_xxb`.`yhxx_xb`   AS `yhxx_xb`,
       `dangjian`.`yh_xxb`.`yhxx_csrq` AS `yhxx_csrq`,
       `dangjian`.`dnzwb`.`dnzw_id`    AS `dnzw_id`,
       `dangjian`.`dnzwb`.`dnzw_mc`    AS `dnzw_mc`,
       `dangjian`.`dnzwb`.`dnzw_jb`    AS `dnzw_jb`,
       `dangjian`.`xzzwb`.`xzzw_id`    AS `xzzw_id`,
       `dangjian`.`xzzwb`.`xzzw_mc`    AS `xzzw_mc`,
       `dangjian`.`xzzwb`.`xzzw_jb`    AS `xzzw_jb`,
       `dangjian`.`zbb`.`zb_id`        AS `zb_id`,
       `dangjian`.`zbb`.`zb_mc`        AS `zb_mc`,
       `dangjian`.`zbb`.`zb_ms`        AS `zb_ms`,
       `dangjian`.`zb_lxb`.`zblx_id`   AS `zblx_id`,
       `dangjian`.`zb_lxb`.`zblx_mc`   AS `zblx_mc`,
       `dangjian`.`bmb`.`bm_id`        AS `bm_id`,
       `dangjian`.`bmb`.`bm_mc`        AS `bm_mc`
from `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`dnzwb`
       join `dangjian`.`xzzwb`
       join `dangjian`.`zbb`
       join `dangjian`.`zb_lxb`
       join `dangjian`.`bmb`
where ((`dangjian`.`yh_xxb`.`yhxx_id` = `dangjian`.`yhb`.`user_yhxxdm`) and
       (`dangjian`.`yh_xxb`.`yhxx_dnzwdm` = `dangjian`.`dnzwb`.`dnzw_id`) and
       (`dangjian`.`yh_xxb`.`yhxx_xzzwdm` = `dangjian`.`xzzwb`.`xzzw_id`) and
       (`dangjian`.`yh_xxb`.`yhxx_zbdm` = `dangjian`.`zbb`.`zb_id`) and
       (`dangjian`.`yh_xxb`.`yhxx_bmdm` = `dangjian`.`bmb`.`bm_id`) and
       (`dangjian`.`zbb`.`zb_lxdm` = `dangjian`.`zb_lxb`.`zblx_id`));


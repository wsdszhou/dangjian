create view view_bug as
select `dangjian`.`bug`.`id`         AS `id`,
       `dangjian`.`bug`.`bt`         AS `bt`,
       `dangjian`.`bug`.`sj`         AS `sj`,
       `dangjian`.`bug`.`sfyd`       AS `sfyd`,
       `dangjian`.`bug`.`yhdm`       AS `yhdm`,
       `dangjian`.`bug`.`nr`         AS `nr`,
       `dangjian`.`yhb`.`user_id`    AS `user_id`,
       `dangjian`.`yhb`.`user_mc`    AS `user_mc`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `yhxx_xm`
from `dangjian`.`bug`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
where ((`dangjian`.`bug`.`yhdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


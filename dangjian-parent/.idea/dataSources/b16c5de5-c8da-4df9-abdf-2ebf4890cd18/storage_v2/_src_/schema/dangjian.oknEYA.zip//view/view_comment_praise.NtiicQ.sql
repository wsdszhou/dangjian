create view view_comment_praise as
select `pl`.`id`                       AS `pl_id`,
       `pl`.`zw`                       AS `pl_zw`,
       `pl`.`sj`                       AS `pl_sj`,
       `pl`.`flag`                     AS `pl_flag`,
       `pl`.`xwdm`                     AS `pl_xwdm`,
       `pl`.`yhdm`                     AS `pl_yhdm`,
       `dangjian`.`xw_pldzb`.`pldz_id` AS `pldz_id`,
       `dangjian`.`yhb`.`user_id`      AS `pldz_userId`,
       `dangjian`.`yh_xxb`.`yhxx_xm`   AS `pldz_userName`
from `dangjian`.`xw_plb` `pl`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`xw_pldzb`
where ((`dangjian`.`xw_pldzb`.`pldz_pldm` = `pl`.`id`) and
       (`dangjian`.`xw_pldzb`.`pldz_yhdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


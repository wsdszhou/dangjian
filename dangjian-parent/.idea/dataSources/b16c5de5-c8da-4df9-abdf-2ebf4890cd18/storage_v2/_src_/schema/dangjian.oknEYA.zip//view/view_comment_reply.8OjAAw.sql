create view view_comment_reply as
select `pl`.`id`                     AS `pl_id`,
       `pl`.`zw`                     AS `pl_zw`,
       `pl`.`sj`                     AS `pl_sj`,
       `pl`.`flag`                   AS `pl_flag`,
       `pl`.`xwdm`                   AS `pl_xwdm`,
       `pl`.`yhdm`                   AS `pl_yhdm`,
       `hf`.`id`                     AS `hf_id`,
       `hf`.`reply_id`               AS `hf_reply_id`,
       `hf`.`reply_type`             AS `hf_reply_type`,
       `hf`.`nr`                     AS `hf_nr`,
       `hf`.`mb_yh_id`               AS `hf_mb_yh_id`,
       `hf`.`sj`                     AS `hf_sj`,
       `hf`.`flag`                   AS `hf_flag`,
       `dangjian`.`yhb`.`user_id`    AS `hf_userId`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `hf_userName`
from `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`xw_plb` `pl`
       join `dangjian`.`xw_pl_hf` `hf`
where ((`hf`.`pldm` = `pl`.`id`) and (`hf`.`hf_yhdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


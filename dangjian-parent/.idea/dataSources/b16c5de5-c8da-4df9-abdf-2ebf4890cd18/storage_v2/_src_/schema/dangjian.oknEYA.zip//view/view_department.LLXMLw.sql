create view view_department as
select distinct `bm`.`bm_id`    AS `bm_id`,
                `bm`.`bm_mc`    AS `bm_mc`,
                `bm`.`bm_js`    AS `bm_js`,
                `bm`.`bm_cjsj`  AS `bm_cjsj`,
                `bm`.`bm_xgsj`  AS `bm_xgsj`,
                `bm`.`bm_logo`  AS `bm_logo`,
                `yh1`.`user_id` AS `secretaryId`,
                `xx1`.`yhxx_xm` AS `secretaryName`,
                `yh2`.`user_id` AS `deanId`,
                `xx2`.`yhxx_xm` AS `deanName`
from `dangjian`.`bmb` `bm`
       join `dangjian`.`yhb` `yh1`
       join `dangjian`.`yh_xxb` `xx1`
       join `dangjian`.`yhb` `yh2`
       join `dangjian`.`yh_xxb` `xx2`
where ((`bm`.`bm_sj` = `yh1`.`user_id`) and (`bm`.`bm_yz` = `yh2`.`user_id`) and
       (`yh1`.`user_yhxxdm` = `xx1`.`yhxx_id`) and (`yh2`.`user_yhxxdm` = `xx2`.`yhxx_id`));


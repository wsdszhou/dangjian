create view view_dues_college_branch as
  select `dangjian`.`dues_college`.`college_id` AS `college_id`,
         `dangjian`.`dues_branch`.`branch_id`   AS `branch_id`,
         `dangjian`.`dues_branch`.`branch_name` AS `branch_name`,
         `dangjian`.`dues_branch`.`branch_num`  AS `branch_num`,
         `dangjian`.`dues_branch`.`branch_rate` AS `branch_rate`
  from `dangjian`.`dues_college`
         join `dangjian`.`dues_branch`;


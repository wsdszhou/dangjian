create view view_dues_list as
  select `dangjian`.`yh_xxb`.`yhxx_xm`            AS `yhxx_xm`,
         `dangjian`.`dues_branch`.`branch_name`   AS `branch_name`,
         `dangjian`.`dues_college`.`college_name` AS `college_name`,
         `dangjian`.`dues_list`.`list_id`         AS `list_id`,
         `dangjian`.`dues_list`.`dues_time`       AS `dues_time`,
         `dangjian`.`dues_list`.`dues_person`     AS `dues_person`,
         `dangjian`.`dues_list`.`dues_status`     AS `dues_status`,
         `dangjian`.`dues_list`.`dues_anount`     AS `dues_anount`,
         `dangjian`.`dues_list`.`dues_month`      AS `dues_month`,
         `dangjian`.`dues_list`.`yhxx_id`         AS `yhxx_id`,
         `dangjian`.`dues_list`.`branch_id`       AS `branch_id`,
         `dangjian`.`dues_list`.`college_id`      AS `college_id`
  from `dangjian`.`yh_xxb`
         join `dangjian`.`dues_branch`
         join `dangjian`.`dues_college`
         join `dangjian`.`dues_list`
  where ((`dangjian`.`yh_xxb`.`yhxx_id` = `dangjian`.`dues_list`.`yhxx_id`) and
         (`dangjian`.`dues_branch`.`branch_id` = `dangjian`.`dues_list`.`branch_id`) and
         (`dangjian`.`dues_college`.`college_id` = `dangjian`.`dues_list`.`college_id`));


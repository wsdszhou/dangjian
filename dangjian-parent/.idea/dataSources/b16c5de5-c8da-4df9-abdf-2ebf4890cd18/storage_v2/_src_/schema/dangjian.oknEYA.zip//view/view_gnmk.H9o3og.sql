create view view_gnmk as
select `b`.`mk_id`   AS `mk_id`,
       `b`.`mk_mc`   AS `mk_mc`,
       `b`.`mk_url`  AS `mk_url`,
       `b`.`mk_icon` AS `mk_icon`,
       `a`.`gn_id`   AS `gn_id`,
       `a`.`gn_mc`   AS `gn_mc`,
       `a`.`gn_icon` AS `gn_icon`
from (`dangjian`.`gnb` `a`
       left join `dangjian`.`mkb` `b` on ((`a`.`gn_id` = `b`.`gnb`)));


create view view_job_user as
select `dangjian`.`sp_spgwb`.`spgw_id`     AS `spgw_id`,
       `dangjian`.`sp_spgwb`.`spgw_spgwmc` AS `spgw_spgwmc`,
       `ry`.`spry_id`                      AS `spry_id`,
       `dangjian`.`yhb`.`user_id`          AS `user_id`,
       `dangjian`.`yhb`.`user_mc`          AS `user_mc`,
       `dangjian`.`yh_xxb`.`yhxx_xm`       AS `yhxx_xm`,
       `dangjian`.`bmb`.`bm_id`            AS `bm_id`,
       `dangjian`.`bmb`.`bm_mc`            AS `bm_mc`
from `dangjian`.`sp_ryb` `ry`
       join `dangjian`.`sp_spgwb`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`bmb`
where ((`ry`.`spry_bmdm` = `dangjian`.`bmb`.`bm_id`) and (`ry`.`spry_spgwdm` = `dangjian`.`sp_spgwb`.`spgw_id`) and
       (`ry`.`spry_yh` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


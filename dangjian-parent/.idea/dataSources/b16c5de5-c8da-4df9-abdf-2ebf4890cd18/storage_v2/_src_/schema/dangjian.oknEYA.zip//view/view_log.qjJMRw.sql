create view view_log as
select `l`.`id`                   AS `id`,
       `l`.`login_ip`             AS `login_ip`,
       `l`.`type`                 AS `type`,
       `l`.`operation`            AS `operation`,
       `l`.`create_time`          AS `create_time`,
       `l`.`remark`               AS `remark`,
       `dangjian`.`yhb`.`user_id` AS `user_id`,
       `dangjian`.`yhb`.`user_mc` AS `user_mc`,
       `xx`.`yhxx_id`             AS `yhxx_id`,
       `xx`.`yhxx_xm`             AS `yhxx_xm`
from `dangjian`.`log` `l`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb` `xx`
where ((`l`.`yhdm` = `dangjian`.`yhb`.`user_id`) and (`dangjian`.`yhb`.`user_yhxxdm` = `xx`.`yhxx_id`));


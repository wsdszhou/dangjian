create view view_myself_notice as
select `tz`.`tz_id`        AS `tz_id`,
       `tz`.`tz_bt`        AS `tz_bt`,
       `tz`.`tz_nr`        AS `tz_nr`,
       `tz`.`tz_fbsj`      AS `tz_fbsj`,
       `tz`.`tz_fbrdm`     AS `tz_fbrdm`,
       `tz`.`tz_fbrmc`     AS `tz_fbrmc`,
       `tz`.`tz_jssj`      AS `tz_jssj`,
       `tz`.`tz_yxj`       AS `tz_yxj`,
       `dx`.`tzdx_id`      AS `tzdx_id`,
       `dx`.`tzdx_btzyhdm` AS `tzdx_btzyhdm`,
       `xx`.`yhxx_xm`      AS `tzdx_btzyhXm`,
       `dx`.`tzdx_sfyd`    AS `tzdx_sfyd`,
       `dx`.`tzdx_ydsj`    AS `tzdx_ydsj`,
       `bm`.`bm_id`        AS `bm_id`,
       `bm`.`bm_mc`        AS `bm_mc`,
       `fw`.`tzfw_id`      AS `tzfw_id`,
       `fw`.`tzfw_mc`      AS `tzfw_mc`,
       `xx`.`yhxx_xm`      AS `yhxx_xm`
from (((((`dangjian`.`tz_fw` `fw` join `dangjian`.`tz_tzb` `tz`) join `dangjian`.`tz_tzdxb` `dx`) join `dangjian`.`bmb` `bm`) join `dangjian`.`yhb` `yh`)
       join `dangjian`.`yh_xxb` `xx`)
where ((`tz`.`tz_fwdm` = `fw`.`tzfw_id`) and (`dx`.`tzdx_tzdm` = `tz`.`tz_id`) and
       (`dx`.`tzdx_btzyhdm` = `yh`.`user_id`) and (`yh`.`user_yhxxdm` = `xx`.`yhxx_id`));


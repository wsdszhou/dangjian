create view view_news as
select `dangjian`.`xwb`.`xw_id`      AS `xw_id`,
       `dangjian`.`xwb`.`xw_slt`     AS `xw_slt`,
       `dangjian`.`xwb`.`xw_bt`      AS `xw_bt`,
       `dangjian`.`xwb`.`xw_fbsj`    AS `xw_fbsj`,
       `dangjian`.`xwb`.`xw_zw`      AS `xw_zw`,
       `dangjian`.`xwb`.`xw_ydrs`    AS `xw_ydrs`,
       `dangjian`.`xwb`.`xw_xgsj`    AS `xw_xgsj`,
       `dangjian`.`xwb`.`xw_sfpl`    AS `xw_sfpl`,
       `dangjian`.`xwb`.`xw_splc`    AS `xw_splc`,
       `dangjian`.`yhb`.`user_id`    AS `fbr_userId`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `fbr_userName`,
       `dangjian`.`xw_ztb`.`xwzt_id` AS `xwzt_id`,
       `dangjian`.`xw_ztb`.`xwzt_mc` AS `xwzt_mc`,
       `dangjian`.`lmb`.`lm_id`      AS `lm_id`,
       `dangjian`.`lmb`.`lm_mc`      AS `lm_mc`,
       `dangjian`.`bmb`.`bm_id`      AS `bm_id`,
       `dangjian`.`bmb`.`bm_mc`      AS `bm_mc`
from (((((`dangjian`.`xwb` join `dangjian`.`yhb`) join `dangjian`.`yh_xxb`) join `dangjian`.`bmb`) join `dangjian`.`xw_ztb`)
       join `dangjian`.`lmb`)
where ((`dangjian`.`xwb`.`xw_fbrdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`) and
       (`dangjian`.`xwb`.`xw_xwztdm` = `dangjian`.`xw_ztb`.`xwzt_id`) and
       (`dangjian`.`xwb`.`xw_lmdm` = `dangjian`.`lmb`.`lm_id`) and
       (`dangjian`.`xwb`.`xw_bmdm` = `dangjian`.`bmb`.`bm_id`));


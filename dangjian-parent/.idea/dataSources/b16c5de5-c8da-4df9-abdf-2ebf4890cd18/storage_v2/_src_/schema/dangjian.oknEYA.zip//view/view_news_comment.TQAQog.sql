create view view_news_comment as
select `dangjian`.`xwb`.`xw_id`      AS `xw_id`,
       `dangjian`.`xwb`.`xw_bt`      AS `xw_bt`,
       `dangjian`.`xwb`.`xw_fbsj`    AS `xw_fbsj`,
       `dangjian`.`xwb`.`xw_zw`      AS `xw_zw`,
       `dangjian`.`xwb`.`xw_ydrs`    AS `xw_ydrs`,
       `dangjian`.`xwb`.`xw_xgsj`    AS `xw_xgsj`,
       `dangjian`.`xwb`.`xw_sfpl`    AS `xw_sfpl`,
       `dangjian`.`xwb`.`xw_splc`    AS `xw_splc`,
       `dangjian`.`xw_plb`.`id`      AS `id`,
       `dangjian`.`xw_plb`.`zw`      AS `zw`,
       `dangjian`.`xw_plb`.`sj`      AS `sj`,
       `dangjian`.`xw_plb`.`flag`    AS `flag`,
       `dangjian`.`yhb`.`user_id`    AS `pl_userId`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `pl_userName`
from `dangjian`.`xwb`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`xw_plb`
where ((`dangjian`.`xw_plb`.`xwdm` = `dangjian`.`xwb`.`xw_id`) and
       (`dangjian`.`xw_plb`.`yhdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


create view view_news_praise as
select `dangjian`.`xwb`.`xw_id`      AS `xw_id`,
       `dangjian`.`xwb`.`xw_bt`      AS `xw_bt`,
       `dangjian`.`xwb`.`xw_fbsj`    AS `xw_fbsj`,
       `dangjian`.`xwb`.`xw_zw`      AS `xw_zw`,
       `dangjian`.`xwb`.`xw_ydrs`    AS `xw_ydrs`,
       `dangjian`.`xwb`.`xw_xgsj`    AS `xw_xgsj`,
       `dangjian`.`xwb`.`xw_sfpl`    AS `xw_sfpl`,
       `dangjian`.`xwb`.`xw_splc`    AS `xw_splc`,
       `dangjian`.`xw_dzb`.`dz_id`   AS `dz_id`,
       `dangjian`.`yhb`.`user_id`    AS `dz_userId`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `dz_userName`
from `dangjian`.`xwb`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb`
       join `dangjian`.`xw_dzb`
where ((`dangjian`.`xw_dzb`.`dz_xwdm` = `dangjian`.`xwb`.`xw_id`) and
       (`dangjian`.`xw_dzb`.`dz_yhdm` = `dangjian`.`yhb`.`user_id`) and
       (`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`));


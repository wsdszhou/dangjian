create view view_notice as
select `dx`.`tzdx_id`    AS `tzdx_id`,
       `dx`.`tzdx_sfyd`  AS `tzdx_sfyd`,
       `dx`.`tzdx_ydsj`  AS `tzdx_ydsj`,
       `dx`.`tzdx_bmdm`  AS `tzdx_bmdm`,
       `dx`.`tzdx_zbdm`  AS `tzdx_zbdm`,
       `tz`.`tz_id`      AS `tz_id`,
       `tz`.`tz_bt`      AS `tz_bt`,
       `tz`.`tz_nr`      AS `tz_nr`,
       `tz`.`tz_fbsj`    AS `tz_fbsj`,
       `tz`.`tz_fbrmc`   AS `tz_fbrmc`,
       `tz`.`tz_jssj`    AS `tz_jssj`,
       `tz`.`tz_fwdm`    AS `tz_fwdm`,
       `tz`.`tz_yxj`     AS `tz_yxj`,
       `tz`.`tz_spId`    AS `tz_spId`,
       `yh1`.`user_id`   AS `btzdxId`,
       `yh1`.`user_mc`   AS `btzdxMc`,
       `yhxx1`.`yhxx_id` AS `btzdxYhxxId`,
       `yhxx1`.`yhxx_xm` AS `btzdxXm`,
       `yh2`.`user_id`   AS `fbrId`,
       `yh2`.`user_mc`   AS `fbrMc`,
       `yhxx2`.`yhxx_id` AS `fbrYhxxId`,
       `yhxx2`.`yhxx_xm` AS `fbrXm`
from `dangjian`.`tz_tzdxb` `dx`
       join `dangjian`.`tz_tzb` `tz`
       join `dangjian`.`yhb` `yh1`
       join `dangjian`.`yh_xxb` `yhxx1`
       join `dangjian`.`yhb` `yh2`
       join `dangjian`.`yh_xxb` `yhxx2`
where ((`dx`.`tzdx_tzdm` = `tz`.`tz_id`) and (`dx`.`tzdx_btzyhdm` = `yh1`.`user_id`) and
       (`yh1`.`user_yhxxdm` = `yhxx1`.`yhxx_id`) and (`tz`.`tz_fbrdm` = `yh2`.`user_id`) and
       (`yh2`.`user_yhxxdm` = `yhxx2`.`yhxx_id`));


create view view_notice_common as
select `dx`.`tzdx_id`    AS `tzdx_id`,
       `dx`.`tzdx_sfyd`  AS `tzdx_sfyd`,
       `dx`.`tzdx_ydsj`  AS `tzdx_ydsj`,
       `dx`.`tzdx_bmdm`  AS `tzdx_bmdm`,
       `dx`.`tzdx_zbdm`  AS `tzdx_zbdm`,
       `tz`.`tz_id`      AS `tz_id`,
       `tz`.`tz_bt`      AS `tz_bt`,
       `tz`.`tz_nr`      AS `tz_nr`,
       `tz`.`tz_fbsj`    AS `tz_fbsj`,
       `tz`.`tz_fbrmc`   AS `tz_fbrmc`,
       `tz`.`tz_jssj`    AS `tz_jssj`,
       `tz`.`tz_fwdm`    AS `tz_fwdm`,
       `tz`.`tz_yxj`     AS `tz_yxj`,
       `tz`.`tz_spId`    AS `tz_spId`,
       `yh2`.`user_id`   AS `fbrId`,
       `yh2`.`user_mc`   AS `fbrMc`,
       `yhxx2`.`yhxx_id` AS `fbrYhxxId`,
       `yhxx2`.`yhxx_xm` AS `fbrXm`
from `dangjian`.`tz_tzdxb` `dx`
       join `dangjian`.`tz_tzb` `tz`
       join `dangjian`.`yhb` `yh2`
       join `dangjian`.`yh_xxb` `yhxx2`
where ((`tz`.`tz_fbrdm` = `yh2`.`user_id`) and (`yh2`.`user_yhxxdm` = `yhxx2`.`yhxx_id`) and
       (`dx`.`tzdx_tzdm` = `tz`.`tz_id`) and isnull(`dx`.`tzdx_btzyhdm`));


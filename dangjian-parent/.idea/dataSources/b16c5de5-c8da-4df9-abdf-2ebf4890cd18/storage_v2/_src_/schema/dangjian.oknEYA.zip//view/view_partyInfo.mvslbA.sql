create view view_partyInfo as
select `dangjian`.`djxx`.`id`        AS `id`,
       `dangjian`.`djxx`.`sqsj`      AS `sqsj`,
       `dangjian`.`djxx`.`spsj`      AS `spsj`,
       `dangjian`.`djxx`.`rdsj`      AS `rdsj`,
       `dangjian`.`djxx`.`ms`        AS `ms`,
       `dangjian`.`djxx`.`zrsj`      AS `zrsj`,
       `dangjian`.`djxx`.`zcdd`      AS `zcdd`,
       `dangjian`.`djxx`.`zt`        AS `zt`,
       `dangjian`.`djxx`.`result`    AS `result`,
       `dangjian`.`djxx`.`bmdm`      AS `bmdm`,
       `dangjian`.`djxx`.`zbdm`      AS `zbdm`,
       `dangjian`.`djxx`.`dnzwdm`    AS `dnzwdm`,
       `dangjian`.`djxx`.`zzmmdm`    AS `zzmmdm`,
       `dangjian`.`yhb`.`user_id`    AS `user_id`,
       `dangjian`.`yhb`.`user_mc`    AS `user_mc`,
       `xx`.`yhxx_id`                AS `yhxx_id`,
       `xx`.`yhxx_xm`                AS `yhxx_xm`,
       `xx`.`yhxx_xb`                AS `yhxx_xb`,
       `xx`.`yhxx_csrq`              AS `yhxx_csrq`,
       `xx`.`yhxx_dhhm`              AS `yhxx_dhhm`,
       `xx`.`yhxx_sjh`               AS `yhxx_sjh`,
       `xx`.`yhxx_yx`                AS `yhxx_yx`,
       `xx`.`yhxx_sfzh`              AS `yhxx_sfzh`,
       `dangjian`.`xlb`.`xl_id`      AS `xl_id`,
       `dangjian`.`xlb`.`xl_mc`      AS `xl_mc`,
       `dangjian`.`zzmmb`.`zzmm_id`  AS `zzmm_id`,
       `dangjian`.`zzmmb`.`zzmm_mc`  AS `zzmm_mc`,
       `dangjian`.`jgb`.`jg_id`      AS `jg_id`,
       `dangjian`.`jgb`.`js_szqx_mc` AS `js_szqx_mc`,
       `dangjian`.`jgb`.`jg_szs_mc`  AS `jg_szs_mc`,
       `dangjian`.`mzb`.`mz_id`      AS `mz_id`,
       `dangjian`.`mzb`.`mz_mc`      AS `mz_mc`,
       `dangjian`.`dnzwb`.`dnzw_id`  AS `dnzw_id`,
       `dangjian`.`dnzwb`.`dnzw_mc`  AS `dnzw_mc`,
       `dangjian`.`dnzwb`.`dnzw_jb`  AS `dnzw_jb`,
       `dangjian`.`xzzwb`.`xzzw_id`  AS `xzzw_id`,
       `dangjian`.`xzzwb`.`xzzw_mc`  AS `xzzw_mc`,
       `dangjian`.`xzzwb`.`xzzw_jb`  AS `xzzw_jb`,
       `dangjian`.`bmb`.`bm_id`      AS `bm_id`,
       `dangjian`.`bmb`.`bm_mc`      AS `bm_mc`,
       `dangjian`.`zbb`.`zb_id`      AS `zb_id`,
       `dangjian`.`zbb`.`zb_mc`      AS `zb_mc`
from `dangjian`.`djxx`
       join `dangjian`.`yhb`
       join `dangjian`.`yh_xxb` `xx`
       join `dangjian`.`xlb`
       join `dangjian`.`zzmmb`
       join `dangjian`.`jgb`
       join `dangjian`.`mzb`
       join `dangjian`.`dnzwb`
       join `dangjian`.`xzzwb`
       join `dangjian`.`bmb`
       join `dangjian`.`zbb`
where ((`dangjian`.`djxx`.`yhdm` = `dangjian`.`yhb`.`user_id`) and (`dangjian`.`yhb`.`user_yhxxdm` = `xx`.`yhxx_id`) and
       (`xx`.`yhxx_xldm` = `dangjian`.`xlb`.`xl_id`) and (`xx`.`yhxx_jgdm` = `dangjian`.`jgb`.`jg_id`) and
       (`xx`.`yhxx_mzdm` = `dangjian`.`mzb`.`mz_id`) and (`xx`.`yhxx_xzzwdm` = `dangjian`.`xzzwb`.`xzzw_id`) and
       (`dangjian`.`djxx`.`zzmmdm` = `dangjian`.`zzmmb`.`zzmm_id`) and
       (`dangjian`.`djxx`.`dnzwdm` = `dangjian`.`dnzwb`.`dnzw_id`) and
       (`dangjian`.`djxx`.`bmdm` = `dangjian`.`bmb`.`bm_id`) and (`dangjian`.`djxx`.`zbdm` = `dangjian`.`zbb`.`zb_id`));


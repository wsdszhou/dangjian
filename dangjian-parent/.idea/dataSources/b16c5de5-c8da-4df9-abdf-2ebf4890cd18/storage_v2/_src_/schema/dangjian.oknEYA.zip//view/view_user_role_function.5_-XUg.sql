create view view_user_role_function as
select `dangjian`.`mkb`.`mk_id`      AS `mk_id`,
       `dangjian`.`mkb`.`mk_mc`      AS `mk_mc`,
       `dangjian`.`mkb`.`mk_code`    AS `mk_code`,
       `dangjian`.`mkb`.`mk_f_id`    AS `mk_f_id`,
       `dangjian`.`mkb`.`mk_sfsccd`  AS `mk_sfsccd`,
       `dangjian`.`mkb`.`mk_px`      AS `mk_px`,
       `dangjian`.`mkb`.`mk_url`     AS `mk_url`,
       `dangjian`.`mkb`.`mk_ms`      AS `mk_ms`,
       `dangjian`.`mkb`.`mk_icon`    AS `mk_icon`,
       `dangjian`.`mkb`.`mk_xgsj`    AS `mk_xgsj`,
       `dangjian`.`yhb`.`user_id`    AS `user_id`,
       `dangjian`.`yhb`.`user_mc`    AS `user_mc`,
       `dangjian`.`yh_xxb`.`yhxx_id` AS `yhxx_id`,
       `dangjian`.`yh_xxb`.`yhxx_xm` AS `yhxx_xm`,
       `dangjian`.`jsb`.`js_id`      AS `js_id`,
       `dangjian`.`jsb`.`js_mc`      AS `js_mc`,
       `dangjian`.`jsb`.`js_xgsj`    AS `js_xgsj`,
       `dangjian`.`jsb`.`js_code`    AS `js_code`,
       `dangjian`.`jsb`.`js_ms`      AS `js_ms`,
       `dangjian`.`jsb`.`js_yxj`     AS `js_yxj`
from (((((`dangjian`.`yhb` join `dangjian`.`yh_xxb`) join `dangjian`.`yh_jsb`) join `dangjian`.`jsb`) join `dangjian`.`js_mk`)
       join `dangjian`.`mkb`)
where ((`dangjian`.`yhb`.`user_yhxxdm` = `dangjian`.`yh_xxb`.`yhxx_id`) and
       (`dangjian`.`yhb`.`user_id` = `dangjian`.`yh_jsb`.`yh_id`) and
       (`dangjian`.`jsb`.`js_id` = `dangjian`.`yh_jsb`.`js_id`) and
       (`dangjian`.`jsb`.`js_id` = `dangjian`.`js_mk`.`js_id`) and
       (`dangjian`.`mkb`.`mk_id` = `dangjian`.`js_mk`.`mk_id`));


create view view_yhxx as
select `xxb`.`yhxx_id`    AS `yhxx_id`,
       `xxb`.`yhxx_xm`    AS `yhxx_xm`,
       `xxb`.`yhxx_dhhm`  AS `yhxx_dhhm`,
       `xxb`.`yhxx_xb`    AS `yhxx_xb`,
       `xxb`.`yhxx_csrq`  AS `yhxx_csrq`,
       `xxb`.`yhxx_sjh`   AS `yhxx_sjh`,
       `xxb`.`yhxx_mj`    AS `yhxx_mj`,
       `xxb`.`yhxx_yx`    AS `yhxx_yx`,
       `xxb`.`yhxx_sfzh`  AS `yhxx_sfzh`,
       `xxb`.`yhxx_tx`    AS `yhxx_tx`,
       `xxb`.`yhxx_ms`    AS `yhxx_ms`,
       `xxb`.`yhxx_da`    AS `yhxx_da`,
       `a`.`xl_id`        AS `xl_id`,
       `a`.`xl_mc`        AS `xl_mc`,
       `b`.`zzmm_id`      AS `zzmm_id`,
       `b`.`zzmm_mc`      AS `zzmm_mc`,
       `c`.`jg_id`        AS `jg_id`,
       `c`.`js_szs_id`    AS `js_szs_id`,
       `c`.`js_szqx_mc`   AS `js_szqx_mc`,
       `c`.`jg_szs_mc`    AS `jg_szs_mc`,
       `d`.`mz_id`        AS `mz_id`,
       `d`.`mz_mc`        AS `mz_mc`,
       `e`.`dnzw_id`      AS `dnzw_id`,
       `e`.`dnzw_mc`      AS `dnzw_mc`,
       `e`.`dnzw_jb`      AS `dnzw_jb`,
       `f`.`xzzw_id`      AS `xzzw_id`,
       `f`.`xzzw_mc`      AS `xzzw_mc`,
       `f`.`xzzw_jb`      AS `xzzw_jb`,
       `g`.`bm_id`        AS `bm_id`,
       `g`.`bm_mc`        AS `bm_mc`,
       `h`.`zb_id`        AS `zb_id`,
       `h`.`zb_mc`        AS `zb_mc`,
       `h`.`zb_ssbmdm`    AS `zb_ssbmdm`,
       `h`.`zb_lxdm`      AS `zb_lxdm`,
       `h`.`zb_ms`        AS `zb_ms`,
       `yh`.`user_id`     AS `user_id`,
       `yh`.`user_mc`     AS `user_mc`,
       `yh`.`user_pwk`    AS `user_pwk`,
       `yh`.`user_mm`     AS `user_mm`,
       `yh`.`user_wx_id`  AS `user_wx_id`,
       `yh`.`user_wxm`    AS `user_wxm`,
       `yh`.`user_ms`     AS `user_ms`,
       `yh`.`user_cjrq`   AS `user_cjrq`,
       `yh`.`user_yhxxdm` AS `user_yhxxdm`,
       `yh`.`user_ztdm`   AS `user_ztId`,
       `zt`.`zt_mc`       AS `user_ztMc`
from `dangjian`.`yh_xxb` `xxb`
       join `dangjian`.`xlb` `a`
       join `dangjian`.`zzmmb` `b`
       join `dangjian`.`jgb` `c`
       join `dangjian`.`mzb` `d`
       join `dangjian`.`dnzwb` `e`
       join `dangjian`.`xzzwb` `f`
       join `dangjian`.`bmb` `g`
       join `dangjian`.`zbb` `h`
       join `dangjian`.`yhb` `yh`
       join `dangjian`.`yh_ztb` `zt`
where ((`xxb`.`yhxx_xldm` = `a`.`xl_id`) and (`xxb`.`yhxx_zzmmdm` = `b`.`zzmm_id`) and
       (`xxb`.`yhxx_jgdm` = `c`.`jg_id`) and (`xxb`.`yhxx_mzdm` = `d`.`mz_id`) and
       (`xxb`.`yhxx_dnzwdm` = `e`.`dnzw_id`) and (`xxb`.`yhxx_xzzwdm` = `f`.`xzzw_id`) and
       (`xxb`.`yhxx_bmdm` = `g`.`bm_id`) and (`xxb`.`yhxx_zbdm` = `h`.`zb_id`) and
       (`yh`.`user_yhxxdm` = `xxb`.`yhxx_id`) and (`yh`.`user_ztdm` = `zt`.`zt_id`));


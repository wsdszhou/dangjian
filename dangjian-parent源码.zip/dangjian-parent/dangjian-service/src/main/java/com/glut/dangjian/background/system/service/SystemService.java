package com.glut.dangjian.background.system.service;


import java.util.List;

import com.glut.dangjian.entity.other.Gnb;
import com.glut.dangjian.entity.other.Mkb;

public interface SystemService {

    public List<Gnb>  getMkbList();

}

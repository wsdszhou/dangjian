package com.glut.dangjian.background.user.service;

import com.glut.dangjian.entity.view.ViewYhxx;

public interface YhxxService {

    ViewYhxx getYhxxByYhId(String userId);

}

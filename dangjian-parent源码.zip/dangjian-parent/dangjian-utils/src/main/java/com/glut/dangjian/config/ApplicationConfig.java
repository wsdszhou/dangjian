package com.glut.dangjian.config;
/** 
* @author xulankong
* @date 创建时间:  2018年12月1日 下午3:00:14
* @version 1.0
*/
public class ApplicationConfig {

    public static final String rootFile = "E:\\images";
    
    // 最大文件大小为1000MB
    public static final long UPLOADSIZE = 1070596096;
}

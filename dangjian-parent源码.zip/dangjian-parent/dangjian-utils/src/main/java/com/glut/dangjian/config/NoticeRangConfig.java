package com.glut.dangjian.config;
/** 
* @author xulankong
* @date 创建时间:  2018年12月18日 下午2:43:34
* @version 1.0
*/
public class NoticeRangConfig {

    // 个人通知
    public static final Integer INDIVIDUAL = 1;
    
    //全校
    public static final Integer SCHOOL = 1; 
    
    //部门
    public static final Integer DEPARTMENT = 1; 
    
    //支部
    public static final Integer BRANCH = 1; 
}

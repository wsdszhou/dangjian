<template>
  <div id="app">
    <transition :name="$store.getters.direction==='forward'?'pop-in':'pop-out'">
      <div>
        <keep-alive>
          <router-view class="app-content" :djmhshow="true" v-if="!$route.meta.noKeepAlive"></router-view>
        </keep-alive>
        <router-view class="app-content" v-if="$route.meta.noKeepAlive"></router-view>
      </div>
    </transition>
  </div>
</template>

<script>
  import {mapActions} from 'vuex'

  export default {
    name: 'App',
    methods: {
      ...mapActions({
        setToken: 'SET_TOKEN', // 设置登录状态
        deleteToken: 'DELETE_TOKEN', // 删除登录状态
        decrease: 'DECREASE_ALLMESSAGE', // 删除一条通知
        setAllMessage: 'SET_ALLMESSAGE', // 设置所有通知
        setAllspMessage: 'SET_ALLSPMESSAGE', // 设置所有审批通知
        setExamId: 'SET_EXAMID', // 设置考试ID
        setUsername: 'SET_USERNAME', // 设置用户名
        setAvatar: 'SET_AVATAR' // 头像初始化
      }),
      // 获取当前账号是否有进行中的考试
      _getExams() {
        this.$http.post('/exam/TestPaperListTesting')
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              res = res.data
              if (res.list.length) { // 如果有则提示用户有正在进行中的考试，确认是否跳转
                this.$nextTick(() => {
                  window.setTimeout(() => {
                    this.setExamId(res.list[0].id)
                    let path = this.$route.path
                    let onexam = path.split('/')[1]
                    if (path === '/exam/testing' || onexam === 'onexam') {
                      return
                    }
                    this.$confirm('检测到您当前有未提交的考试，是否立即跳转', '未完成的考试')
                      .then((val) => {
                        if (val.result) {
                          this.$router.push({name: 'exam-testing'})
                        }
                      })
                  }, 3000)
                })
              }
            } else {
              // 防止vuex中还有examId
              this.setExamId(0)
            }
          })
          .catch()
      },
      // 获取用户通知
      getALLMessage() {
        this.$http.get('/notice/getNoticeNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllMessage(res.data)
              }
            }
          }).catch(() => {
        })
      },
      // 获取用户审批数量
      getALLspMessage() {
        this.$http.get('/approval/getApprovalNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllspMessage(res.data)
              }
            }
          }).catch(() => {
        })
      },
      // 获取登录状态
      _getLogStatus() {
        this.$http.post('/isLogin')
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              if (!window.localStorage.token) {
                window.localStorage.setItem('token', 'logged')
              } else {
                window.localStorage.token = 'logged'
              }
              this.setToken()
              this.setUsername(res.data)
              this.getALLMessage()
              this.getALLspMessage()
              this._getExams()
              this.setAvatar('')
            } else {
              if (!window.localStorage.token) {
                window.localStorage.setItem('token', 'nologged')
              } else {
                window.localStorage.token = 'nologged'
              }
              this.deleteToken()
            }
          })
          .catch(() => {
            if (!window.localStorage.token) {
              window.localStorage.setItem('token', 'nologged')
            } else {
              window.localStorage.token = 'nologged'
            }
            this.deleteToken()
          })
      }
    },
    created() {
      this._getLogStatus()
    }
  }
</script>

<style lang="stylus">
  #app
    width: 100%
    height: 100%
    overflow: hidden
    .app-content
      width: 100%
      height: 100%

</style>

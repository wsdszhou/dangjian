<template>
  <div @click="onChoose">
    <mu-ripple class="border-1px mu-ripple">
      <span class="span" :class="{active:currentOption===option}">{{option}}</span>
      <span class="option"><span class="choice">{{choice}}</span></span>
    </mu-ripple>
  </div>
</template>

<script>
  export default {
    methods: {
      onChoose() {
        this.$emit('on-choose', this.option)
      }
    },
    mounted() {
      if (this.currentOption === this.option) {
        this.$emit('on-choose')
      }
    },
    props: {
      option: {
        type: String
      },
      currentOption: [String],
      choice: [String, Number]
    }
  }
</script>

<style scoped lang="stylus">
  @import '~common/stylus/mixin'
  .mu-ripple
    vertical-align: bottom
    border-1px(rgba(7, 17, 27, 0.1))
    .span
      display: inline-block
      width: 0.6rem
      margin-right: 0.2rem
      height: 0.6rem
      line-height: 0.6rem
      vertical-align: top
      border-radius: 50%
      border: 1px solid #dcdfe6
      color: #606266
      text-align: center
      box-sizing: border-box
      font-weight: 500
      &.active
        color: #fff
        background-color: rgb(33, 150, 243)

  .option
    display: inline-block
    width: 5.8rem
    line-height: 0.3rem
    padding-top: 0.13rem
    white-space: pre-wrap
    .choice
      vertical-align: bottom

</style>

<template>
  <div class="common-title">
    <mu-button fab small class="wrapper" @click="back" color="#ee2728">
      <mu-icon value="arrow_back" size="24"></mu-icon>
    </mu-button>
    <span class="title">{{title}}</span>
    <mu-button v-if="needsearch" fab small class="search" @click="search" color="#ee2728">
      <mu-icon value="search" size="24"></mu-icon>
    </mu-button>
    <mu-button v-if="needrefresh" fab small class="search" @click="refresh" color="#ee2728">
      <mu-icon value="refresh" size="24"></mu-icon>
    </mu-button>
  </div>
</template>

<script>
  export default {
    props: {
      title: {
        type: String,
        default: '智慧党建'
      },
      backPath: {
        type: Object,
        default() {
          return null
        }
      },
      needsearch: {
        type: Boolean,
        default() {
          return false
        }
      },
      needrefresh: {
        type: Boolean,
        default() {
          return false
        }
      }
    },
    methods: {
      // 搜索功能按钮
      search() {
        this.$emit('search')
      },
      refresh() {
        this.$emit('refresh')
      },
      back() {
        if (this.backPath) {
          this.$router.push(this.backPath)
          return
        }
        this.$router.back()
      }
    }
  }
</script>

<style scoped lang="stylus">
  .common-title
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem
    .search
      position: absolute
      top: 0rem
      right: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
</style>

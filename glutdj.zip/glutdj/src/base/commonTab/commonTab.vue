<template>
  <div class="commontab">
    <div class="tab">
      <router-link
        tag="div"
        v-for="(tab,index) in tabs"
        :key="tab.name"
        class="tab-item"
        :to="tab.url">
        <div
          tag="div"
          ref="item"
          class="name"
          color="#9e9e9e"
          @click="_lineMove(index)"
          :opacity="0.2">
          <mu-ripple class="mu-ripple ">{{ tab.name }}</mu-ripple>
        </div>
      </router-link>
      <div class="sideline" ref="sideline"></div>
    </div>
  </div>
</template>

<script>
  import {prefixStyle} from 'common/js/dom'

  const transform = prefixStyle('transform')

  export default {
    props: {
      tabs: {
        type: Array,
        default() {
          return [1, 2]
        }
      },
      dynamic: {
        type: Boolean,
        default() {
          return false
        }
      }
    },
    created() {
      this.$nextTick(() => {
        if (this.dynamic) { // 如果传入的tabs是通过http请求来的数据则重定向至首页
          this.$router.push(this.tabs[0].url)
        }
        this._setLineWidth()
        this.setCurrentRoute()
      })
    },
    methods: {
      _setLineWidth() {
        this.itemWidth = this.$refs.item[0].clientWidth
        this.$refs.sideline.style.width = this.itemWidth + 'px'
      },
      setCurrentRoute() {
        this.tabs.forEach((item, index) => {
          if (this.$route.path === item.url) {
            this._lineMove(index)
          }
        })
      },
      _lineMove(index) {
        this.$refs.sideline.style[transform] = `translate3d(${this.itemWidth * index}px,0,0)`
        this.$emit('move', index)
      }
    }
  }
</script>

<style scoped lang="stylus">
  .commontab
    width: 100%
    top: 0.8rem
    left: 0
    .tab
      position: relative
      display: flex
      width: 100%
      height: 0.7rem
      line-height: 0.7rem
      background-color: #ffffff
      box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
      .sideline
        position: absolute
        left: 0
        bottom: 0
        border: 0
        height: 0.03rem
        background-color: #f01414
        transition: all 0.3s
        transform: translate3d(0, 0, 0)
      .tab-item
        flex: 1
        text-align: center
        color: #9fabb6
        &.active
          color: #f01414
        .name
          display: block
          margin: auto
          font-size: 0.26rem
          .mu-ripple
            position: relative
            width: 100%
</style>

<template>
  <transition name="slide">
    <div class="newremind">
      <common-title title="通知详情" class="title"></common-title>
      <scroll class="remind-content"
              :showItem="showItem"
              :itemsLoaded="itemsLoaded"
              :scrollbar="true"
              ref="scroll">
        <div>
          <div class="info-wrapper">
            <div class="item-wrapper">
              <div class="item-title">
                {{news.tzBt}}
              </div>
              <div
                color="#9e9e9e"
                :opacity="0.6"
                class="item mu-ripple">
                <div class="date-time">
                  <mu-icon value="person" size="10px" class="icon" color="#43a047"></mu-icon>
                  发布人：{{news.fbrxm}}
                </div>
                <div class="date-time">
                  <mu-icon value="access_time" size="10px" class="icon" color="orange"></mu-icon>
                  发布时间：{{news.tzFbsj}}
                </div>
                <div class="numi">
                  <mu-icon value="assignment" size="10px" class="icon" color="pink"></mu-icon>
                  通知内容：{{news.tzNr}}
                </div>
              </div>
            </div>
          </div>
        </div>
      </scroll>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'
  import CommonTitle from 'base/common-title/common-title'

  export default {
    data() {
      return {
        news: {},
        page: 1,
        limit: 5,
        honorShow: false,
        honorDetail: {},
        showItem: '', // 数据获取情况
        loading: false,
        itemsLoaded: false,
        itemsStatus: 0
      }
    },
    created() {
      this.init()
    },
    methods: {
      init() {
        this.id = this.$route.params.id
        this.getDetail(this.id)
      },
      // 点击审批通知获取详细信息
      getDetail(id) {
        this.$http.get('/notice/getSingleNoticeInfo', {
          params: {
            noticeId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.news = res.data
          }
        }).catch()
      }
    },
    watch: {
      '$route': 'init'
    },
    components: {
      Scroll,
      CommonTitle
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .newremind
    width: 100%
    height: 100%
    position: absolute
    z-index: 10
    font-size: 0
    background-color: #fff
    .remind-content
      height: 100%
      overflow: hidden
      .info-wrapper
        box-sizing: border-box
        width: 100%
        height: 100%
        overflow: hidden
        .item-wrapper
          margin-top: 0.2rem
          .item-title
            min-height: 0.56rem
            margin: 0 0.12rem
            font-size: 0.3rem
            line-height: 0.56rem
            padding-left: 0.2rem
            border-radius: 0.1rem 0.1rem 0 0
            color: rgba(255, 255, 255, .95)
            background: #e22b19
          .item
            margin: 0 0.12rem 0.2rem 0.12rem
            padding: 0.2rem
            box-sizing: border-box
            border-radius: 0 0 0.1rem 0.1rem
            box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
            background: #fff
            .numi
              min-height: 0.56rem
            div
              border-1px(rgba(7, 17, 27, 0.1))
          .mu-ripple
            position: relative
            padding-top: 0.32rem
            display: inline-block
            width: 7.25rem
            div
              min-height: 0.5rem
              line-height: 0.5rem
              font-size: 0.3rem
              font-family: 'Microsoft YaHei'
              .icon
                vertical-align: bottom
                padding-bottom: 0.06rem
    .loader-container
      position: absolute
      width: 100%
      top: 50%
      transform: translateY(-50%)
    .show-item
      position: absolute
      width: 100%
      top: 40%
      transform: translateY(-40%)
      text-align: center
      font-size: 0.3rem
      color #484848
      .show-item-msg
        padding-bottom: 0.2rem
        border-bottom: solid 1px #ce285d
      .refresh
        margin: 6rem auto 0.2rem auto
        text-align: center
        font-size: 0.34rem
</style>

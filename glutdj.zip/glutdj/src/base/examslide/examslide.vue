<template>
  <div class="slide-wrapper">
    <div class="slide" ref="slide">
      <div class="slide-group" ref="slideGroup">
        <slot>
        </slot>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import {addClass} from 'common/js/dom'
  import BScroll from 'better-scroll'

  export default {
    props: {
      click: {
        type: Boolean,
        default: true
      },
      threshold: {
        type: Number,
        default: 0.3
      },
      speed: {
        type: Number,
        default: 400
      }
    },
    data() {
      return {
        currentPageIndex: 0
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.update()
      })
    },
    activated() {
      if (!this.slide) {
        return
      }
      this.slide.enable()
      let pageIndex = this.slide.getCurrentPage().pageX
      this.slide.goToPage(pageIndex, 0, 0)
      this.currentPageIndex = pageIndex
    },
    methods: {
      update() {
        if (this.slide) {
          this.slide.destroy()
        }
        this.$nextTick(() => {
          this.init()
        })
      },
      refresh() {
        this._setSlideWidth()
        this.slide.refresh()
      },
      prev() {
        this.slide.prev()
      },
      next() {
        this.slide.next()
      },
      goToPage(x, y, time) {
        this.slide.goToPage(x, y, time)
      },
      init() {
        this.currentPageIndex = 0
        this._setSlideWidth()
        this._initSlide()
      },
      _setSlideWidth() {
        this.children = this.$refs.slideGroup.children
        let width = 0
        let slideWidth = this.$refs.slide.clientWidth
        for (let i = 0; i < this.children.length; i++) {
          let child = this.children[i]
          addClass(child, 'slide-item')
          child.style.width = slideWidth + 'px'
          width += slideWidth
        }
        this.$refs.slideGroup.style.width = width + 'px'
      },
      _initSlide() {
        this.slide = new BScroll(this.$refs.slide, {
          scrollX: true,
          scrollY: false,
          momentum: false,
          snap: {
            loop: this.loop,
            threshold: this.threshold,
            speed: this.speed
          },
          bounce: false,
          stopPropagation: true,
          click: this.click
        })
        this.slide.on('scrollEnd', this._onScrollEnd)
      },
      _onScrollEnd() {
        let pageIndex = this.slide.getCurrentPage().pageX
        this.currentPageIndex = pageIndex
        this.$emit('index-change', this.currentPageIndex + 1)
      }
    }
  }
</script>

<style lang="stylus" scoped rel="stylesheet/stylus">
  .slide-wrapper
    overflow: hidden
    .slide
      position: relative
      height: 100%
      min-height: 1px
      .slide-group
        position: relative
        overflow: hidden
        white-space: nowrap
        .slide-item
          float: left
          box-sizing: border-box
          overflow: hidden
</style>

<template>
  <div class="head-wrapper" @click="gonews">
    <mu-ripple tag="div" class="head mu-ripple" color="white" :opacity="0.8">
      <div class="item name">
        <mu-icon value="subject"></mu-icon>
        {{ name }}
      </div>
      <div class="item more">
        查看更多
        <mu-icon value="chevron_right"></mu-icon>
      </div>
    </mu-ripple>
  </div>
</template>

<script>
  export default {
    props: {
      name: {
        type: String
      }
    },
    methods: {
      gonews() {
        this.$emit('gonews')
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .head
    width: 100%
    height: 0.6rem
    line-height: 0.6rem
    box-sizing: border-box
    text-align: center
    font-size: 0
    border-radius: 3px
    color: #a2a2a2
    background-color: #fff
    border-1px(rgba(7, 17, 27, 0.1))
    &.mu-ripple
      position: relative
      width: 100%
    .item
      display: inline-block
      height: 0.6rem
      line-height: 0.6rem
      margin-left: 0.2rem
      vertical-align: top
      font-size: 0.3rem
      .mu-icon
        vertical-align: bottom
        padding-bottom: 0.05rem
    .name
      float: left
      color: #ee2728
    .more
      font-size: 0.26rem
      float: right
</style>

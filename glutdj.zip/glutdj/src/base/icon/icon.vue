<template>
  <div class="icon">
    <div class="list-item">
      <div class="icon-wrapper" :class="color"><i class="iconfont" :class="iconType"></i></div>
      <span class="item-name">{{name}}</span>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      name: {
        type: String
      },
      color: {
        type: String
      },
      iconType: {
        type: String
      }
    },
    data() {
      return {}
    }
  }
</script>

<style scoped lang="stylus">
  .icon
    width: 100%
    .list-item
      display: inline-block
      flex: 1
      text-align: center
      .icon-wrapper
        margin: 0 auto 6px auto
        height: 45px
        width: 45px
        border-radius: 50%
        &.red
          background-color: #dd2929
        &.green
          background-color: #43dd8e
        &.blue
          background-color: #156cdd
        &.yellow
          background-color: #ddc014
        &.purple
          background-color: #8a40dd
        &.pink
          background-color: #dd0db0
        &.lightblue
          background-color: #0fddd7
        .iconfont
          display: block
          height: 100%
          box-sizing: border-box
          padding: 9px
          font-size: 28px
          color: #fff
      .item-name
        letter-spacing: 1px
        color: #9fabb6
        font-size: 13px
</style>

<template>
  <div class="info-wrapper">
    <div class="item-wrapper" v-for="(item) in items" :key="item.name">
      <div class="item-title">{{item.name}}</div>
      <mu-ripple
        color="#9e9e9e"
        :opacity="0.6"
        class="item mu-ripple">
        <div class="num">题目数量：{{item.num}}</div>
        <div class="time">截止时间：{{item.dateTime}}</div>
        <div class="time">{{item.status===0?'进行中':'已过期'}}</div>
      </mu-ripple>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      items: {
        type: Array
      }
    }
  }
</script>

<style scoped lang="stylus">
  .info-wrapper
    padding-bottom: 1.4rem
    box-sizing: border-box
    width: 100%
    height: 100%
    overflow: hidden
    .item-wrapper
      margin-top: 0.2rem
      animation: bounceInRight 1s .1s both
      .item-title
        height: 0.4rem
        margin: 0 0.12rem
        font-size: 0.3rem
        line-height: 0.4rem
        padding-left: 0.2rem
        border-radius: 0.1rem 0.1rem 0 0
        color: #ffffff
        background: #007f7f
      .item
        height: 2rem
        margin: 0 0.12rem 0.2rem 0.12rem
        padding: 0.2rem
        box-sizing: border-box
        border-radius: 0 0 0.1rem 0.1rem
        box-shadow: 0 0 5px #cccccc
        background: #fff
      .mu-ripple
        position: relative
        display: inline-block
        width: 7.25rem
      .num
        font-size: 14px
        font-family: 'Microsoft YaHei'
      .time
        font-size: 14px
        font-family: 'Microsoft YaHei'
</style>

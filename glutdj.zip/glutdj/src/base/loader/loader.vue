<template>
  <div class="loader-container">
    <div class="loader">
      <div v-loading="true"
           data-mu-loading-size="40"
           data-mu-loading-color="red"
           data-mu-loading-overlay-color="rgba(0, 0, 0, 0)"
           style="width: 50px; height: 100px;">
      </div>
    </div>
    <div class="msg">
      <div class="data-container">
        <span class="data">获取数据中</span>
      </div>
    </div>
  </div>
</template>

<script>
  export default {}
</script>

<style scoped>

  .loader {
    position: relative;
    margin: 0 auto;
    width: 1rem;
  }

  .msg {
    height: 0.5rem;
    line-height: 0.5rem;
    position: relative;
    width: 100%;
  }

</style>

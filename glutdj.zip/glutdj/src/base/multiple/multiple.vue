<template>
  <div class="multiple">
    <div class="onexam-header" @click="showList">
      <mu-button full-width color="red">
        <div class="header-name">智慧党建考试</div>
        <div class="header-num"><span class="num">{{index}}/{{length}}</span></div>
      </mu-button>
    </div>
    <div class="onexam-main">
      <div class="main-title">
        <span class="type">
          <mu-chip color="blue">多选题</mu-chip>
        </span>
        <span class="name">{{exam.name}}</span>
      </div>
      <div class="main-options">
        <Chooser v-for="(item,index) in exam.options"
                 :key="index"
                 :option="options[item.num-1]"
                 @on-choose="chooseAnswer"
                 :current-option="curOpt[options[index]]"
                 :choice="item.value"
        ></Chooser>
      </div>
    </div>
  </div>
</template>

<script>
  import Chooser from 'base/chooser/chooser'

  export default {
    data() {
      return {
        answers: [],
        options: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'],
        curOpt: {A: '', B: '', C: '', D: '', E: '', F: '', G: '', H: ''}
      }
    },
    props: {
      curoption: {
        type: String
      },
      exam: {
        type: Object
      },
      index: [String, Number],
      length: [String, Number],
      id: [String, Number]
    },
    methods: {
      chooseAnswer(answer) {
        let answers = this.answers
        for (let i = 0; i < answers.length; i++) {
          if (answers[i] === answer) {
            answers.splice(i, 1)
            answers.sort()
            this.curOpt[answer] = ''
            this.$emit('multiple-choosed', {
              [this.id]: answers
            })
            return
          }
        }
        answers.push(answer)
        answers.sort()
        answers.forEach((item) => {
          this.curOpt[item] = item
        })
        this.$emit('multiple-choosed', {
          [this.id]: answers
        })
      },
      // 根据题目选项个数初始化curOpt
      _initOpt() {
        let len = this.exam.options.length
        for (let i = 0; i < len; i++) {
          this.curOpt[this.options[i]] = ''
        }
        if (this.curoption) {
          let curArray = this.curoption.split('')
          curArray.forEach((item) => {
            this.curOpt[item] = item
          })
          this.answers = curArray
        }
      },
      showList() {
        this.$emit('showList')
      }
    },
    created() {
      this._initOpt()
    },
    components: {
      Chooser
    }
  }
</script>

<style scoped lang="stylus">
  .onexam-header
    position: relative
    height: 0.7rem
    font-size: 0.28rem
    background: #ececec
    color: #3567b3
    font-size: 0.24rem
    .header-name
      display: inline-block
      width: 6.5rem
      line-height: 0.7rem
      text-align: left
      overflow: hidden
    .header-num
      display: inline-block
      position: absolute
      right: 0.36rem
      line-height: 0.7rem

  .onexam-main
    margin: 0.2rem 0 0 0.35rem
    font-size: 0.27rem
    .main-title
      line-height: 0.6rem
      padding-bottom: 0.26rem
      white-space: pre-wrap
      .type
        color: green
    .main-options
      div // Chooser的样式
        margin-bottom: 0.26rem
        position: relative
</style>

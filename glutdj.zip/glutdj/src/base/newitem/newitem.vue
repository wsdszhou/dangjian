<template>
  <div class="newitem" @click="clickit">
    <div class="newitem-content">
      <mu-ripple class="mu-ripple wrapper" color="#9e9e9e" :opacity="0.2">
        <div class="icon"><img width="100" height="60" src="../../common/image/1.jpg"></div>
        <div class="text"><h2>{{title}}</h2></div>
        <div class="time">{{time}}</div>
      </mu-ripple>
    </div>
  </div>
</template>

<script>

  export default {
    props: {
      title: {
        type: String,
        default() {
          return '桂林理工大学新闻'
        }
      },
      time: {
        type: String,
        default() {
          return ''
        }
      },
      id: {
        type: String,
        default() {
          return ''
        }
      }
    },
    methods: {
      clickit() {
        this.$emit('clickit', this.id)
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .newitem
    width: 100%
    min-height: 1.6rem
    width: 100%
    border-top: 0
    border-radius: 0.1rem
    background-color: #fff
    .newitem-content
      height: 100%
      padding-top: 0.2rem
      margin: 0 0.2rem 0 0.2rem
      .wrapper
        display: flex
        justify-content: center
        border-1px(rgba(1, 17, 27, 0.1))
        &.mu-ripple
          position: relative
        .text
          flex: 1
          box-sizing: border-box
          padding: 0 0.16rem 0.16rem 0.16rem
          font-size: 0.3rem
          color: #7a838e
        .icon
          flex: 0 0 2rem
        .time
          position: absolute
          right: 0.15rem
          bottom: 0
          color: #6b737c
          font-size: 0.22rem
</style>

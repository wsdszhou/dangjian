<template>
  <div class="num" v-if="message > 0">{{ message }}</div>
</template>

<script>
  export default {
    props: ['message']
  }
</script>

<style scoped lang="stylus">
  .num
    z-index: 1000
    line-height: 20px
    text-align: center
    border-radius: 50%
    padding: 0
    width: 20px
    height: 20px
    overflow: hidden
    z-index: 1000
    font-size: 12px
    background-color: #ff2829
    color: #fff
</style>

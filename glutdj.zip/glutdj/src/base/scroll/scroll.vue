<template>
  <div ref="wrapper">
    <slot></slot>
  </div>
</template>

<script>
  import BScroll from 'better-scroll'

  export default {
    props: {
      probeType: {
        type: Number,
        default: 1
      },
      click: {
        type: Boolean,
        default: true
      },
      scrollX: {
        type: Boolean,
        default: false
      },
      listenScroll: {
        type: Boolean,
        default: false
      },
      data: {
        type: Array,
        default: null
      },
      scrollbar: {
        type: null,
        default: false
      },
      pullDownRefresh: {
        type: null,
        default: false
      },
      pullUpLoad: {
        type: null,
        default: false
      },
      refreshDelay: {
        type: Number,
        default: 20
      },
      momentum: {
        type: Boolean,
        default: true
      }
    },
    mounted() {
      setTimeout(() => {
        this._initscroll()
      }, 20)
    },
    methods: {
      _initscroll() {
        if (!this.$refs.wrapper) {
          return
        }
        this.scroll = new BScroll(this.$refs.wrapper, {
          probeType: this.probeType,
          click: this.click,
          pullUpLoad: this.pullUpLoad,
          scrollbar: this.scrollbar,
          momentum: this.momentum,
          bounce: {
            top: false,
            bottom: false
          }
        })

        if (this.listenScroll) {
          this._initListenScroll()
        }

        if (this.pullUpLoad) {
          this._initPullUpLoad()
        }
      },
      _initListenScroll() {
        let me = this
        this.scroll.on('scroll', (pos) => {
          me.$emit('scroll', pos)
        })
      },
      _initPullUpLoad() {
        let me = this
        this.scroll.on('pullingUp', () => {
          me.$emit('pullingUp')
        })
      },
      enable() {
        this.scroll && this.scroll.enable()
      },
      disable() {
        this.scroll && this.scroll.disable()
      },
      refresh() {
        this.scroll && this.scroll.refresh()
      },
      scrollTo() {
        this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
      },
      scrollToElement() {
        this.scroll && this.scrollToElement.apply(this.scroll, arguments)
      },
      finishPullUp() {
        this.scroll && this.scroll.finishPullUp()
      }
    },
    watch: {
      data() {
        setTimeout(() => {
          this.refresh()
        }, this.refreshDelay)
      }
    }
  }
</script>

<style scoped lang="stylus">

</style>

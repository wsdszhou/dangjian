<template>
  <div ref="wrapper">
    <div>
      <slot></slot>
      <div class="load">
        <div v-show="!itemsLoaded" class="loader-container">
          <loader class="loader"></loader>
        </div>
        <div class="show-item" v-if="showItem">
          <span class="show-item-msg">{{showItem}}</span>
          <div class="refresh">
            <mu-button color="red" @click="clickrefresh">点击刷新</mu-button>
          </div>
        </div>
        <div v-show="itemsLoaded&&exceedHeight" class="pullup-wrapper">
          <div class="before-trigger" v-if="!pullUploading">
            <span>{{pullUpTxt}}</span>
          </div>
          <div class="after-trigger" v-else>
            <div v-loading="true"
                 data-mu-loading-size="32"
                 data-mu-loading-color="red"
                 data-mu-loading-overlay-color="rgba(0, 0, 0, 0)"
                 style="position: relative; width: 200px; height: 100px;"></div>
          </div>
        </div>
        <mu-container data-mu-loading-color="secondary"
                      data-mu-loading-overlay-color="rgba(0, 0, 0, .2)"
                      v-loading="loading">
        </mu-container>
      </div>
    </div>
  </div>
</template>

<script>
  import BScroll from 'better-scroll'
  import Loader from 'base/loader/loader'

  export default {
    props: {
      itemsLoaded: {
        type: Boolean,
        default: false
      },
      exceedHeight: {
        type: Boolean,
        default: false
      },
      pullUploading: {
        type: Boolean,
        default: false
      },
      notPullUploadOver: {
        type: Boolean,
        default: false
      },
      loading: {
        type: Boolean,
        default: false
      },
      showItem: {
        type: String,
        default: ''
      },
      probeType: {
        type: Number,
        default: 1
      },
      click: {
        type: Boolean,
        default: true
      },
      scrollX: {
        type: Boolean,
        default: false
      },
      listenScroll: {
        type: Boolean,
        default: false
      },
      data: {
        type: Array,
        default: null
      },
      scrollbar: {
        type: null,
        default: false
      },
      pullDownRefresh: {
        type: null,
        default: false
      },
      pullUpLoad: {
        type: null,
        default: false
      },
      refreshDelay: {
        type: Number,
        default: 20
      },
      momentum: {
        type: Boolean,
        default: true
      }
    },
    mounted() {
      setTimeout(() => {
        this._initscroll()
      }, 20)
    },
    methods: {
      _initscroll() {
        if (!this.$refs.wrapper) {
          return
        }
        this.scroll = new BScroll(this.$refs.wrapper, {
          probeType: this.probeType,
          click: this.click,
          pullUpLoad: this.pullUpLoad,
          scrollbar: this.scrollbar,
          momentum: this.momentum,
          bounce: {
            top: false
          }
        })

        if (this.listenScroll) {
          this._initListenScroll()
        }

        if (this.pullUpLoad) {
          this._initPullUpLoad()
        }
      },
      _initListenScroll() {
        let me = this
        this.scroll.on('scroll', (pos) => {
          me.$emit('scroll', pos)
        })
      },
      _initPullUpLoad() {
        let me = this
        this.scroll.on('pullingUp', () => {
          me.$emit('pullingUp')
        })
      },
      enable() {
        this.scroll && this.scroll.enable()
      },
      disable() {
        this.scroll && this.scroll.disable()
      },
      refresh() {
        this.scroll && this.scroll.refresh()
      },
      scrollTo() {
        this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
      },
      scrollToElement() {
        this.scroll && this.scrollToElement.apply(this.scroll, arguments)
      },
      finishPullUp() {
        this.scroll && this.scroll.finishPullUp()
      },
      clickrefresh() {
        this.$emit('clickrefresh')
      }
    },
    watch: {
      data() {
        setTimeout(() => {
          this.refresh()
        }, this.refreshDelay)
      }
    },
    computed: {
      pullUpTxt() {
        return this.notPullUploadOver ? '上拉加载更多' : '没有更多了'
      }
    },
    components: {
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  .load
    position: relative
    width: 100%

  .pullup-wrapper
    width: 100%
    height: 1rem
    font-size: 0.3rem
    display: flex
    justify-content center
    align-items center
    padding: 0.22rem 0
    .after-trigger
      margin-top: 0.2rem
    .before-trigger
      height: 100%

  .loader-container
    position: absolute
    top: 0
    bottom: 0
    left: 0
    right: 0
    margin: auto
    width: 100%
    height: 100%
    .loader
      position: absolute
      top: 2rem

  .show-item
    margin: 0.5rem auto 0 auto
    text-align: center
    font-size: 0.3rem
    color #484848
    .show-item-msg
      padding-bottom: 0.2rem
      border-bottom: solid 1px #ce285d
    .refresh
      margin: 4rem auto 0.2rem auto
      text-align: center
      font-size: 0.34rem
</style>

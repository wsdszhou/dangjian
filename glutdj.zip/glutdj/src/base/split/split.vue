<template>
  <div class="split"></div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style scoped lang="stylus">
  .split
    width: 100%
    height: 0.1rem
    background: #f5f5f4
</style>

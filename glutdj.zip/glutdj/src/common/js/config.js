export const ERR_OK = 0
// export const URL = 'http://localhost:8090'
export const URL = 'http://111.231.76.233:8080'

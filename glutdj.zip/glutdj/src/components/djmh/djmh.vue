<template>
  <transition name="slide">
    <div class="djmh">
      <div class="headers" ref="headers">
        <common-title
          :title="title"
          :backPath="backPath"
          :needsearch="true"
          @search="goSearch">
        </common-title>
        <div v-if="tabLoaded">
          <tab :tabs="tabs" :dynamic="true"></tab>
        </div>
        <div class="page-content" v-if="searchShow">
          <mu-text-field v-model="content" placeholder="输入新闻标题关键字并点击搜索" action-icon="search"
                         :action-click="searchNews"
                         class="field"></mu-text-field>
        </div>
      </div>
      <keep-alive>
        <router-view class="djmh-content"
                     ref="items"
                     :content="content"
                     :style="'height:'+curheight+'px'"
                     :search="searchShow"></router-view>
      </keep-alive>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Tab from 'base/commonTab/commonTab'

  export default {
    data() {
      return {
        title: '党建门户',
        tabs: [],
        oldIndex: 0,
        newIndex: 0,
        moveSlide: '',
        tabLoaded: false,
        curheight: 0,
        content: '',
        searchShow: false,
        backPath: {name: 'home'}
      }
    },
    created() {
      this.getTab()
    },
    methods: {
      getTab() {
        this.$http.get('news/getSecondColumn/1')
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              let data = res.data
              data.forEach((item, index) => {
                let curTab = this.tabs[index] = {}
                curTab.name = item.lmMc
                curTab.url = `/djmh/${item.lmId}`
              })
              this.tabLoaded = true
            }
            this.$nextTick(() => {
              this.curheight = window.innerHeight - this.$refs.headers.clientHeight
            })
          })
          .catch(() => {
          })
      },
      // 打开搜索页面
      goSearch() {
        this.searchShow = !this.searchShow
      },
      // 搜索新闻
      searchNews() {
        this.$refs.items.getit(1)
      }
    },
    components: {
      CommonTitle,
      Tab
    }
  }
</script>

<style scoped lang="stylus">
  .djmh
    position: fixed
    width: 100%
    z-index: 100
    background-color: #f5f5f4

  .page-content
    position: absolute
    top: 0.8rem
    width: 100%
    height: 0.7rem
    background-color: #fff
    .field
      width: 100%
      padding: 0 0.15rem
    .button
      padding: 0 0.15rem
    .mu-input
      padding-bottom: 0
      margin-bottom: 0
</style>

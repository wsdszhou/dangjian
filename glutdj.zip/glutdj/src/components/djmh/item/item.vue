<template>
  <div class="news">
    <scroll
      class="news-content"
      @scroll="scroll"
      :probeType="probeType"
      :scrollbar="scrollbar"
      :pullUpLoad="pullUpLoad"
      @pullingUp="onPullingUp"
      ref="scroll"
    >
      <div class="items" ref="items">
        <newitem class="item"
                 v-for="(item,index) in news"
                 :key="index"
                 :title="item.xwBt"
                 :time="item.xwXgsj"
                 :id="item.xwId"
                 @clickit="go"></newitem>
        <div v-show="newsLoaded&&exceedHeight" class="pullup-wrapper">
          <div class="before-trigger" v-if="!pullUploading">
            <span>{{pullUpTxt}}</span>
          </div>
          <div class="after-trigger" v-else>
            <div v-loading="true"
                 data-mu-loading-size="32"
                 data-mu-loading-color="red"
                 data-mu-loading-overlay-color="rgba(0, 0, 0, 0)"
                 style="position: relative; width: 200px; height: 100px;"></div>
          </div>
        </div>
        <mu-container data-mu-loading-color="secondary"
                      data-mu-loading-overlay-color="rgba(0, 0, 0, .2)"
                      v-loading="loading">
        </mu-container>
      </div>
    </scroll>
    <div class="detailpage">
      <newdetail :id="newsid" v-if="detailPageShow" @off-show="showOff"></newdetail>
    </div>
  </div>
</template>

<script>
  import newitem from 'base/newitem/newitem'
  import Scroll from 'base/scroll/scroll'
  import Newdetail from 'components/new-detail/new-detail'

  export default {
    data() {
      return {
        news: [],
        news2: [], // 存放搜索得的新闻列表
        searched: false,
        id: '',
        newsid: '', // 新闻ID
        newsLoaded: false,
        detailPageShow: false, // 新闻详情页
        loading: false,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        probeType: 3,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        },
        page: 1,
        limit: 10
      }
    },
    props: {
      search: {
        type: Boolean,
        default() {
          return false
        }
      },
      content: {
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.id = this.$route.params.id
      this.getit(this.id)
    },
    methods: {
      // 根据栏目ID获取新闻列表
      getit(id) {
        let url = '/news/column'
        let curParams = {
          page: this.page,
          limit: this.limit,
          columnId: id
        }
        if (this.search) {
          this.searched = true
          url = '/news/getSearchNewsPageList'
          curParams = {
            page: this.page,
            limit: this.limit,
            newsTitle: this.content
          }
          this.news2 = this.news
        }
        this.news = null
        this.newsLoaded = false
        this.loading = true
        this.exceedHeight = false
        this.page = 1 // 保证在当前页面首次加载为第一页
        this.$http.get(url, {
          params: curParams
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.news = res.data
            this.loading = false
            this.newsLoaded = true
          }
          if (this.news.length >= this.limit) {
            this.exceedHeight = true
          }
        }).catch(() => {
          this.loading = false
        })
      },
      // 根据新闻ID进入新闻内容
      go(newsid) {
        this.newsid = newsid
        this.detailPageShow = true
      },
      // 关闭新闻详情
      showOff() {
        this.detailPageShow = false
      },
      scroll(pos) {
        this.scrollY = pos.y
      },
      // 加载更多新闻
      getMoreNews() {
        this.$http.get('/news/column', {
          params: {
            page: ++this.page,
            limit: this.limit,
            columnId: this.id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.news, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        }).catch()
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMoreNews()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      changeNews(newVal) {
        if (newVal.redirectedFrom === '/djmh') {
          return
        }
        let path = newVal.path.split('/')[1]
        if (path === 'djmh') {
          this.getit(newVal.params.id)
        }
      }
    },
    computed: {
      pullUpTxt() {
        return this.notPullUploadOver ? '上拉加载更多' : '没有更多了'
      }
    },
    watch: {
      '$route': 'changeNews',
      'search': function (newVal) {
        if (!newVal) {
          if (this.content && this.searched) {
            this.news = this.news2
          }
        }
      }
    },
    components: {
      newitem,
      Scroll,
      Newdetail
    }
  }
</script>

<style scoped lang="stylus">
  /*@import "~common/stylus/mixin"*/
  .news
    position: absolute
    width: 100%
    height: 100%
    font-size: 0.3rem
    .news-content
      height: 100%
      overflow: hidden
      .pullup-wrapper
        width: 100%
        height: 1rem
        display: flex
        justify-content center
        align-items center
        padding: 0.32rem 0
        .after-trigger
          margin-top: 0.2rem
</style>

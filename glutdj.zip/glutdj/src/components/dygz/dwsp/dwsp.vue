<template>
  <item></item>
</template>

<script>
  import Item from '../item/item'

  export default {
    components: {
      Item
    }
  }
</script>

<style scoped lang="stylus">

</style>

<template>
  <transition name="slide">
    <div class="dygz">
      <div class="headers" ref="headers">
        <common-title title="党员工作"
                      @refresh="refresh"
                      :backPath="backPath"
                      :needrefresh="true"></common-title>
        <div>
          <tab :tabs="tabs" ref="tab"></tab>
        </div>
      </div>
      <keep-alive>
        <router-view :style="'height:'+curheight+'px'" ref="dygz" @keep-nav="keepNav"></router-view>
      </keep-alive>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Tab from 'base/commonTab/commonTab'

  export default {
    data() {
      return {
        tabs: [
          {name: '党务审批', url: '/dygz/getPartyNoticePageList'},
          {name: '新闻审批', url: '/dygz/getNewsNoticePageList'},
          {name: '评论审批', url: '/dygz/getNewsCommentNoticePageList'}
        ],
        oldIndex: 0,
        newIndex: 0,
        moveSlide: '',
        tabLoaded: false,
        curheight: 0,
        backPath: {name: 'home'}
      }
    },
    created() {
      this.setHeight()
    },
    methods: {
      // 设置router-view的高度
      setHeight() {
        this.$nextTick(() => {
          this.curheight = window.innerHeight - this.$refs.headers.clientHeight
        })
      },
      refresh() {
        this.$refs.dygz.$children[0].init()
      },
      keepNav() {
        this.$refs.tab.setCurrentRoute()
      }
    },
    components: {
      CommonTitle,
      Tab
    }
  }
</script>

<style scoped lang="stylus">
  .dygz
    position: fixed
    width: 100%
    z-index: 100
    background-color: #f5f5f4
</style>

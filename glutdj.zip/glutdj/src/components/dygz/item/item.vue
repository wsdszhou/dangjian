<template>
  <div class="newremind">
    <scroll class="remind-content"
            :showItem="showItem"
            :itemsLoaded="itemsLoaded"
            :exceedHeight="exceedHeight"
            :pullUploading="pullUploading"
            :notPullUploadOver="notPullUploadOver"
            :loading="loading"
            :scrollbar="scrollbar"
            :pullUpLoad="pullUpLoad"
            @clickrefresh="refresh"
            @pullingUp="onPullingUp"
            ref="scroll">
      <div>
        <div class="info-wrapper">
          <div class="item-wrapper" v-for="(item) in items" :key="item.name">
            <div class="item-title">
              {{item.tzBt}}
            </div>
            <div
              color="#9e9e9e"
              :opacity="0.6"
              class="item mu-ripple">
              <div class="numi">
                <mu-icon value="check" size="10px" class="icon" color="pink"></mu-icon>
                通知内容：{{item.tzNr}}
              </div>
              <div class="date-time">
                <mu-icon value="person" size="10px" class="icon" color="#43a047"></mu-icon>
                发布人：{{item.fbrxm}}
              </div>
              <div class="date-time">
                <mu-icon value="access_time" size="10px" class="icon" color="orange"></mu-icon>
                发布时间：{{item.tzFbsj}}
              </div>
              <div class="date-time">
                <mu-button color="red" @click.stop="selectApproval(item.tzId,1)">同意</mu-button>
                <mu-button color="red" @click.stop="selectApproval(item.tzId,0)">不同意</mu-button>
                <mu-button color="red" @click.stop="getDetail(item.tzId)">点击查看详情</mu-button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </scroll>
    <div class="scannews" v-if="scannews">
      <scannews :showit="scannewsShow"
                :id="noticeId"
                @off-show="scannewsPageShow">
      </scannews>
    </div>
    <div class="scannews" v-if="scandj">
      <scandj :showit="scandjShow"
              :id="noticeId"
              @off-show="scandjPageShow">
      </scandj>
    </div>
  </div>
</template>

<script>
  import Scroll from 'base/scrollmore/scrollmore'
  import Confirm from 'components/exam/index/confirm/confirm'
  import Loader from 'base/loader/loader'
  import Scannews from '../scannews/scannews'
  import Scandj from '../Scandj/Scandj'
  import {mapActions} from 'vuex'

  const NOITEMS = 1 // 获取数据成功但没有数据
  const ITEMSFAILED = 2 // 获取数据失败

  export default {
    data() {
      return {
        items: [],
        id: '',
        page: 1,
        limit: 5,
        honorShow: false,
        honorDetail: {},
        showItem: '', // 数据获取情况
        loading: false,
        itemsLoaded: false,
        itemsStatus: 0,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        },
        scannews: false,
        scannewsShow: false,
        scandj: false,
        scandjShow: false,
        noticeId: '' // 通知ID
      }
    },
    created() {
      this.init()
    },
    methods: {
      ...mapActions({
        decreaseMessage: 'DECREASE_ALLSPMESSAGE' // 删除一条通知
      }),
      init() {
        this.keepNav()
        let ary = this.$route.path.split('/')
        this.id = ary[2]
        this.getit(this.id)
      },
      getit(id) {
        this.items = null
        this.itemsLoaded = false
        this.showItem = ''
        this.itemsStatus = 0
        this.exceedHeight = false
        this.$http.get(`/notice/${id}`, {
          params: {
            page: this.page,
            limit: this.limit,
            columnId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) { // 判断数据长度
              this.items = res.data
            } else {
              this.itemsStatus = NOITEMS
            }
            this.itemsLoaded = true
          }
          if (this.items.length >= this.limit) {
            this.exceedHeight = true
          } else {
            this.notPullUploadOver = false
          }
          this.showStatus()
        }).catch(() => {
          if (this.itemsStatus !== NOITEMS) {
            this.itemsStatus = ITEMSFAILED
          }
          this.showStatus()
        })
      },
      // 加载更多数据
      getMore() {
        let id = this.id
        this.$http.get(`/notice/${id}`, {
          params: {
            page: ++this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      // 保持tab最新状态
      keepNav() {
        this.$emit('keep-nav')
      },
      // 点击新闻审批通知获取详细信息
      getDetail(id) {
        let curId = this.id // 当前页面
        if (curId === 'getNewsNoticePageList') {
          this.noticeId = id
          this.scannewsPageShow()
        } else if (curId === 'getPartyNoticePageList') {
          this.noticeId = id
          this.scandjPageShow()
        }
      },
      // 根据id区分审批党籍还是新闻又或者是评论
      selectApproval(tzid, flag) {
        this.$confirm('确定？', '提示', {
          type: 'warning'
        }).then(({result}) => {
          if (result) {
            let id = this.id
            let url = ''
            if (id === 'getPartyNoticePageList') {
              url = 'PartyApproval'
            } else if (id === 'getNewsNoticePageList') {
              url = 'NewsApproval'
            } else if (id === 'getNewsCommentNoticePageList') {
              url = 'NewsCommentApproval'
            }
            if (flag) {
              this.approval(tzid, url)
            } else {
              this.noapproval(tzid, url)
            }
          }
        }).catch()
      },
      // 点击同意审批
      approval(tzid, url) {
        this.$http({
          url: `/approval/agree${url}`,
          method: 'post',
          data: {
            noticeId: tzid
          },
          transformRequest: [function (data) {
            // Do whatever you want to transform the data
            let ret = ''
            for (let it in data) {
              ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
            }
            return ret
          }]
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.$toast.success('审批成功')
            this.items.forEach((item, index) => {
              if (item.tzId === tzid) {
                this.items.splice(index, 1)
              }
            })
            this.decreaseMessage()
          }
        }).catch()
      },
      // 点击不同意审批
      noapproval(tzid, url) {
        this.$http({
          url: `/approval/disAgree${url}`,
          method: 'post',
          data: {
            noticeId: tzid
          },
          transformRequest: [function (data) {
            // Do whatever you want to transform the data
            let ret = ''
            for (let it in data) {
              ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
            }
            return ret
          }]
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.$toast.success('审批成功')
            this.items.forEach((item, index) => {
              if (item.tzId === tzid) {
                this.items.splice(index, 1)
              }
            })
            this.decreaseMessage()
          }
        }).catch()
      },
      // 根据数据状态显示信息
      showStatus() {
        if (this.itemsStatus === NOITEMS) {
          this.showItem = '暂无最新数据'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '获取数据失败'
        }
      },
      // 新闻详情页打开
      scannewsPageShow() {
        if (!this.scannews) {
          this.scannews = true
        }
        this.scannewsShow = !this.scannewsShow
      },
      // 党籍详情页打开
      scandjPageShow() {
        if (!this.scandj) {
          this.scandj = true
        }
        this.scandjShow = !this.scandjShow
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMore()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      // 刷新页面
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this.getit(this.id)
      }
    },
    components: {
      Scroll,
      Confirm,
      Loader,
      Scannews,
      Scandj
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .newremind
    width: 100%
    height: 100%
    position: relative
    z-index: 10
    font-size: 0
    .remind-content
      height: 100%
      overflow: hidden
      .info-wrapper
        box-sizing: border-box
        width: 100%
        height: 100%
        overflow: hidden
        .item-wrapper
          margin-top: 0.2rem
          .item-title
            min-height: 0.56rem
            margin: 0 0.12rem
            font-size: 0.3rem
            line-height: 0.56rem
            padding-left: 0.2rem
            border-radius: 0.1rem 0.1rem 0 0
            color: rgba(255, 255, 255, .95)
            background: #e22b19
          .item
            margin: 0 0.12rem 0.2rem 0.12rem
            padding: 0.2rem
            box-sizing: border-box
            border-radius: 0 0 0.1rem 0.1rem
            box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
            background: #fff
            .mu-button
              margin-right: 0.1rem
            div
              border-1px(rgba(7, 17, 27, 0.1))
              border-none()
          .mu-ripple
            position: relative
            padding-top: 0.32rem
            display: inline-block
            width: 7.25rem
            div
              min-height: 0.5rem
              line-height: 0.5rem
              font-size: 0.3rem
              font-family: 'Microsoft YaHei'
              .icon
                vertical-align: bottom
                padding-bottom: 0.06rem
    .loader-container
      position: absolute
      width: 100%
      top: 50%
      transform: translateY(-50%)
    .show-item
      position: absolute
      width: 100%
      top: 40%
      transform: translateY(-40%)
      text-align: center
      font-size: 0.3rem
      color #484848
      .show-item-msg
        padding-bottom: 0.2rem
        border-bottom: solid 1px #ce285d
      .refresh
        margin: 6rem auto 0.2rem auto
        text-align: center
        font-size: 0.34rem
</style>

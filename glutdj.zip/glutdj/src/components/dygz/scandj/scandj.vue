<template>
  <transition name="slide">
    <div class="dj-detail" v-show="showit">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">党籍详情</span>
      </div>
      <mu-paper class="item">
        <div>
          <mu-icon value="account_box" size="10px" class="icon" color="red"></mu-icon>
          姓名：{{info.yhxxXm }}
        </div>
        <div>
          <mu-icon value="school" size="10px" class="icon" color="indigo800"></mu-icon>
          学历：{{ info.xlMc }}
        </div>
        <div>
          <mu-icon value="location_on" size="10px" class="icon" color="deepPurple400"></mu-icon>
          所属部门：{{ info.bmMc }}
        </div>
        <div>
          <mu-icon value="domain" size="10px" class="icon" color="cyan500"></mu-icon>
          支部：{{info.zbMc }}
        </div>
        <div>
          <mu-icon value="person_pin" size="10px" class="icon" color="green500"></mu-icon>
          政治面貌：{{info.zzmmMc }}
        </div>
        <div>
          <mu-icon value="settings" size="10px" class="icon" color="orange600"></mu-icon>
          党内职务：{{ info.dnzwMc }}
        </div>
      </mu-paper>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'

  export default {
    data() {
      return {
        info: {},
        praiseNum: 0
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      id: {
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.init()
    },
    methods: {
      // 获取新闻
      init() {
        let id = this.id
        this.getDjdetail(id)
      },
      // 获取党籍详细信息
      getDjdetail(id) {
        this.$http.get('/party/getSinglePartyByNoticeId', {
          params: {
            noticeId: id
          },
          headers: {'content-type': 'charset=UTF-8'}
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.info = res.data
          }
        }).catch()
      },
      back() {
        this.$emit('off-show')
      }
    },
    watch: {
      'id': 'init'
    },
    components: {
      Scroll
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .dj-detail
    position: fixed
    top: 0
    left: 0
    width: 100%
    height: 100%
    overflow: hidden
    font-size: 0.3rem
    background-color: #fff

  .item
    position: relative
    margin: 0.12rem
    padding: 0.2rem
    box-sizing: border-box
    box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
    background: #fff
    div
      font-size: 0.3rem
      padding: 0.1rem 0 0 0.1rem
      border-1px(rgba(7, 17, 27, 0.1))
      i
        vertical-align: bottom

  .common-title
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem

</style>

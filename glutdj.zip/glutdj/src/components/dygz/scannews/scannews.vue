<template>
  <transition name="slide">
    <div class="new-detail" v-show="showit">
      <div class="detail-wrapper">
        <div class="new-header" ref="header">
          <div class="common-title">
            <mu-button fab small class="wrapper" @click="back" color="#ee2728">
              <mu-icon value="arrow_back" size="24"></mu-icon>
            </mu-button>
            <span class="title">新闻详情</span>
          </div>
        </div>
        <div class="new-wrapper">
          <scroll ref="scroll"
                  :scrollbar="scrollbar"
                  class="new-content">
            <div class="new-content-body">
              <div class="top"></div>
              <h1 class="new-title">{{news.xwBt}}</h1>
              <div class="new-info border-1px">
                <div class="datetime">{{news.xwXgsj}}</div>
              </div>
              <div class="new-body">
                <div ref="news"></div>
              </div>
            </div>
          </scroll>
        </div>
      </div>
      <transition name="top">
        <mu-button fab class="icon-top" @click="scrollTo" v-show="needTop">
          <mu-icon value="arrow_upward"></mu-icon>
        </mu-button>
      </transition>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'

  export default {
    data() {
      return {
        news: {},
        praiseNum: 0,
        scrollY: 0,
        scrollbar: {
          fade: true
        },
        needTop: false
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      id: {
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.init()
    },
    methods: {
      // 获取新闻
      init() {
        let id = this.id
        this.$http.get('/news/geSingleNewsByNoticeId', {
          params: {
            noticeId: id
          },
          headers: {'content-type': 'charset=UTF-8'}
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            let orablob = res.data.newsContext
            this.news = res.data
            this.$nextTick(() => {
              this.$refs.news.innerHTML = orablob
            })
          }
        }).catch()
      },
      back() {
        this.$emit('off-show')
      },
      scrollTo() {
        this.needTop = false
        this.$refs.scroll.scrollTo(0, 0, 500)
      }
    },
    watch: {
      'id': 'init'
    },
    components: {
      Scroll
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .new-detail
    position: fixed
    top: 0
    left: 0
    width: 100%
    height: 100%
    overflow: hidden
    font-size: 0.3rem
    background-color: #fff
    .detail-wrapper
      position: absolute
      width: 100%
      height: 100%
      overflow: hidden
      .new-header
        position: absolute
        width: 100%
        height: 0.8rem
        z-index: 1000
        text-align: center
        border-radius: 0.06rem
        overflow: hidden
        background: #ee2728
        box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
        transition: all 0.3s
      .new-wrapper
        position: absolute
        bottom: 0.72rem
        width: 100%
        height: 100%
        padding: 0 0.16rem
        .new-content
          height: 100%
          .new-content-body
            padding-bottom: 1rem
          .top
            height: 1.6rem
          .new-title
            width: 100%
            line-height: 1.25
            font-size 0.46rem
            font-weight: 700
          .new-info
            height: 0.6rem
            margin-bottom: 0.16rem
            border-1px(rgba(7, 17, 27, 0.4))
            div
              display: inline-block
              overflow: hidden
              color: #6b737c
              font-size: 0.28rem
            .read-num
              float: right
            .praise-num
              float: right
              padding-left: 0.3rem
              .thumb
                vertical-align: middle
                font-size: 0.34rem
          .new-body
            padding-bottom: 0.7rem
            white-space: pre-wrap
            word-break: break-all

  .mu-button
    box-shadow: none

  .icon-top
    position: fixed
    right: 5%
    bottom: 30%
    color: #fff;
    display: flex
    width: 0.84rem
    height: 0.84rem
    justify-content: center
    align-items: center;
    background-color: rgba(238, 39, 40, 0.9)
    .iconfont
      font-size: 0.5rem

  .top-enter-active, .top-leave-active
    transition: all 0.2s linear

  .top-enter, .top-leave-to
    transform: translate3d(0.9rem, 0, 0)

  .common-title
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem

</style>

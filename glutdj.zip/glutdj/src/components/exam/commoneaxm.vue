<template>
  <div class="exam">
    <scroll class="remind-content"
            :showItem="showItem"
            :itemsLoaded="itemsLoaded"
            :exceedHeight="exceedHeight"
            :pullUploading="pullUploading"
            :notPullUploadOver="notPullUploadOver"
            :loading="loading"
            :scrollbar="scrollbar"
            :pullUpLoad="pullUpLoad"
            @clickrefresh="refresh"
            @pullingUp="onPullingUp"
            ref="scroll">
      <div>
        <div class="info-wrapper">
          <div class="item-wrapper" v-for="(item) in items" :key="item.name" @click="showConfirm(item)">
            <div class="item-title">{{ item.name }}</div>
            <mu-ripple
              color="#9e9e9e"
              :opacity="0.6"
              class="item mu-ripple">
              <div class="num">
                <mu-icon value="search" size="10px" class="icon" color="#795548"></mu-icon>
                题目数量：{{ item.questionNumber }}
              </div>
              <div class="time">
                <mu-icon value="timelapse" size="10px" class="icon" color="blue"></mu-icon>
                考试时长：{{ item.examTime }}分钟
              </div>
              <div class="question">
                <mu-icon value="view_list" size="10px" class="icon" color="orange"></mu-icon>
                单选题：{{ item.singleNum }}道，多选题：{{ item.multipleNum }}道，判断题：{{ item.judgementNum }}道
              </div>
              <div class="date-time">
                <mu-icon value="access_time" size="10px" class="icon" color="#43a047"></mu-icon>
                开始时间：{{item.startTime }}
              </div>
              <div class="date-time">
                <mu-icon value="timer_off" size="10px" class="icon" color="red"></mu-icon>
                截止时间：{{item.endTime }}
              </div>
              <span class="status" :class="[examStatus===0?'status-ready':'status-testing']">
                {{examStatus===0?'待考':'考试中'}}
              </span>
            </mu-ripple>
          </div>
        </div>
      </div>
    </scroll>
    <confirm :examdetail="examdetail" class="confirm" ref="confirm"></confirm>
  </div>
</template>
<script>
  import Scroll from 'base/scrollmore/scrollmore'
  import Confirm from 'components/exam/index/confirm/confirm'
  import Loader from 'base/loader/loader'
  import {mapActions} from 'vuex'

  const NOITEMS = 1 // 成功获取数据但没有试卷
  const ITEMSFAILED = 2 // 获取数据失败
  const NOLOGIN = 3 // 用户未登录

  export default {
    data() {
      return {
        items: [],
        itemsLoaded: false,
        itemsStatus: 0,
        showItem: '', // 试卷获取情况
        examdetail: {},
        examStatus: 0, // 试卷是否是待考
        page: 1,
        limit: 5,
        loading: false,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        }
      }
    },
    props: ['path'], // API接口
    created() {
      this._getExams()
    },
    methods: {
      ...mapActions({
        setExamId: 'SET_EXAMID'
      }),
      _getExams() {
        this.$http({
          url: this.path,
          method: 'post'
        })
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              res = res.data
              if (res.list.length) { // 判断试卷数据长度
                this.items = res.list
                if (this.path === '/exam/TestPaperListTesting') {
                  this.setExamId(this.items[0].id)
                  this.examStatus = 1
                }
              } else {
                this.itemsStatus = NOITEMS
              }
            } else if (res.error === 101) {
              this.itemsStatus = NOLOGIN
              this.$login()
            }
            this.itemsLoaded = true
            if (this.items.length >= this.limit) {
              this.exceedHeight = true
            } else {
              this.notPullUploadOver = false
            }
            this.showStatus()
          })
          .catch(() => {
            if (this.itemsStatus !== NOITEMS) {
              this.itemsStatus = ITEMSFAILED
            }
            this.showStatus()
          })
      },
      // 加载更多数据
      getMore() {
        let path = this.path
        this.$http({
          url: path,
          method: 'post'
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      // 根据试卷状态显示信息
      showStatus() {
        if (this.itemsStatus === NOITEMS) {
          this.showItem = '暂无最新试卷'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '获取数据失败'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '用户未登录'
        }
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMore()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this._getExams()
      },
      showConfirm(item) {
        if (item.status === 1) {
          return
        }
        this.examdetail = item
        this.$refs.confirm.show()
      }
    },
    components: {
      Scroll,
      Confirm,
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .exam
    position: relative
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    .remind-content
      height: 100%
      overflow: hidden
      .info-wrapper
        box-sizing: border-box
        width: 100%
        height: 100%
        overflow: hidden
        .item-wrapper
          margin-top: 0.2rem
          animation: bounceInRight 1s .1s both
          .item-title
            min-height: 0.56rem
            margin: 0 0.12rem
            font-size: 0.3rem
            line-height: 0.56rem
            padding-left: 0.2rem
            border-radius: 0.1rem 0.1rem 0 0
            color: rgba(255, 255, 255, .95)
            background: #06aba0
          .item
            margin: 0 0.12rem 0.2rem 0.12rem
            padding: 0.2rem
            box-sizing: border-box
            border-radius: 0 0 0.1rem 0.1rem
            box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
            background: #fff
            div
              border-1px(rgba(7, 17, 27, 0.1))
          .mu-ripple
            position: relative
            display: inline-block
            width: 7.25rem
            .status
              position: absolute
              display: block
              top: 0.1rem
              right: 0.1rem
              height: 0.4rem
              width: 1rem
              text-align: center
              line-height: 0.4rem
              border-radius: 0.4rem
              font-size: 0.24rem
              color: #fff
              &.status-ready
                background: #36bb67
              &.status-testing
                background: #fb681d
            div
              padding-bottom: 0.05rem
              min-height: 0.5rem
              line-height: 0.5rem
              font-size: 0.3rem
              font-family: 'Microsoft YaHei'
              .icon
                vertical-align: bottom
    .loader-container
      position: absolute
      width: 100%
      top: 50%
      transform: translateY(-50%)
    .show-item
      position: absolute
      width: 100%
      top: 40%
      transform: translateY(-40%)
      text-align: center
      font-size: 0.3rem
      color #484848
      .show-item-msg
        padding-bottom: 0.2rem
        border-bottom: solid 1px #ce285d
      .refresh
        margin: 6rem auto 0.2rem auto
        text-align: center
        font-size: 0.34rem
</style>

<template>
  <transition name="slide">
    <div class="dyjy">
      <div ref="headers">
        <common-title :title="title" :backPath="backPath"></common-title>
        <tab :tabs="tabs" ref="tab"></tab>
      </div>
      <keep-alive>
        <router-view class="dyjy-content"
                     :style="'height:'+curheight+'px'"
                     @keep-nav="keepNav"></router-view>
      </keep-alive>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Tab from 'base/commonTab/commonTab'

  export default {
    data() {
      return {
        title: '考试中心',
        tabs: [{name: '待考', url: '/exam/index'},
          {name: '考试中', url: '/exam/testing'},
          {name: '已考试', url: '/exam/tested'}
        ],
        backPath: {name: 'home'},
        curheight: 0
      }
    },
    created() {
      this.$nextTick(() => {
        this.curheight = window.innerHeight - this.$refs.headers.clientHeight
      })
    },
    methods: {
      keepNav() {
        this.$refs.tab.setCurrentRoute()
      }
    },
    components: {
      CommonTitle,
      Tab
    }
  }
</script>

<style scoped lang="stylus">
  .dyjy
    position: fixed
    width: 100%
    z-index: 100
    background-color: #f5f5f4
</style>

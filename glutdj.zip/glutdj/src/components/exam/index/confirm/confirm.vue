<template>
  <div class="confirm" v-show="showFlag" @click.self="showOff">
    <mu-container>
      <mu-dialog title="确认进行考试?"
                 width="600" max-width="80%"
                 :esc-press-close="false"
                 :overlay-close="false"
                 :open.sync="showFlag">
        <div class="confirm-main">
          <div class="name">考试：{{ examdetail.name }}</div>
          <div class="time">考试时长：{{ examdetail.examTime }}分钟</div>
          <div class="select">单选题：{{ examdetail.singleNum }}道</div>
          <div class="select">多选题：{{ examdetail.multipleNum }}道</div>
          <div class="question">判断题：{{ examdetail.judgementNum }}道</div>
          <div class="datetime"><span class="span-block">考试截止时间：</span>{{ examdetail.endTime }}</div>
        </div>
        <mu-button slot="actions" flat color="primary" @click="showOff">暂时不了</mu-button>
        <mu-button slot="actions" flat color="primary" @click="confirm(examdetail.id)">确认考试</mu-button>
      </mu-dialog>
    </mu-container>
  </div>
</template>

<script>
  import {mapGetters, mapActions} from 'vuex'

  export default {
    data() {
      return {
        showFlag: false
      }
    },
    props: {
      examdetail: {
        type: Object,
        default() {
          return {
            name: '考试1'
          }
        }
      }
    },
    methods: {
      ...mapActions({
        setExamId: 'SET_EXAMID'
      }),
      show() {
        this.showFlag = true
      },
      showOff() {
        this.showFlag = false
      },
      confirm(id) {
        this.showFlag = false
        if (this.examId === 0) {
          this.setExamId(id)
          this.$router.push('/onexam/' + id)
        } else if (this.examId !== 0 && this.examId !== id) {
          this.$toast.warning('完成未完成的试卷才可进行新考试')
        } else if (this.examId !== 0 && this.examId === id) {
          this.$router.push('/onexam/' + id + '?restart=1')
        }
      }
    },
    computed: {
      ...mapGetters(['examId'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin.styl"
  .confirm
    position: fixed
    top: 0
    left: 0
    z-index: 30
    height: 100%
    width: 100%
    background: rgba(7, 17, 27, 0.4)
    font-size: 0

  .confirm-main
    width: 100%
    font-size: 0.3rem
    color: rgba(0, 0, 0, 0.7)
    div
      margin-top: 0.1rem
      border-1px(rgba(7, 17, 27, 0.1))
      .span-block
        display: block
</style>

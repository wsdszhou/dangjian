<template>
  <commoneaxm :path="path"></commoneaxm>
</template>

<script>
  import Commoneaxm from '../commoneaxm'

  export default {
    data() {
      return {
        path: '/exam/TestPaperList?page=1&limit=10'
      }
    },
    components: {
      Commoneaxm
    }
  }
</script>
<style>
</style>

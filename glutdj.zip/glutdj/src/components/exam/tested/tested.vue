<template>
  <div class="exam">
    <scroll class="remind-content"
            :showItem="showItem"
            :itemsLoaded="itemsLoaded"
            :exceedHeight="exceedHeight"
            :pullUploading="pullUploading"
            :notPullUploadOver="notPullUploadOver"
            :loading="loading"
            :scrollbar="scrollbar"
            :pullUpLoad="pullUpLoad"
            @clickrefresh="refresh"
            @pullingUp="onPullingUp"
            ref="scroll">
      <div>
        <div class="info-wrapper">
          <div class="item-wrapper" v-for="(item) in items" :key="item.name">
            <div class="item-title">{{ item.name }}</div>
            <div
              color="#9e9e9e"
              :opacity="0.6"
              class="item mu-ripple">
              <div class="num">
                <mu-icon value="star" size="10px" class="icon" color="blue"></mu-icon>
                分数：{{ item.studentScore }}
              </div>
              <div class="num">
                <mu-icon value="check" size="10px" class="icon" color="pink"></mu-icon>
                及格分数：{{ item.passScore }}
              </div>
              <div class="date-time">
                <mu-icon value="timer" size="10px" class="icon" color="#43a047"></mu-icon>
                开始时间：{{item.startTime }}
              </div>
              <div class="date-time">
                <mu-icon value="access_time" size="10px" class="icon" color="orange"></mu-icon>
                截止时间：{{item.endTime }}
              </div>
              <span class="status">已考</span>
            </div>
          </div>
        </div>
      </div>
    </scroll>
  </div>
</template>

<script>
  import Scroll from 'base/scrollmore/scrollmore'
  import Loader from 'base/loader/loader'

  const NOITEMS = 1 // 成功获取数据但没有试卷
  const ITEMSFAILED = 2 // 获取数据失败

  export default {
    data() {
      return {
        items: [],
        itemsLoaded: false,
        itemsStatus: 0,
        showItem: '', // 试卷获取情况
        examdetail: {},
        score: 0,
        passScore: 0,
        refreshing: false,
        loading: false,
        loadready: false,
        page: 1,
        limit: 5,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        }
      }
    },
    created() {
      this._getTested()
    },
    methods: {
      _getTested() {
        this.$http.post('/exam/TestPaperListTested')
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              res = res.data
              if (res.list.length) { // 判断试卷数据长度
                this.items = res.list
                this.items.forEach((item) => {
                  item.studentScore = Math.floor((item.studentScore / item.totalScore) * 100)
                })
              } else {
                this.itemsStatus = NOITEMS
              }
              this.itemsLoaded = true
            }
            if (this.items.length >= this.limit) {
              this.exceedHeight = true
            } else {
              this.notPullUploadOver = false
            }
            this.showStatus()
          })
          .catch(() => {
            if (this.itemsStatus !== NOITEMS) {
              this.itemsStatus = ITEMSFAILED
            }
            this.showStatus()
          })
      },
      // 加载更多数据
      getMore() {
        this.$http({
          url: '/exam/TestPaperListTested',
          method: 'post'
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      // 根据试卷状态显示信息
      showStatus() {
        if (this.itemsStatus === NOITEMS) {
          this.showItem = '暂无最新试卷'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '获取数据失败'
        }
      },
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this._getTested()
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMore()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      }
    },
    components: {
      Scroll,
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .exam
    position: relative
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    .remind-content
      height: 100%
      overflow: hidden
      .info-wrapper
        box-sizing: border-box
        width: 100%
        height: 100%
        overflow: hidden
        .item-wrapper
          margin-top: 0.2rem
          .item-title
            min-height: 0.56rem
            margin: 0 0.12rem
            font-size: 0.3rem
            line-height: 0.56rem
            padding-left: 0.2rem
            border-radius: 0.1rem 0.1rem 0 0
            color: rgba(255, 255, 255, .95)
            background: #06aba0
          .item
            margin: 0 0.12rem 0.2rem 0.12rem
            padding: 0.2rem
            box-sizing: border-box
            border-radius: 0 0 0.1rem 0.1rem
            box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
            background: #fff
            div
              border-1px(rgba(7, 17, 27, 0.1))
          .mu-ripple
            position: relative
            display: inline-block
            width: 7.25rem
            .status
              position: absolute
              display: block
              top: 0.1rem
              right: 0.1rem
              height: 0.4rem
              width: 1rem
              text-align: center
              line-height: 0.4rem
              border-radius: 0.4rem
              font-size: 0.24rem
              color: #fff
              background: #42a5f5
            div
              padding-bottom: 0.05rem
              min-height: 0.5rem
              line-height: 0.5rem
              font-size: 0.3rem
              font-family: 'Microsoft YaHei'
              .icon
                vertical-align: bottom
    .loader-container
      position: absolute
      width: 100%
      top: 50%
      transform: translateY(-50%)
    .show-item
      position: absolute
      width: 100%
      top: 40%
      transform: translateY(-40%)
      text-align: center
      font-size: 0.3rem
      color #484848
      .show-item-msg
        padding-bottom: 0.2rem
        border-bottom: solid 1px #ce285d
      .refresh
        margin: 6rem auto 0.2rem auto
        text-align: center
        font-size: 0.34rem
</style>

<template>
  <commoneaxm :path="path"></commoneaxm>
</template>

<script>
  import Commoneaxm from '../commoneaxm'

  export default {
    data() {
      return {
        path: '/exam/TestPaperListTesting'
      }
    },
    created() {
      this.keepNav()
    },
    methods: {
      // 保持导航状态
      keepNav() {
        this.$emit('keep-nav')
      }
    },
    components: {
      Commoneaxm
    }
  }
</script>
<style>
</style>

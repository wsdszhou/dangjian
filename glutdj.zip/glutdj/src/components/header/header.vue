<template>
  <div class="header">
    <div class="v-header">
      <mu-appbar style="width: 100%;height: 100%;" color="#ee2728" class="v-header">
        <mu-avatar size="33" slot="left" class="avatar">
          <img class="img" src='../../common/image/gluticon.png'>
        </mu-avatar>
        <span class="title">智慧党建系统</span>
        <mu-button flat slot="right" v-if="!username" @click="toLogin">登录</mu-button>
        <span slot="right" v-if="username">{{username}}</span>
      </mu-appbar>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'

  export default {
    computed: {
      ...mapGetters(['username'])
    },
    created() {
      this.user = 'zh123angfei'
    },
    methods: {
      toLogin() {
        this.$router.push({name: 'login'})
      }
    }
  }
</script>

<style scoped lang="stylus">
  .v-header
    position: relative
    width: 100%
    height: 0.7rem
    line-height: 0.7rem
    font-size: 0.25rem
    z-index: 1
    .avatar
      margin: 0
      .img
        color: #ee2728
    .title
      font-size: 0.32rem
</style>

<template>
  <div class="home">
    <div class="home-wrapper">
      <scroll class="home-content" ref="scroll">
        <div class="scroll">
          <slide class="slide">
            <div>
              <a href="javascript:;">
                <img src="../../common/image/1.jpg" class="needsclick">
              </a>
            </div>
            <div>
              <a href="javascript:;">
                <img src="../../common/image/2.jpg" class="needsclick">
              </a>
            </div>
            <div>
              <a href="javascript:;">
                <img src="../../common/image/4.jpg" class="needsclick">
              </a>
            </div>
          </slide>
          <list></list>
          <split></split>
          <div class="item-wrapper">
            <div class="djdt">
              <headshow :name="djdt" @gonews="goNews"></headshow>
              <newitem class="item"
                       v-for="(item,index) in news"
                       :key="index"
                       :title="item.xwBt"
                       :time="item.xwXgsj"
                       :id="item.xwId"></newitem>
            </div>
          </div>
          <div class="button">
            <mu-button color="red" @click="getALLMessage">获取最新公告数目</mu-button>
            <mu-button color="red" @click="getALLspMessage">获取最新党员工作数目</mu-button>
          </div>
        </div>
      </scroll>
    </div>
  </div>
</template>

<script>
  import Scroll from 'base/scroll/scroll'
  import Slide from 'base/slide/slide'
  import Split from 'base/split/split'
  import List from './list/list'
  import Headshow from 'base/headshow/headshow'
  import newitem from 'base/newitem/newitem'
  import {mapActions} from 'vuex'

  export default {
    data() {
      return {
        slider: ['1', '1', '1'],
        news: [
          {xwBt: '桂林理工大学', xwXgsj: '2018-08-08', xwId: 'asd'},
          {xwBt: '桂林理工大学', xwXgsj: '2018-08-08', xwId: 'asd'}
        ],
        djdt: '党建动态'
      }
    },
    methods: {
      ...mapActions({
        setAllMessage: 'SET_ALLMESSAGE', // 设置所有通知
        setAllspMessage: 'SET_ALLSPMESSAGE' // 设置所有审批通知
      }),
      go(newsid) {
        this.$router.push({path: `/new-detail/${newsid}`})
      },
      // 进入党建门户
      goNews() {
        this.$router.push({name: 'djmh'})
      },
      // 获取用户通知
      getALLMessage() {
        this.$http.get('/notice/getNoticeNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllMessage(res.data)
              }
            }
          }).catch(() => {
        })
      },
      // 获取用户审批数量
      getALLspMessage() {
        this.$http.get('/approval/getApprovalNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllspMessage(res.data)
              }
            }
          }).catch(() => {
        })
      }
    },
    components: {
      Scroll,
      Slide,
      Split,
      List,
      Headshow,
      newitem
    }
  }
</script>

<style scoped lang="stylus">
  .home
    width: 100%
    height: 100%
    position: absolute
    top: 0.7rem
    font-size: 0.4rem
    .home-wrapper
      position: relative
      width: 100%
      height: 100%
      overflow: hidden
      .home-content
        height: 100%
        width: 100%
        position: absolute
        overflow: hidden
        .scroll
          .slide
            box-shadow: 0 2px 4px -1px rgba(0, 0, 0, .2), 0 4px 5px 0 rgba(0, 0, 0, .14), 0 1px 10px 0 rgba(0, 0, 0, .12)
            div
              width: 100%
              height: 3.2rem

  .item-wrapper
    margin-bottom: 0.15rem

  .button
    .mu-button
      float: right
      margin-left: 0.2rem
</style>

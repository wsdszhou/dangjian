<template>
  <div class="list">
    <div v-for="(list,index) in lists" :key="index" class="list-line">
      <router-link v-for="item in list" tag="div" class="list-item" :to="item.to" :key="item.name">
        <mu-ripple class="mu-ripple" color="#9e9e9e" :opacity="0.2">
          <div class="icon-wrapper" :class="item.color">
            <mu-icon class="icon" :value="item.icon"></mu-icon>
          </div>
          <span class="item-name">{{ item.name }}</span>
        </mu-ripple>
      </router-link>
    </div>
    <num :message="allspMessage" class="spnum"></num>
  </div>
</template>

<script>
  import Num from 'base/num/num'
  import {mapGetters} from 'vuex'

  export default {
    data() {
      return {
        lists: [
          [
            {name: '党建门户', to: '/djmh', color: 'color1', icon: 'filter'},
            {name: '党员教育', to: '/dyjy', color: 'color2', icon: 'import_contacts'},
            {name: '党员工作', to: '/dygz', color: 'color3', icon: 'work'},
            {name: '考试中心', to: '/exam', color: 'color4', icon: 'edit'}
          ]
        ]
      }
    },
    computed: {
      ...mapGetters(['allspMessage'])
    },
    components: {Num}
  }
</script>

<style scoped lang="stylus">
  .list
    position: relative
    margin-top: 0.1rem
    padding-top: 0.1rem
    width: 100%
    height: 1.3rem
    box-sizing: content-box
    font-size: 0
    background: #fff
    box-shadow: 0 2px 4px -1px rgba(0, 0, 0, .2), 0 4px 5px 0 rgba(0, 0, 0, .14), 0 1px 10px 0 rgba(0, 0, 0, .12)
    .list-line
      display: flex
      margin-bottom: 0.1rem
      height: 100%
      .list-item
        display: inline-block
        flex: 1
        text-align: center
        line-height: 1.5
        box-sizing: border-box
        border-right: 1px solid rgba(7, 17, 27, 0.1)
        border-bottom: 1px solid rgba(7, 17, 27, 0.1)
        &:last-child
          border-right: none
        .mu-ripple
          position: relative
          width: 100%
          height: 100%
          .icon-wrapper
            margin: 0 auto 0.1rem auto
            height: 0.76rem
            width: 0.76rem
            line-height: 0.76rem
            border-radius: 50%
            &.color1
              background-color: #ff4957
            &.color2
              background-color: #51b7dd
            &.color3
              background-color: #7e57c2
            &.color4
              background-color: #29c55b
            .icon
              line-height: 0.76rem
              font-size: 0.48rem
              color: #fff
          .item-name
            letter-spacing: 0.02rem
            color: #9fabb6
            font-size: 0.26rem

  .spnum
    position: absolute
    top: 0.01rem
    right: 2rem

</style>

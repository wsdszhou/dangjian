<template>
  <transition name="slide">
    <div class="index">
      <div class="wrapper">
        <v-header class="header" ref="header"></v-header>
        <transition :name="$store.getters.direction==='forward'?'pop-in':'pop-out'">
          <keep-alive>
            <router-view @mine-created="mineCreated" :style="'height:'+curheight+'px'"></router-view>
          </keep-alive>
        </transition>
        <num :message="allMessage" class="num"></num>
        <tab class="tab" ref="tab"></tab>
      </div>
    </div>
  </transition>
</template>

<script>
  import vHeader from 'components/header/header'
  import Tab from 'components/tab/tab'
  import Num from 'base/num/num'
  import {mapGetters} from 'vuex'

  export default {
    data() {
      return {
        curheight: 0
      }
    },
    created() {
      this.$nextTick(() => {
        this.curheight = window.innerHeight - this.$refs.header.$el.clientHeight - this.$refs.tab.$el.clientHeight
      })
    },
    methods: {
      mineCreated() {
        if (this.$refs.tab) {
          this.$refs.tab.changeNav()
        }
      },
      loaded() {
        if (!this.notFirst) {
          this.notFirst = true
        }
      }
    },
    computed: {
      ...mapGetters(['allMessage'])
    },
    components: {
      vHeader,
      Tab,
      Num
    }
  }
</script>

<style lang="stylus">
  .index
    position: absolute
    height: 100%
    width: 100%
    .wrapper
      position: relative
      height: 100%
      width: 100%
      overflow: hidden
    .header
      position: relative
    .num
      position: absolute
      bottom: 0.58rem
      right: 3rem

</style>

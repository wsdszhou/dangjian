<template>
  <transition name="slide">
    <div class="dep">
      <common-title title="我的支部" :back-path="backPath" class="common-title" ref="title"></common-title>
      <div class="divider"></div>
      <div class="detail">
        <div class="detail-wrapper clearfix">
          <div class="detail-main">
            <mu-load-more @refresh="loadRefresh"
                          :refreshing="refreshing">
              <div ref="headers">
                <div class="title">
                  <div class="line"></div>
                  <div class="text">{{info.zbMc }}</div>
                  <div class="line"></div>
                </div>
                <mu-paper class="items">
                  <div>
                    <mu-icon value="account_box" size="10px" class="icon" color="red"></mu-icon>
                    支部书记：{{info.sjxm }}
                  </div>
                  <div>
                    <mu-icon value="face" size="10px" class="icon" color="indigoA400"></mu-icon>
                    宣传委员：{{info.xcwyxm }}
                  </div>
                  <div>
                    <mu-icon value="person_pin_circle" size="10px" class="icon" color="yellow900"></mu-icon>
                    组织委员：{{ info.zzwyxm }}
                  </div>
                  <div>
                    <mu-icon value="radio_button_checked" size="10px" class="icon" color="lightBlueA400"></mu-icon>
                    支部类型：{{ info.zblxMc }}
                  </div>
                  <div>
                    <mu-icon value="brush" size="10px" class="icon" color="teal600"></mu-icon>
                    支部描述：{{info.zbMs }}
                  </div>
                </mu-paper>
                <div class="title">
                  <div class="line"></div>
                  <div class="text">支部荣誉</div>
                  <div class="line"></div>
                </div>
              </div>
            </mu-load-more>
            <div class="newremind">
              <scroll class="remind-content"
                      :showItem="showItem"
                      :itemsLoaded="itemsLoaded"
                      :exceedHeight="exceedHeight"
                      :pullUploading="pullUploading"
                      :notPullUploadOver="notPullUploadOver"
                      :loading="loading"
                      :scrollbar="scrollbar"
                      :pullUpLoad="pullUpLoad"
                      @clickrefresh="refresh"
                      @pullingUp="onPullingUp"
                      ref="scroll">
                <div>
                  <div class="info-wrapper">
                    <div class="item-wrapper"
                         v-for="(item) in items"
                         :key="item.name"
                         @click="getSingleBranchHonor(item.zbryId)">
                      <mu-ripple
                        color="#9e9e9e"
                        :opacity="0.6"
                        class="item mu-ripple">
                        <div class="numi">
                          <mu-icon value="golf_course" size="10px" class="icon" color="pink"></mu-icon>
                          荣誉：{{item.zbryMc}}
                        </div>
                        <div class="numi">
                          <mu-icon value="chrome_reader_mode" size="10px" class="icon" color="#43a047"></mu-icon>
                          简介：{{item.zbryJs}}
                        </div>
                        <div class="numi">
                          <mu-icon value="access_time" size="10px" class="icon" color="blue"></mu-icon>
                          时间：{{item.zbryHdsj}}
                        </div>
                      </mu-ripple>
                    </div>
                  </div>
                </div>
              </scroll>
            </div>
          </div>
          <div class="honor" v-if="honor">
            <honordetail :showit="honorShow"
                         :id="honorId"
                         type="branch"
                         @off-show="honorPageShow">
            </honordetail>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Scroll from 'base/scrollmore/scrollmore'
  import Confirm from 'components/exam/index/confirm/confirm'
  import Loader from 'base/loader/loader'
  import Honordetail from '../honordetail/honordetail'

  const NOITEMS = 1 // 成功获取数据但没有通知
  const ITEMSFAILED = 2 // 获取数据失败

  export default {
    data() {
      return {
        info: {},
        backPath: {name: 'mine'},
        items: [],
        page: 1,
        limit: 5,
        honorId: '',
        honor: false,
        honorShow: false,
        showItem: '', // 数据获取情况
        loading: false,
        itemsLoaded: false,
        itemsStatus: 0,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: 300
        },
        refreshing: false
      }
    },
    created() {
      this.$nextTick(() => {
        this.curheight = window.innerHeight - this.$refs.headers.clientHeight - this.$refs.title.$el.clientHeight
      })
      this.getBranchInfo()
      this.getBranchHonorPageList()
    },
    methods: {
      // 获取支部信息
      getBranchInfo() {
        this.$http.get('/branch/getBranchInfo').then((res) => {
          res = res.data
          if (res.error === 0) {
            this.info = res.data
          }
        }).catch()
      },
      // 获取支部荣誉列表
      getBranchHonorPageList(flag) {
        this.$http.get('/branch/getBranchHonorPageList', {
          params: {
            page: this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) { // 判断数据长度
              this.items = res.data
            } else {
              this.itemsStatus = NOITEMS
            }
          }
          if (this.items.length >= this.limit) {
            this.exceedHeight = true
          } else {
            this.notPullUploadOver = false
          }
          this.itemsLoaded = true
          this.showStatus()
          if (flag) {
            this.refreshing = false
          }
        }).catch(() => {
          if (flag) {
            this.refreshing = false
          }
          this.itemsStatus = ITEMSFAILED
        })
      },
      // 加载更多荣誉
      getMoreHonor() {
        this.$http.get('/branch/getBranchHonorPageList', {
          params: {
            page: ++this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      // 获取支部荣誉单条详细信息
      getSingleBranchHonor(id) {
        this.honorId = id
        this.honorPageShow()
      },
      // 荣誉详情页打开
      honorPageShow() {
        if (!this.honor) {
          this.honor = true
        }
        this.honorShow = !this.honorShow
      },
      // 下拉刷新
      loadRefresh() {
        this.refreshing = true
        this.getDeptInfo()
        this.getDeptHonorPageList(1)
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMoreHonor()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      // 根据数据状态显示信息
      showStatus() {
        if (this.itemsStatus === NOITEMS) {
          this.showItem = '暂无最新消息'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '获取数据失败'
        }
      },
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this.getBranchHonorPageList()
      },
      goTo(path) {
        this.$router.push(path)
      }
    },
    components: {
      CommonTitle,
      Scroll,
      Confirm,
      Loader,
      Honordetail
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .dep
    position: absolute
    top: 0
    bottom: 0
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    background-color: #fff
    .common-title
      position: fixed
      top: 0
    .divider
      position: relative
      width: 100%
      margin: auto
      padding-top: 0.8rem
    .items
      position: relative
      margin: 0.1rem 0.3rem
      padding: 0.2rem
      box-sizing: border-box
      background-color: #f2f2f2
      div
        font-size: 0.3rem
        padding: 0.1rem 0 0 0.1rem
        border-1px(rgba(7, 17, 27, 0.1))
        i
          vertical-align: bottom

    .detail
      z-index: 100
      width: 100%
      overflow: auto
      opacity: 1
      .detail-wrapper
        width: 100%
        min-height: 100%
        .detail-main
          .title
            display: flex
            width: 80%
            margin: 0 auto
            padding-top: 0.1rem
            .line
              flex: 1
              position: relative
              top: -6px
              border-bottom: 1px solid #ee2728
            .text
              color: #ee2728
              padding: 0 12px
              font-weight: 700
              font-size: 14px

  .newremind
    position: relative
    margin: 0 0.3rem 0 0.3rem
    height: 6.9rem
    z-index: 10
    font-size: 0
    background-color: #f2f2f2t

  .remind-content
    position: relative
    height: 97%
    overflow: hidden
    .info-wrapper
      box-sizing: border-box
      width: 100%
      height: 100%
      overflow: hidden
      .item-wrapper
        margin: 0.1rem 0.12rem 0.2rem 0.12rem
        .item
          padding: 0.2rem
          box-sizing: border-box
          border-radius: 5px
          box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
          background: #fff
          div
            border-1px(rgba(7, 17, 27, 0.1))
        .mu-ripple
          position: relative
          padding-top: 0.32rem
          display: inline-block
          width: 100%
          .numi
            max-height: 1.5rem
            overflow: hidden
            text-overflow: ellipsis
            white-space: nowrap
          div
            min-height: 0.5rem
            line-height: 0.5rem
            padding-bottom: 0.06rem
            font-size: 0.3rem
            font-family: 'Microsoft YaHei'
            .icon
              vertical-align: bottom
</style>

<template>
  <transition name="slide">
    <div class="dep">
      <common-title title="支部用户列表" :back-path="backPath" class="title"></common-title>
      <mu-container ref="container">
        <mu-load-more @refresh="loadrefresh" :refreshing="refreshing">
          <div class="detail">
            <div class="detail-wrapper clearfix">
              <div class="detail-main">
                <div class="newremind">
                  <scroll class="remind-content"
                          :showItem="showItem"
                          :itemsLoaded="itemsLoaded"
                          :exceedHeight="exceedHeight"
                          :pullUploading="pullUploading"
                          :notPullUploadOver="notPullUploadOver"
                          :loading="loading"
                          :scrollbar="scrollbar"
                          :pullUpLoad="pullUpLoad"
                          @clickrefresh="refresh"
                          @pullingUp="onPullingUp"
                          ref="scroll">
                    <div>
                      <div class="info-wrapper">
                        <div class="item-wrapper"
                             v-for="(item) in items"
                             :key="item.name"
                             @click="getSingleDeptHonor(item.bmryId)">
                          <mu-ripple
                            color="#9e9e9e"
                            :opacity="0.6"
                            class="item mu-ripple">
                            <div class="numi">
                              <mu-icon value="person" size="10px" class="icon" color="red"></mu-icon>
                              {{item.dnzwMc}}：{{item.yhxxXm}}
                            </div>
                          </mu-ripple>
                        </div>
                      </div>
                    </div>
                  </scroll>
                </div>
              </div>
            </div>
          </div>
        </mu-load-more>
      </mu-container>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Scroll from 'base/scrollmore/scrollmore'
  import Confirm from 'components/exam/index/confirm/confirm'
  import Loader from 'base/loader/loader'

  const NOITEMS = 1 // 成功获取数据但没有通知
  const ITEMSFAILED = 2 // 获取数据失败

  export default {
    data() {
      return {
        info: {},
        backPath: {name: 'mine'},
        items: [],
        page: 1,
        limit: 15,
        honorShow: false,
        honorDetail: {},
        showItem: '', // 数据获取情况
        loading: false,
        itemsLoaded: false,
        itemsStatus: 0,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        },
        refreshing: false
      }
    },
    created() {
      this.getBranchUser()
    },
    methods: {
      // 获取部门用户列表
      getBranchUser(flag) {
        this.$http.get('/branch/getBranchUser', {
          params: {
            page: this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) { // 判断数据长度
              this.items = res.data
            } else {
              this.itemsStatus = NOITEMS
            }
          }
          if (flag) {
            this.refreshing = false
          }
          if (this.items.length >= this.limit) {
            this.exceedHeight = true
          } else {
            this.notPullUploadOver = false
          }
          this.itemsLoaded = true
          this.showStatus()
        }).catch(() => {
          if (flag) {
            this.refreshing = false
          }
          this.itemsStatus = ITEMSFAILED
        })
      },
      // 加载更多荣誉
      getMoreUser() {
        this.$http.get('/dept/getBranchUser', {
          params: {
            page: ++this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      loadrefresh() {
        this.refreshing = true
        this.$refs.container.scrollTop = 0
        this.getBranchUser(1)
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMoreHonor()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      showHonor() {
        this.honorShow = !this.honorShow
      },
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this.getMoreUser()
      },
      goTo(path) {
        this.$router.push(path)
      }
    },
    components: {
      CommonTitle,
      Scroll,
      Confirm,
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .dep
    position: absolute
    top: 0
    bottom: 0
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    background-color: #fff

    .detail
      z-index: 100
      width: 100%
      overflow: auto
      opacity: 1
      .detail-wrapper
        width: 100%
        min-height: 100%
        .detail-main
          margin-top: 0.1rem
          .name
            line-height: 16px
            text-align: center
            font-size: 16px
            font-weight: 700
          .title
            display: flex
            width: 80%
            margin: 0.3rem auto 0 auto
            .line
              flex: 1
              position: relative
              top: -6px
              border-bottom: 1px solid #ee2728
            .text
              color: #ee2728
              padding: 0 12px
              font-weight: 700
              font-size: 14px

  .newremind
    position: relative
    margin: 0.2rem
    height: 100%
    z-index: 10
    font-size: 0
    background-color: #f2f2f2

  .remind-content
    position: relative
    height: 100%
    overflow: hidden
    .info-wrapper
      box-sizing: border-box
      width: 100%
      height: 100%
      overflow: hidden
      .item-wrapper
        margin: 0.1rem 0.12rem 0.1rem 0.12rem
        .item
          padding: 0.1rem
          box-sizing: border-box
          border-radius: 5px
          box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
          background: #fff
        .mu-ripple
          position: relative
          padding-top: 0.12rem
          display: inline-block
          width: 100%
          div
            min-height: 0.5rem
            line-height: 0.5rem
            font-size: 0.28rem
            font-family: 'Microsoft YaHei'
            .icon
              vertical-align: bottom
</style>

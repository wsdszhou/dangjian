<template>
  <transition name="slide">
    <div class="dj-detail" v-show="showit">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">荣誉详情</span>
      </div>
      <div class="divider"></div>
      <mu-paper class="item" v-if="type==='dep'">
        <div class="numi">
          <mu-icon value="golf_course" size="10px" class="icon" color="pink"></mu-icon>
          荣誉：{{info.bmryMc}}
        </div>
        <div class="numi">
          <mu-icon value="access_time" size="10px" class="icon" color="blue"></mu-icon>
          时间：{{info.bmryHdsj}}
        </div>
        <div class="numi">
          <img
            :src="url+info.bmryTp"
            class="img">
        </div>
        <div class="numi">
          <mu-icon value="chrome_reader_mode" size="10px" class="icon" color="#43a047"></mu-icon>
          简介：{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}{{info.bmryJs}}
        </div>
      </mu-paper>
      <mu-paper class="item" v-else>
        <div class="numi">
          <mu-icon value="golf_course" size="10px" class="icon" color="pink"></mu-icon>
          荣誉：{{info.zbryMc}}
        </div>
        <div class="numi">
          <mu-icon value="access_time" size="10px" class="icon" color="blue"></mu-icon>
          时间：{{info.zbryHdsj}}
        </div>
        <div class="numi">
          <img
            :src="url+info.zbryTp"
            class="img">
        </div>
        <div class="numi">
          <mu-icon value="chrome_reader_mode" size="10px" class="icon" color="#43a047"></mu-icon>
          简介：{{info.zbryJs}}
        </div>
      </mu-paper>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'
  import {URL} from 'common/js/config'

  export default {
    data() {
      return {
        info: {},
        url: URL
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      id: {
        type: Number,
        default() {
          return ''
        }
      },
      type: {
        type: String,
        default() {
          return 'dep'
        }
      }
    },
    created() {
      this.init()
    },
    methods: {
      // 获取新闻
      init() {
        let id = this.id
        this.getSingleDeptHonor(id)
      },
      // 获取部门荣誉单条详细信息
      getSingleDeptHonor(id) {
        let url = '/dept/getSingleDeptHonor'
        if (this.type === 'branch') {
          url = '/branch/getSingleBranchHonor'
        }
        this.$http.get(url, {
          params: {
            honorId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.info = res.data
          }
        }).catch()
      },
      back() {
        this.$emit('off-show')
      }
    },
    watch: {
      'id': function () {
        this.info = ''
        this.init()
      }
    },
    components: {
      Scroll
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .dj-detail
    position: absolute
    top: 0
    left: 0
    width: 100%
    min-height: 100%
    overflow: hidden
    font-size: 0.3rem
    background-color: #fff
    z-index: 10000

  .item
    position: relative
    margin: 0.12rem
    padding: 0.2rem
    box-sizing: border-box
    box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
    background: #fff
    div
      font-size: 0.3rem
      padding: 0.1rem 0 0 0.1rem
      border-1px(rgba(7, 17, 27, 0.1))
      i
        vertical-align: bottom

  .common-title
    position: fixed
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem

  .divider
    position: relative
    width: 100%
    margin: auto
    padding-top: 0.8rem

</style>

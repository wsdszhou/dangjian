<template>
  <transition name="slide">
    <div class="info">
      <common-title :title="titlename" :back-path="backPath" class="title"></common-title>
      <mu-container ref="container">
        <mu-load-more @refresh="refresh" :refreshing="refreshing">
          <mu-paper class="item">
            <div>
              <mu-icon value="account_box" size="10px" class="icon" color="red"></mu-icon>
              姓名：{{info.yhxxXm }}
            </div>
            <div>
              <mu-icon value="face" size="10px" class="icon" color="indigoA400"></mu-icon>
              性别：{{info.yhxxXb }}
            </div>
            <div>
              <mu-icon value="person_pin_circle" size="10px" class="icon" color="yellow900"></mu-icon>
              民族：{{ info.mzMc }}
            </div>
            <div>
              <mu-icon value="school" size="10px" class="icon" color="indigo800"></mu-icon>
              学历：{{ info.xlMc }}
            </div>
            <div>
              <mu-icon value="forward" size="10px" class="icon" color="pink300"></mu-icon>
              年级：{{info.yhxxMj }}
            </div>
            <div>
              <mu-icon value="radio_button_checked" size="10px" class="icon" color="lightBlueA400"></mu-icon>
              用户状态：{{ info.userZtMc }}
            </div>
            <div>
              <mu-icon value="location_on" size="10px" class="icon" color="deepPurple400"></mu-icon>
              所属学院：{{ info.bmMc }}
            </div>
            <div>
              <mu-icon value="domain" size="10px" class="icon" color="cyan500"></mu-icon>
              支部：{{info.zbMc }}
            </div>
            <div>
              <mu-icon value="brush" size="10px" class="icon" color="teal600"></mu-icon>
              支部描述：{{info.zbMs }}
            </div>
            <div>
              <mu-icon value="person_pin" size="10px" class="icon" color="green500"></mu-icon>
              政治面貌：{{info.zzmmMc }}
            </div>
            <div>
              <mu-icon value="settings" size="10px" class="icon" color="orange600"></mu-icon>
              党内职务：{{ info.dnzwMc }}
            </div>
            <div>
              <mu-icon value="work" size="10px" class="icon" color="brown500"></mu-icon>
              行政职务：{{info.xzzwMc }}
            </div>
            <div>
              <mu-icon value="all_inclusive" size="10px" class="icon" color="green600"></mu-icon>
              用户名：{{ info.userMc }}
            </div>
            <div>
              <mu-icon value="phonelink_ring" size="10px" class="icon" color="lightGreen800"></mu-icon>
              手机号码：{{info.yhxxSjh }}
              <mu-badge content="修改" class="modify" color="red" @click="modifyPageShow"></mu-badge>
            </div>
            <div>
              <mu-icon value="email" size="10px" class="icon" color="blueGrey600"></mu-icon>
              邮箱：{{info.yhxxYx }}
              <mu-badge content="修改" class="modify" color="red" @click="modifyPageShow"></mu-badge>
            </div>
            <div>
              <mu-icon value="perm_identity" size="10px" class="icon" color="teal900"></mu-icon>
              身份证号：{{info.yhxxSfzh }}
            </div>
            <div>
              <mu-icon value="call" size="10px" class="icon" color="redA400"></mu-icon>
              电话号码：{{info.yhxxDhhm }}
              <mu-badge content="修改" class="modify" color="red" @click="modifyPageShow"></mu-badge>
            </div>
          </mu-paper>
        </mu-load-more>
      </mu-container>
      <div class="modify" v-if="modify">
        <modify :showit="modifyShow"
                userid="ysh"
                :call="info.yhxxDhhm"
                :phone="info.yhxxSjh"
                :mail="info.yhxxYx"
                @off-show="modifyShowoff">
        </modify>
      </div>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Modify from './modify'

  export default {
    data() {
      return {
        titlename: '个人信息',
        info: {},
        backPath: {name: 'mine'},
        refreshing: false,
        modifyShow: false,
        modify: false,
        userid: ''
      }
    },
    methods: {
      getInfo() {
        this.$http.get('/user/info').then((res) => {
          res = res.data
          if (res.error === 0) {
            this.info = res.data
            this.userid = this.info.userId
          }
        }).catch()
      },
      goTo(path) {
        this.$router.push(path)
      },
      refresh() {
        this.refreshing = true
        this.$refs.container.scrollTop = 0
        this.$http.get('/user/info').then((res) => {
          res = res.data
          if (res.error === 0) {
            this.info = res.data
            this.refreshing = false
          }
        }).catch(() => {
          this.refreshing = false
        })
      },
      // 修改个人信息页面显示
      modifyPageShow() {
        if (!this.modify) {
          this.modify = true
        }
        this.modifyShow = true
      },
      modifyShowoff() {
        this.modifyShow = false
      }
    },
    created() {
      this.getInfo()
    },
    components: {
      CommonTitle,
      Modify
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .info
    position: absolute
    top: 0
    bottom: 0
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    background-color: #ececec
    .item
      position: relative
      margin: 0.12rem
      padding: 0.2rem
      box-sizing: border-box
      box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
      background: #fff
      div
        font-size: 0.3rem
        padding: 0.1rem 0 0 0.1rem
        border-1px(rgba(7, 17, 27, 0.1))
        i
          vertical-align: bottom

  .modify
    float: right
</style>

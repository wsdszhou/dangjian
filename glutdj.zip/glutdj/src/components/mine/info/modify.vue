<template>
  <transition name="slide">
    <div class="dj-detail" v-show="showit">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">修改个人信息</span>
      </div>
      <div class="item">
        <mu-form ref="form" :model="validateForm">
          <mu-form-item label="手机号">
            <mu-text-field v-model="validateForm.yhxxSjh"></mu-text-field>
          </mu-form-item>
          <mu-form-item label="邮箱">
            <mu-text-field v-model="validateForm.yhxxYx"></mu-text-field>
          </mu-form-item>
          <mu-form-item label="电话号">
            <mu-text-field v-model="validateForm.yhxxDhhm"></mu-text-field>
          </mu-form-item>
        </mu-form>
        <div class="button">
          <mu-button color="red" round @click="submit">保存修改</mu-button>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'

  export default {
    data() {
      return {
        info: {},
        praiseNum: 0,
        validateForm: {
          userId: this.userid,
          yhxxSjh: this.phone,
          yhxxYx: this.mail,
          yhxxDhhm: this.call
        }
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      id: {
        type: String,
        default() {
          return ''
        }
      },
      call: {
        type: String,
        default() {
          return ''
        }
      },
      phone: {
        type: String,
        default() {
          return ''
        }
      },
      mail: {
        type: String,
        default() {
          return ''
        }
      },
      userid: {
        type: String,
        default() {
          return ''
        }
      }
    },
    methods: {
      // 提交
      submit() {
        let obj = this.validateForm
        this.$http({
          method: 'post',
          url: '/user/updateUser',
          data: obj,
          transformRequest: [function (data) {
            // Do whatever you want to transform the data
            let ret = ''
            for (let it in data) {
              ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
            }
            return ret
          }],
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
          } else {
            this.$toast.error(res.msg)
          }
        }).catch(() => {
        })
      },
      back() {
        this.$emit('off-show')
      }
    },
    watch: {
      'id': 'init'
    },
    components: {
      Scroll
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .dj-detail
    position: fixed
    top: 0
    left: 0
    width: 100%
    height: 100%
    overflow: hidden
    font-size: 0.3rem
    background-color: #fff

  .item
    position: relative
    margin: 0.12rem
    padding: 0.2rem
    box-sizing: border-box
    background: #fff

  .common-title
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem

  .button
    text-align: center
    .mu-button
      margin-top: 0.25rem
</style>

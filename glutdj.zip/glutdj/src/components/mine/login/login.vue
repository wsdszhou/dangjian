<template>
  <div class="login">
    <div class="login-wrapper">
      <div class="header">
        <mu-appbar style="width: 100%;height: 100%;" color="#ee2728" class="v-header">
          <mu-avatar size="33" slot="left" class="avatar">
            <img class="img" src='../../../common/image/gluticon.png'>
          </mu-avatar>
          <span class="title">智慧党建系统</span>
          <mu-button flat slot="right" @click="goToMine">
            <mu-icon value="close"></mu-icon>
          </mu-button>
        </mu-appbar>
      </div>
      <div class="login-main">
        <div class="login-logo"><img src="../../../common/image/LOGO.png"></div>
        <div class="login_top"><span>账户登录</span></div>
        <div class="login_middle"></div>
        <mu-container>
          <mu-form ref="form" :model="validateForm">
            <mu-form-item label="用户名" prop="username" :rules="usernameRules">
              <mu-text-field v-model="validateForm.username" prop="username"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="密码" prop="password" :rules="passwordRules">
              <mu-text-field type="password" v-model="validateForm.password" prop="password"></mu-text-field>
            </mu-form-item>
            <div class="authcode-form">
              <mu-form-item class="authcode-label" label="验证码" prop="authcode" :rules="codeRules">
                <mu-text-field v-model="validateForm.authcode" prop="authcode"></mu-text-field>
              </mu-form-item>
              <div class="authcode" @click="_getCodePath">
                <span><img :src="authcodepath" width="100px"></span>
                <span class="refresh">点击刷新</span>
              </div>
            </div>
            <mu-form-item class="form-item">
              <mu-button @click="clear">重置</mu-button>
              <mu-button color="red" @click="login">提交</mu-button>
            </mu-form-item>
          </mu-form>
        </mu-container>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapActions} from 'vuex'
  import {URL} from 'common/js/config'

  export default {
    data() {
      return {
        authcodepath: '',
        usernameRules: [
          {validate: (val) => !!val, message: '必须填写用户名'}
        ],
        passwordRules: [
          {validate: (val) => !!val, message: '必须填写密码'}
        ],
        codeRules: [
          {validate: (val) => !!val, message: '必须填写验证码'}
        ],
        validateForm: {
          username: 'ysh',
          password: '123',
          authcode: ''
        }
      }
    },
    methods: {
      ...mapActions({
        // 设置为已登录状态
        setToken: 'SET_TOKEN',
        setAvatar: 'SET_AVATAR',
        setUsername: 'SET_USERNAME',
        setAllMessage: 'SET_ALLMESSAGE', // 设置所有通知
        setAllspMessage: 'SET_ALLSPMESSAGE' // 设置所有审批通知
      }),
      _getCodePath() {
        this.$http
          .get('/validateCode', {
            responseType: 'arraybuffer',
            crossDomain: true
          })
          .then(res => {
            let codeImg = 'data:image/png;base64,' + btoa(
              new Uint8Array(res.data).reduce((data, byte) => data + String.fromCharCode(byte), '')
            )
            this.authcodepath = codeImg
          })
      },
      // 获取用户通知数量
      getALLMessage() {
        this.$http.get('/notice/getNoticeNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllMessage(res.data)
              }
            }
          }).catch(() => {
        })
      },
      // 获取用户审批数量
      getALLspMessage() {
        this.$http.get('/approval/getApprovalNum')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                this.setAllspMessage(res.data)
              }
            }
          }).catch(() => {
        })
      },
      // 获取用户头像
      getUserPicture() {
        this.$http.get('/user/getUserPicture')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                let url = URL + res.data
                this.setAvatar(url)
              } else {
                this.setAvatar(`${URL}/dangjian-controller/upload/images/user/default-avatar.jpg`)
              }
            }
          }).catch(() => {
        })
      },
      login() {
        const loading = this.$loading()
        let obj = this.validateForm
        this.$http({
          method: 'post',
          url: '/login',
          data: obj
        })
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              window.localStorage.setItem('token', 'logged')
              this.setToken()
              this.setUsername(res.data.userMc)
              this.getALLMessage()
              this.getALLspMessage()
              this.$toast.success('登录成功')
              this.goToMine()
            } else {
              this._getCodePath()
              this.$toast.error(res.msg)
            }
            loading.close()
          })
          .catch(() => {
            this._getCodePath()
            loading.close()
          })
      },
      goToMine() {
        this.$router.push({name: 'mine'})
      },
      clear() {
        this.$refs.form.clear()
        this.validateForm = {
          username: '',
          password: ''
        }
      }
    },
    created() {
      this._getCodePath()
    },
    beforeRouteEnter(to, from, next) {
      if (window.localStorage.token === 'logged') {
        next(vm => {
          vm.$toast.warning('您已登录')
          vm.$router.push({name: 'mine'})
        })
      } else {
        next()
      }
    }
  }
</script>

<style scoped lang="stylus">
  .login
    position: absolute
    top: 0
    height: 100%
    width: 100%
    background: rgba(7, 17, 27, 0.4)
    font-size: 0
    .login-wrapper
      height: 100%
      width: 100%
      border-radius: 0.1rem
      background: #fff
      font-size: 0.38rem
      .login-main
        width: 100%
        .login-logo
          text-align: center
          background: url("../../../common/image/topLogo.jpg")
          background-size: 100% 100%;
          box-shadow: 0 3px 1px -2px rgba(0, 0, 0, .2), 0 2px 2px 0 rgba(0, 0, 0, .14), 0 1px 5px 0 rgba(0, 0, 0, .12)
        .login_top
          height: 55px
          font-size: 18px
          border-bottom: 1px solid #f4f4f4
          position: relative
          background: #fff
          span
            color: #e4393c
            font-weight: 700
            position: absolute
            top: 30%
            right: 40%

  .authcode-form
    display: flex
    .authcode-label
      flex: 0 1 2.2rem
      margin-right: 1.2rem
    .authcode
      margin-top: 0.3rem
      .refresh
        vertical-align: bottom
        color: rgba(0, 0, 0, .54)
        font-size: 0.25rem

  .form-item
    margin: 1rem 0 0 2rem

  .header
    position: relative
    width: 100%
    height: 0.7rem
    line-height: 0.7rem
    font-size: 0.25rem
    .avatar
      margin: 0
      .img
        color: #ee2728
    .title
      font-size: 0.32rem
</style>

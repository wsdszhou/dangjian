<template>
  <div class="mine">
    <div class="wrapper">
      <div class="top">
        <div v-if="!noToken" class="login" @click="goToLogin"><span>请登录</span></div>
        <div v-if="noToken" class="logout">
          <mu-avatar size="100" @click="showAvatar">
            <img :src="avatar">
          </mu-avatar>
          <span @click="goOutToLogin">注销</span>
        </div>
      </div>
      <div class="info-wrapper">
        <router-link tag="div" v-for="info in infos" :key="info.name" class="item" :to="info.to">
          <mu-ripple class="mu-ripple" color="#9e9e9e" :opacity="0.2">
            <div class="icon-wrapper" :class="info.color">
              <mu-icon class="icon" :value="info.icon" size="19"></mu-icon>
            </div>
            <span class="name">{{ info.name }}</span>
            <mu-icon class="chevron" value="chevron_right"></mu-icon>
          </mu-ripple>
        </router-link>
      </div>
      <mu-fade-transition>
        <div class="scale" v-show="avatarShow">
          <mu-scale-transition>
            <div class="scale-avatar" v-show="avatarShow">
              <img :src="avatar" width="200px" height="200px" onerror="this.src='./static/QQ头像.jpg'">
            </div>
          </mu-scale-transition>
          <div class="avatar-close">
            <mu-icon value="close" color="white" @click="showAvatar"></mu-icon>
          </div>
        </div>
      </mu-fade-transition>
    </div>
  </div>
</template>

<script>
  import {mapGetters, mapActions} from 'vuex'
  import {URL} from 'common/js/config'

  export default {
    data() {
      return {
        myData: [],
        infos: [
          {name: '个人信息', to: '/mine/info', color: 'color1', icon: 'data_usage'},
          {name: '我的部门', to: '/mine/dep', color: 'color2', icon: 'domain'},
          {name: '我的支部', to: '/mine/branch', color: 'color3', icon: 'location_on'},
          {name: '支部用户', to: '/mine/branchuser', color: 'color4', icon: 'person'},
          {name: '党籍管理', to: '/mine/party', color: 'color5', icon: 'location_on'},
          {name: '修改密码', to: '/mine/modifier', color: 'color6', icon: 'lock'},
          {name: '上传头像', to: '/mine/upload', color: 'color7', icon: 'cloud_upload'}
        ],
        avatarShow: false,
        avatarurl: ''
      }
    },
    created() {
      this.init()
    },
    methods: {
      ...mapActions({
        deleteToken: 'DELETE_TOKEN',
        deleteUsername: 'DELETE_USERNAME',
        setAvatar: 'SET_AVATAR',
        setExamId: 'SET_EXAMID'
      }),
      init() {
        if (!this.avatar) {
          this.getUserPicture()
        }
        this.$emit('mine-created') // 登录首页->登录->页面回跳到个人中心时，底部导航重新获取路由
      },
      // 获取用户头像
      getUserPicture() {
        this.$http.get('/user/getUserPicture')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              if (res.data) {
                let url = URL + res.data
                this.setAvatar(url)
              } else {
                this.setAvatar(`${URL}/dangjian-controller/upload/images/user/default-avatar.jpg`)
              }
            }
          }).catch(() => {
        })
      },
      showAvatar() {
        this.avatarShow = !this.avatarShow
      },
      goToLogin() {
        this.$router.push({name: 'login'})
      },
      goOutToLogin() {
        this.$http.post('/logout')
        this.deleteToken()
        this.deleteUsername()
        window.localStorage.setItem('token', 'unlogged')
        this.$toast.success('已退出登录')
        this.setExamId(0)
      }
    },
    computed: {
      ...mapGetters({
        noToken: 'token',
        avatar: 'avatar'
      })
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .mine
    position: absolute
    width: 100%
    .wrapper
      position: relative
      width: 100%
      .top
        position: relative
        width: 100%
        height: 4rem
        background-size: 100% 4rem
        background-repeat: no-repeat
        background-image: url("../../common/image/mine.png")
        .login
          position: absolute
          top: 0
          bottom: 0
          left: 0
          right: 0
          margin: auto
          height: 0.5rem
          width: 4rem
          text-align: center
          font-size: 0.36rem
          color: white
          span
            display: block
        .logout
          margin: 0 auto
          padding-top: 0.45rem
          height: 0.5rem
          width: 4rem
          text-align: center
          font-size: 0.36rem
          color: white
          span
            display: block
      .info-wrapper
        width: 100%
        .item
          width: 100%
          height: 0.8rem
          line-height: 1.5
          background: #fff
          border-radius: 2px
          border-1px(rgba(7, 17, 27, 0.1))
          box-shadow: 0 3px 1px -2px rgba(0, 0, 0, .2), 0 2px 2px 0 rgba(0, 0, 0, .14), 0 1px 5px 0 rgba(0, 0, 0, .12)
          .mu-ripple
            position: relative
            height: 0.8rem
            line-height: 1
            box-sizing: border-box
            padding: 0.16rem 0
            width: 100%
            .icon-wrapper
              display: inline-block
              vertical-align: top
              margin: 0 0.14rem 0 0.2rem
              width: 0.5rem
              height: 0.5rem
              line-height: 0.5rem
              text-align: center
              border-radius: 50%
              &.color1
                background-color: #51b7dd
              &.color2
                background-color: #d4d14e
              &.color3
                background-color: #ff4957
              &.color4
                background-color: #01cf29
              &.color5
                background-color: #51b7dd
              &.color6
                background-color: #d4d14e
              &.color7
                background-color: #9b0ed4
              .icon
                line-height: 0.5rem
                color: #fff
            .name
              display: inline-block
              vertical-align: top
              padding-top: 0.1rem
              font-size: 0.28rem
              font-family: 'Microsoft YaHei'
            .chevron
              position: absolute
              top: 0.17rem
              right: 0.4rem
      .scale
        position: fixed
        z-index: 10000
        top: 0
        left: 0
        width: 100%
        height: 100%
        overflow: auto
        opacity: 1
        background: rgba(7, 17, 27, 0.8)
        .scale-avatar
          position: absolute
          top: 0
          bottom: 0
          left: 0
          right: 0
          margin: auto
          height: 200px
          width: 200px
          text-align: center
          font-size: 0.36rem
          color: white
        .avatar-close
          position: absolute
          bottom: 0
          left: 0
          right: 0
          width: 32px
          height: 32px
          margin: 0 auto 1rem auto
          font-size: 32px
</style>

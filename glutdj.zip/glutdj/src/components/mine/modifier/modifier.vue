<template>
  <div class="modifier">
    <div class="modifier-wrapper">
      <div class="header">
        <mu-appbar style="width: 100%;height: 100%;" color="#ee2728" class="v-header">
          <mu-avatar size="33" slot="left" class="avatar">
            <img class="img" src='../../../common/image/gluticon.png'>
          </mu-avatar>
          <span class="title">智慧党建系统</span>
          <mu-button flat slot="right" @click="goToMine">
            <mu-icon value="close"></mu-icon>
          </mu-button>
        </mu-appbar>
      </div>
      <div class="login-main">
        <div class="login-logo"><img src="../../../common/image/LOGO.png"></div>
        <div class="login_top"><span>修改密码</span></div>
        <div class="login_middle"></div>
        <mu-container>
          <mu-form ref="form" :model="validateForm">
            <mu-form-item label="旧密码" prop="oldPassword" :rules="oldPasswordRules">
              <mu-text-field type="password" v-model="validateForm.oldPassword" prop="oldPassword"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="密码" prop="newPassword" :rules="newPasswordRules">
              <mu-text-field type="password" v-model="validateForm.newPassword" prop="newPassword"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="确认密码" prop="confiremNewPassword" :rules="confiremNewPasswordRules">
              <mu-text-field type="password" v-model="validateForm.confiremNewPassword"
                             prop="confiremNewPassword"></mu-text-field>
            </mu-form-item>
            <mu-form-item class="form-item">
              <mu-button @click="clear">重置</mu-button>
              <mu-button color="red" @click="modify">提交</mu-button>
            </mu-form-item>
          </mu-form>
        </mu-container>
      </div>
    </div>
  </div>
</template>

<script>

  export default {
    data() {
      return {
        oldPasswordRules: [
          {validate: (val) => !!val, message: '必须填写旧密码'}
        ],
        newPasswordRules: [
          {validate: (val) => !!val, message: '必须填写新密码'}
        ],
        confiremNewPasswordRules: [
          {validate: (val) => val === this.validateForm.newPassword, message: '与原密码不一致'}
        ],
        validateForm: {
          oldPassword: '',
          newPassword: '',
          confiremNewPassword: ''
        }
      }
    },
    methods: {
      modify() {
        let obj = this.validateForm
        if (obj.oldPassword === obj.newPassword) {
          this.$message.alert('新密码不能与当前密码相同', '错误')
        } else if (obj.newPassword !== obj.confiremNewPassword) {
          this.$message.alert('新密码与确认密码不相同', '错误')
        } else {
          const loading = this.$loading()
          this.$http({
            method: 'post',
            url: '/user/validatePassword',
            data: {
              oldPassword: obj.oldPassword,
              newPassword: obj.newPassword
            }
          })
            .then((res) => {
              res = res.data
              if (res.error === 0) {
                this.$toast.success('修改成功')
                this.goToMine()
              } else {
                this.$toast.error(res.msg)
              }
              loading.close()
            })
            .catch(() => {
              loading.close()
            })
        }
      },
      goToMine() {
        this.$router.push({name: 'mine'})
      },
      clear() {
        this.$refs.form.clear()
        this.validateForm = {
          username: '',
          password: ''
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  .modifier
    position: absolute
    top: 0
    height: 100%
    width: 100%
    background: rgba(7, 17, 27, 0.4)
    font-size: 0
    .modifier-wrapper
      height: 100%
      width: 100%
      border-radius: 0.1rem
      background: #fff
      font-size: 0.38rem
      .login-main
        width: 100%
        .login-logo
          text-align: center
          background: url("../../../common/image/topLogo.jpg")
          background-size: 100% 100%;
          box-shadow: 0 3px 1px -2px rgba(0, 0, 0, .2), 0 2px 2px 0 rgba(0, 0, 0, .14), 0 1px 5px 0 rgba(0, 0, 0, .12)
        .login_top
          height: 55px
          font-size: 18px
          border-bottom: 1px solid #f4f4f4
          position: relative
          background: #fff
          span
            color: #e4393c
            font-weight: 700
            position: absolute
            top: 30%
            right: 40%

  .authcode-form
    display: flex
    .authcode-label
      flex: 0 1 2.2rem
      margin-right: 1.2rem
    .authcode
      margin-top: 0.3rem
      .refresh
        vertical-align: bottom
        color: rgba(0, 0, 0, .54)
        font-size: 0.25rem

  .form-item
    margin: 1rem 0 0 2rem

  .header
    position: relative
    width: 100%
    height: 0.7rem
    line-height: 0.7rem
    font-size: 0.25rem
    .avatar
      margin: 0
      .img
        color: #ee2728
    .title
      font-size: 0.32rem
</style>

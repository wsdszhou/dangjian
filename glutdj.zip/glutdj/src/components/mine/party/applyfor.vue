<template>
  <transition name="slide">
    <div class="page" v-show="showit">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">申请</span>
      </div>
      <div class="page-content">
        <mu-container v-if="!infoLoaded">
          <mu-row gutter>
            <mu-col span="12" lg="4" sm="6">
              <mu-select label="部门名称" v-model="inData.bmdm" full-width>
                <mu-option v-for="option in depOptions" :key="option.option" :label="option.option"
                           :value="option.id"></mu-option>
              </mu-select>
            </mu-col>
            <mu-col span="12" lg="4" sm="6">
              <mu-select label="支部名称" v-model="inData.zbdm" full-width>
                <mu-option v-for="option in zbOptions" :key="option.option" :label="option.option"
                           :value="option.id"></mu-option>
              </mu-select>
            </mu-col>
            <mu-col span="12" lg="4" sm="6">
              <mu-select label="政治面貌" v-model="inData.zzmmdm" full-width>
                <mu-option v-for="option in zzmmOptions" :key="option.option" :label="option.option"
                           :value="option.id"></mu-option>
              </mu-select>
            </mu-col>
            <mu-col span="12" lg="4" sm="6">
              <mu-select label="党内职务" v-model="inData.dnzwdm" full-width>
                <mu-option v-for="option in dnzwOptions" :key="option.option" :label="option.option"
                           :value="option.id"></mu-option>
              </mu-select>
            </mu-col>
            <mu-col span="12" lg="4" sm="6">
              <mu-date-input v-model="date" label="入党时间" label-float full-width no-display></mu-date-input>
            </mu-col>
          </mu-row>
        </mu-container>
        <mu-container v-if="infoLoaded">
          <mu-form :model="outData">
            <mu-form-item label="转出地点">
              <mu-text-field v-model="outData.zcdd"></mu-text-field>
            </mu-form-item>
          </mu-form>
        </mu-container>
        <div class="button">
          <mu-button full-width color="red" @click="submit">提交</mu-button>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {
        depOptions: [],
        zzmmOptions: [],
        zbOptions: [],
        dnzwOptions: [],
        confirmpage: false, // 显示党籍确认信息
        showFlag: false, // 显示党籍确认信息
        inData: {
          zt: 2, // 状态为2则是转出状态
          id: '',
          bmdm: '',
          zbdm: '',
          zzmmdm: '',
          dnzwdm: '',
          rdsj: '',
          ms: ''
        },
        outData: {
          id: '',
          zcdd: '' // 转出地点
        },
        date: ''
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      infoLoaded: { // 判断是否有党籍了，如有则为true
        type: Boolean,
        default() {
          return true
        }
      },
      djid: {
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.outOrIn()
      this.getAllDep()
      this.getAllPoliticsState()
      this.getAllPartyJob()
    },
    methods: {
      // 判断转入或转出
      outOrIn() {
        if (!this.infoLoaded) {
          this.$set(this.inData, 'id', '')
        }
      },
      show() {
        this.showFlag = true
      },
      showOff() {
        this.showFlag = false
      },
      // 回调函数
      reMethod(res, name) {
        res = res.data
        if (res.error === 0) {
          let data = res.data
          if (res.data.length) {
            let options = []
            data.forEach((item) => {
              let obj = {
                option: item[`${name}Mc`],
                id: item[`${name}Id`]
              }
              options.push(obj)
            })
            return options
          }
        }
      },
      // 获取全部部门
      getAllDep() {
        this.$http.get('/common/getAllDepartment')
          .then((res) => {
            this.depOptions = this.reMethod(res, 'bm')
            this.getBranchListByDeptId(this.inData.bmdm)
          }).catch()
      },
      // 获取政治面貌
      getAllPoliticsState() {
        this.$http.get('/common/getAllPoliticsState')
          .then((res) => {
            this.zzmmOptions = this.reMethod(res, 'zzmm')
          }).catch()
      },
      // 获取部门里的所有支部
      getBranchListByDeptId(id) {
        this.$http.get('/common/getBranchListByDeptId', {
          params: {
            deptId: id
          }
        }).then((res) => {
          this.zbOptions = this.reMethod(res, 'zb')
        }).catch()
      },
      // 获取党内职务
      getAllPartyJob() {
        this.$http.get('/common/getAllPartyJob')
          .then((res) => {
            this.dnzwOptions = this.reMethod(res, 'dnzw')
          }).catch()
      },
      back() {
        this.$emit('off-show')
      },
      submit() {
        this.$confirm('确定？', '提示', {
          type: 'warning'
        }).then(({result}) => {
          if (result) {
            let emitData = ''
            if (this.infoLoaded) {
              emitData = 'outData'
              this.outData.id = this.djid
            } else {
              emitData = 'inData'
              this.submitIn()
            }
            let data = this[emitData]
            for (let item in data) {
              if (!data[item] && item !== 'ms' && item !== 'id') {
                this.$message.alert('信息未填写完成')
                return
              }
            }
            this.$emit('submit-applyfor', this[emitData])
          }
        })
      },
      submitIn() {
        let date = this.date
        let year = date.getFullYear()
        let month = date.getUTCMonth() + 1
        let day = date.getDate()
        let curDate = year + '-' + ((month + 1) >= 10 ? (month + 1) : '0' + (month + 1)) + '-' + (day < 10 ? '0' + day : day)
        let data = this.inData
        data.rdsj = curDate
        this.inData.id = this.djid
        this.inData.zt = 1
      }
    },
    watch: {
      'inData.bmdm': function () {
        let dm = this.inData.bmdm
        this.getBranchListByDeptId(dm)
      },
      'inData.zcdd': function () {
        this.outOrIn()
      },
      'showit': function () {
        this.outOrIn()
        this.date = ''
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin.styl"
  .page
    position: fixed
    left: 0
    top: 0
    bottom: 48px
    z-index: 1000
    width: 100%
    height: 100%
    background: #fff
    .common-title
      width: 100%
      height: 0.8rem
      line-height: 1
      z-index: 1000
      text-align: center
      border-radius: 0.06rem 0.06rem 0 0
      font-size: 0
      background: #ee2728
      .wrapper
        position: absolute
        top: 0rem
        left: 0.2rem
        overflow: hidden
        box-shadow: none
        height: 0.8rem
      .title
        display: block
        width: 100%
        padding: 0.24rem 0
        letter-spacing: 0.04rem
        color: #FFFFFF
        font-family: 'Microsoft YaHei'
        font-size: 0.32rem
    .page-title
      height: 0.8rem
      font-size: 0.3rem
      div
        height: 0.8rem
        font-size: 0.3rem
    .page-content
      width: 100%
      .field
        width: 100%
        padding: 0 0.15rem
        background: #fff
      .button
        padding: 0 0.15rem
      .mu-input
        padding-bottom: 0

  .confirm
    position: fixed
    top: 0
    left: 0
    z-index: 30
    height: 100%
    width: 100%
    background: rgba(7, 17, 27, 0.4)
    font-size: 0

  .confirm-main
    width: 100%
    font-size: 0.3rem
    color: rgba(0, 0, 0, 0.7)
    div
      margin-top: 0.1rem
      border-1px(rgba(7, 17, 27, 0.1))
      .span-block
        display: block
</style>

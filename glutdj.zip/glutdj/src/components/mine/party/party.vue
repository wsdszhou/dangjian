<template>
  <transition name="slide">
    <div class="party">
      <common-title :title="titlename" :back-path="backPath"></common-title>
      <mu-container ref="container">
        <mu-load-more @refresh="refresh" :refreshing="refreshing">
          <div class="detail-main">
            <div class="title">
              <div class="line"></div>
              <div class="text">我的党籍</div>
              <div class="line"></div>
            </div>
            <mu-paper class="item">
              <div>
                <mu-icon value="account_box" size="10px" class="icon" color="red"></mu-icon>
                姓名：{{info.yhxxXm }}
              </div>
              <div>
                <mu-icon value="school" size="10px" class="icon" color="indigo800"></mu-icon>
                学历：{{ info.xlMc }}
              </div>
              <div>
                <mu-icon value="location_on" size="10px" class="icon" color="deepPurple400"></mu-icon>
                所属部门：{{ info.bmMc }}
              </div>
              <div>
                <mu-icon value="domain" size="10px" class="icon" color="cyan500"></mu-icon>
                支部：{{info.zbMc }}
              </div>
              <div>
                <mu-icon value="person_pin" size="10px" class="icon" color="green500"></mu-icon>
                政治面貌：{{info.zzmmMc }}
              </div>
              <div>
                <mu-icon value="settings" size="10px" class="icon" color="orange600"></mu-icon>
                党内职务：{{ info.dnzwMc }}
              </div>
            </mu-paper>
            <div class="in-out">
              <div class="title">
                <div class="line"></div>
                <div class="text">党籍状态</div>
                <div class="line"></div>
              </div>
              <mu-button color="red" round>{{djzt}}</mu-button>
            </div>
            <div v-if="!reInParty">
              <div class="inparty in-out" v-if="!infoLoaded && result">
                <div class="title">
                  <div class="line"></div>
                  <div class="text">申请转入党籍</div>
                  <div class="line"></div>
                </div>
                <mu-button color="red" round @click.stop="applyforPageShow">申请</mu-button>
              </div>
              <div class="outparty in-out" v-if="infoLoaded && result">
                <div class="title">
                  <div class="line"></div>
                  <div class="text">申请转出党籍</div>
                  <div class="line"></div>
                </div>
                <mu-button color="red" round @click.stop="applyforPageShow">申请</mu-button>
              </div>
            </div>
            <div class="inparty in-out" v-if="reInParty && result">
              <div class="title">
                <div class="line"></div>
                <div class="text">申请重新转入党籍</div>
                <div class="line"></div>
              </div>
              <mu-button color="red" round @click.stop="applyforPageShow">申请</mu-button>
            </div>
          </div>
        </mu-load-more>
      </mu-container>
      <div class="applyfor" v-if="applyfor">
        <applyfor :showit="applyforShow"
                  :infoLoaded="infoLoaded"
                  :djid="id"
                  @off-show="applyforPageShow"
                  @submit-applyfor="submit">
        </applyfor>
      </div>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import Applyfor from './applyfor'

  // 接口数据result, 0:在审批状态，1:审批通过
  // 接口数据zt, 1:在籍，2：转出

  export default {
    data() {
      return {
        titlename: '党籍管理',
        info: {},
        backPath: {name: 'mine'},
        id: '', // 党籍ID
        reInParty: false, // 已转出党籍需要重新申请进入
        result: 0, // 当前党籍审批结果
        djzt: '',
        infoLoaded: false, // 是否有党籍
        refreshing: false,
        applyfor: false, // 开启申请页面
        applyforShow: false // 显示申请页面
      }
    },
    methods: {
      getParty(flag) {
        this.$http.get('/party').then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.bmMc) {
              this.infoLoaded = true
              this.info = res.data
              this.id = this.info.id
              this.result = this.info.result
              if (this.result) {
                if (this.info.zt === 1) {
                  this.djzt = '在籍'
                } else {
                  this.djzt = '已转出'
                  this.reInParty = true
                }
              } else {
                this.djzt = '审批中'
              }
              if (flag) {
                this.refreshing = false
              }
            } else {
              this.djzt = '不在籍'
              this.result = 1
              this.$toast.error('您的党籍信息未载入')
              if (flag) {
                this.refreshing = false
              }
            }
          }
        }).catch(() => {
          if (flag) {
            this.refreshing = false
          }
          this.djzt = '不在籍'
          this.result = 1
          this.$toast.error('您的党籍信息未载入')
        })
      },
      refresh() {
        this.refreshing = true
        this.getParty(1)
      },
      goTo(path) {
        this.$router.push(path)
      },
      applyforPageShow() {
        if (!this.applyfor) {
          this.applyfor = true
        }
        this.applyforShow = !this.applyforShow
      },
      submit(val) {
        let url = ''
        if (this.infoLoaded) {
          url = 'party/updateParty'
        } else {
          url = 'party'
        }
        this.$http({
          url: url,
          method: 'post',
          data: val,
          transformRequest: [function (data) {
            let ret = ''
            for (let it in data) {
              ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
            }
            return ret
          }],
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.$message.alert('申请已经提交，请静候审批', '党籍管理')
            this.applyforPageShow()
          }
        }).catch(() => {
          this.$message.alert('申请提交失败', '党籍管理')
          this.applyforPageShow()
        })
      }
    },
    created() {
      this.getParty()
    },
    components: {
      CommonTitle,
      Applyfor
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .party
    position: absolute
    top: 0
    bottom: 0
    width: 100%
    height: 100%
    z-index: 100
    font-size: 0
    background-color: #fff
    .detail-main
      .item
        position: relative
        margin: 0.12rem
        padding: 0.2rem
        box-sizing: border-box
        box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
        background: #fff
        div
          font-size: 0.3rem
          padding: 0.1rem 0 0 0.1rem
          border-1px(rgba(7, 17, 27, 0.1))
          i
            vertical-align: bottom
      .title
        display: flex
        width: 80%
        margin: 0.16rem auto
        .line
          flex: 1
          position: relative
          top: -6px
          border-bottom: 1px solid #ee2728
        .text
          color: #ee2728
          padding: 0 12px
          font-weight: 700
          font-size: 14px
      .in-out
        margin: 0.3rem
        text-align: center
        .mu-button
          margin-top: 0.25rem
</style>

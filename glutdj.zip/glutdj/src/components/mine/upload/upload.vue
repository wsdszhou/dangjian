<template>
  <transition name="slide">
    <div class="upload">
      <common-title title="上传头像" class="title"></common-title>
      <div class="card">
        <div class="card-body">
          <img :src="user.avatar" width="160px" height="160px" class="card-img avatar"/>
          <div class="card-img-overlay">
            <mu-button id="pick-avatar">选择一张新图片</mu-button>
          </div>
        </div>
        <div class="card-footer text-muted" v-html="message"></div>
        <avatar-cropper
          upload-form-name="uploadFile"
          @uploading="handleUploading"
          @uploaded="handleUploaded"
          @completed="handleCompleted"
          @error="handlerError"
          trigger="#pick-avatar"
          upload-url="http://111.231.76.233:8080/dangjian-controller/mobile/user/uploadPortrait">
        </avatar-cropper>
      </div>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import AvatarCropper from 'vue-avatar-cropper'
  import {URL} from 'common/js/config'
  import {mapGetters, mapActions} from 'vuex'

  export default {
    data() {
      return {
        message: '请上传新头像',
        user: {
          id: 1,
          avatar: ''
        },
        uploadUrl: ''
      }
    },
    created() {
      if (!this.avatar) {
        this.getUserPicture()
      } else {
        this.user.avatar = this.avatar
      }
      this.uploadUrl = `${URL}/dangjian-controller/mobile/user/uploadPortrait`
    },
    methods: {
      ...mapActions({
        setAvatar: 'SET_AVATAR'
      }),
      // 获取用户头像
      getUserPicture() {
        this.$http.get('/user/getUserPicture')
          .then(res => {
            res = res.data
            if (res.error === 0) {
              this.user.avatar = URL + res.data
              this.setAvatar(this.user.avatar)
            }
          }).catch(() => {
        })
      },
      handleUploading(form, xhr) {
        this.message = '上传中...'
      },
      handleUploaded(response) {
        this.user.avatar = URL + response.data
        this.setAvatar(this.user.avatar)
        this.message = '用户头像已更新.'
      },
      handleCompleted(response, form, xhr) {
        this.message = '上传成功.'
      },
      handlerError(message, type, xhr) {
        this.message = '出了点小问题...'
      }
    },
    computed: {
      ...mapGetters(['avatar'])
    },
    components: {AvatarCropper, CommonTitle}
  }
</script>

<style scoped lang="stylus">
  .upload
    position: absolute
    width: 100%
    background-color: #fff

  .card
    max-width: 4rem
    margin: 0 auto

  .avatar
    width: 160px
    border-radius: 6px
    display: block
    margin: 20px auto

  .card-img-overlay
    width: 100%
    text-align: center

  .card-footer
    text-align: center
</style>

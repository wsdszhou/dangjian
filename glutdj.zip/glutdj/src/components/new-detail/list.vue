<template>
  <transition name="slide">
    <div class="list" v-show="showlist">
      <div class="headers" ref="headers">
        <div class="common-title">
          <mu-button fab small class="wrapper" @click="back" color="#ee2728">
            <mu-icon value="arrow_back" size="24"></mu-icon>
          </mu-button>
          <span class="title">评论</span>
        </div>
        <mu-appbar style="width: 100%;" :title="title" class="page-title"></mu-appbar>
      </div>
      <div class="list-wrapper" :style="'height:'+curheight+'px'">
        <div class="list-content">
          <scroll ref="scroll"
                  :probe-type="probeType"
                  :scrollbar="scrollbar"
                  :pullUpLoad="pullUpLoad"
                  @pullingUp="onPullingUp"
                  class="comment-content">
            <div class="comment-content-body">
              <div class="comment-comment" v-if="commentEnd">
                <div class="comment-comment-title">
                  {{comments.length}}条评论
                </div>
                <ul>
                  <li v-for="item in comments" :key="item.rateTime" class="comment-item">
                    <div class="avatar">
                      <img width="28" height="28"
                           src="http://static.galileo.xiaojukeji.com/static/tms/default_header.png">
                    </div>
                    <div class="content">
                      <span class="name">{{item.plUsername}}</span>
                      <div class="time">{{item.sj}}</div>
                      <p class="text">{{item.zw}}</p>
                    </div>
                  </li>
                </ul>
                <div v-show="commentEnd&&exceedHeight" class="pullup-wrapper">
                  <div class="before-trigger" v-if="!isPullUpload">
                    <span>{{pullUpTxt}}</span>
                  </div>
                  <div class="after-trigger" v-else>
                    <div v-loading="true"
                         data-mu-loading-size="32"
                         data-mu-loading-color="red"
                         data-mu-loading-overlay-color="rgba(0, 0, 0, 0)"
                         style="position: relative; width: 200px; height: 100px;"></div>
                  </div>
                </div>
              </div>
            </div>
          </scroll>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'

  export default {
    data() {
      return {
        comment: '',
        needTop: false,
        // 首次加载评论完成
        commentEnd: false,
        curheight: 0,
        probeType: 3,
        scrollbar: {
          fade: true
        },
        page: 1,
        limit: 15,
        comments: [], // 新闻评论
        notPullUploadOver: true, // 有更多数据，可以上拉刷新
        isPullUpload: false,
        pullUpLoad: {
          threshold: -20
        },
        exceedHeight: false // 判断首次加载10条评论如果成功则有更多
      }
    },
    props: {
      showlist: {
        type: Boolean,
        default() {
          return false
        }
      },
      title: {
        type: String,
        default() {
          return '桂林理工大学新闻'
        }
      },
      // 新闻的id
      id: {
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.getComment()
    },
    methods: {
      // 分页获取评论列表
      getComment() {
        let id = this.id
        if (id === '') {
          this.back()
          return
        }
        this.$http.get('/news/comment/getSingletNewsComment', {
          params: {
            page: this.page,
            limit: this.limit,
            newsId: id
          }
        }).then((res) => {
          res = res.data
          this.comments = res.data
          this.commentEnd = true
          if (this.comments.length >= this.limit) {
            this.exceedHeight = true
          }
          this.$nextTick(() => {
            this.curheight = window.innerHeight - this.$refs.headers.clientHeight
            window.setTimeout(() => {
              this.$refs.scroll.refresh()
            })
          })
        }).catch()
      },
      // 加载更多评论
      getMoreComment() {
        this.$http.get('/news/comment/getSingletNewsComment', {
          params: {
            page: ++this.page,
            limit: this.limit,
            newsId: this.id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.comments, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.isPullUpload = false
          }
        }).catch()
      },
      // 上拉加载更多评论
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.isPullUpload = true
          this.getMoreComment()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      back() {
        this.$emit('off-show')
      },
      submit() {
        if (this.comment !== '') {
          this.$emit('submit-comment', this.comment)
        } else {
          this.$toast.error('评论不能为空')
        }
      }
    },
    computed: {
      pullUpTxt() {
        return this.notPullUploadOver ? '上拉加载更多' : '没有更多了'
      }
    },
    components: {
      Scroll
    }
  }
</script>

<style scoped lang="stylus">
  @import '~common/stylus/mixin'
  .list
    position: fixed
    left: 0
    top: 0
    bottom: 48px
    z-index: 1000
    width: 100%
    height: 100%
    background: #f5f5f4
    .headers
      .common-title
        width: 100%
        height: 0.8rem
        line-height: 1
        z-index: 1000
        text-align: center
        border-radius: 0.06rem 0.06rem 0 0
        font-size: 0
        background: #ee2728
        .wrapper
          position: absolute
          top: 0rem
          left: 0.2rem
          overflow: hidden
          box-shadow: none
          height: 0.8rem
        .title
          display: block
          width: 100%
          padding: 0.24rem 0
          letter-spacing: 0.04rem
          color: #FFFFFF
          font-family: 'Microsoft YaHei'
          font-size: 0.32rem
      .page-title
        height: 0.8rem
        font-size: 0.3rem
        div
          height: 0.8rem
          font-size: 0.3rem
    .list-wrapper
      .list-content
        position: relative
        width: 100%
        height: 100%
        overflow: hidden
        .comment-content
          position: absolute
          width: 100%
          height: 100%
          overflow: hidden
          .comment-content-body
            background-color: #fff
          .comment-comment
            padding: 0 0.06rem 0 0.06rem
            .comment-comment-title
              padding: 0.16rem
            .comment-item
              display: flex
              position: relative
              font-size: 0.3rem
              border-1px(rgba(1, 17, 27, 0.1))
              .avatar
                flex: 0 0 0.56rem
                width: 0.56rem
                margin-right: 0.24rem
            .pullup-wrapper
              width: 100%
              height: 1rem
              display: flex
              justify-content center
              align-items center
              padding: 0.32rem 0
              .after-trigger
                margin-top: 0.2rem
</style>

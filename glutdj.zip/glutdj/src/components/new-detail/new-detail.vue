<template>
  <transition name="slide">
    <div class="new-detail">
      <div class="detail-wrapper">
        <div class="new-header" ref="header">
          <div class="common-title">
            <mu-button fab small class="wrapper" @click="back" color="#ee2728">
              <mu-icon value="arrow_back" size="24"></mu-icon>
            </mu-button>
            <span class="title">新闻详情</span>
          </div>
        </div>
        <div class="new-wrapper">
          <scroll ref="scroll"
                  @scroll="scroll"
                  :probe-type="probeType"
                  :listen-scroll="listenScroll"
                  :scrollbar="scrollbar"
                  class="new-content">
            <div class="new-content-body">
              <div class="top"></div>
              <h1 class="new-title">{{news.xwBt}}</h1>
              <div class="new-info border-1px">
                <div class="datetime">{{news.xwXgsj}}</div>
                <div class="praise-num">
                  <mu-icon value="thumb_up" color="gray" class="thumb"></mu-icon>
                  {{praiseNum}}
                </div>
                <div class="read-num">阅读次数：{{news.xwYdrs}}</div>
              </div>
              <div class="new-body">
                <div ref="news"></div>
              </div>
              <div class="new-comment" v-if="commentEnd">
                <div class="new-comment-title">
                  {{comments.length}}条评论
                </div>
                <ul>
                  <li v-for="item in comments" :key="item.rateTime" class="comment-item">
                    <div class="avatar">
                      <img width="28" height="28"
                           src="http://static.galileo.xiaojukeji.com/static/tms/default_header.png">
                    </div>
                    <div class="content">
                      <span class="name">{{item.plUsername}}</span>
                      <div class="time">{{item.sj}}</div>
                      <p class="text">{{item.zw}}</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </scroll>
        </div>
        <div class="comment" ref="comment">
          <div class="comment-left" @click="openCommentPage">
            <i class="iconfont icon-xuexi"></i>
            <input id="input" type="text" placeholder="留下你的评论">
          </div>
          <div class="comment-right">
            <mu-button fab small class="mu-button" color="red500" @click="openCommentList">
              <mu-icon class="icon" value="chat_bubble"></mu-icon>
            </mu-button>
            <mu-button fab small class="mu-button" @click="praise">
              <mu-icon class="icon" value="thumb_up"></mu-icon>
            </mu-button>
          </div>
        </div>
        <transition name="top">
          <mu-button fab class="icon-top" @click="scrollTo" v-show="needTop">
            <mu-icon value="arrow_upward"></mu-icon>
          </mu-button>
        </transition>
        <div class="comment-page" v-if="commentPage">
          <page :showit="commentPageShow"
                @off-show="openCommentPage"
                @submit-comment="saveComment"
                :title="news.xwBt">
          </page>
        </div>
        <div class="comment-list" v-if="commentList">
          <list :showlist="commentListShow"
                @off-show="openCommentList"
                :id="id"
                :title="news.xwBt">
          </list>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  import Scroll from 'base/scroll/scroll'
  import Page from './page'
  import List from './list'
  import {prefixStyle} from 'common/js/dom'
  import {mapGetters} from 'vuex'
  import Commontitle from 'base/common-title/common-title'

  const transform = prefixStyle('transform')

  export default {
    data() {
      return {
        news: {},
        praiseNum: 0,
        scrollY: 0,
        scrollbar: {
          fade: true
        },
        needTop: false,
        commentEnd: false,
        probeType: 3,
        listenScroll: true,
        praised: false,
        comments: [], // 新闻评论
        commentPage: false,
        commentPageShow: false,
        commentList: false,
        commentListShow: false
      }
    },
    props: {
      id: { // 新闻ID
        type: String,
        default() {
          return ''
        }
      }
    },
    created() {
      this.init()
    },
    methods: {
      // 初始化
      init() {
        this.innerHeight = window.innerHeight
        this.getNews()
        this.getComment()
        this.$nextTick(function () {
          this.header = this.$refs.header
          this.comment = this.$refs.comment
          this.headerHeight = this.header.clientHeight
          this.commentHeight = this.comment.clientHeight
        })
      },
      // 获取新闻
      getNews() {
        let id = this.id
        this.$http.get('/news/geSingletNewsByNewsId', {
          params: {
            newId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.getPraise()
            this.news = res.data
            let orablob = this.news.newsContext
            this.$refs.news.innerHTML = orablob
          }
        })
      },
      // 分页获取评论列表
      getComment() {
        if (this.$route.params.newsid) {
          this.id = this.$route.params.newsid
        }
        let id = this.id
        this.$http.get('/news/comment/getSingletNewsComment', {
          params: {
            page: 1,
            limit: 10,
            newsId: id
          }
        }).then((res) => {
          res = res.data
          this.comments = res.data
          this.commentEnd = true
          this.$nextTick(() => {
            this.$refs.scroll.refresh()
          })
        }).catch()
      },
      // 保存评论
      saveComment(comment) {
        let id = this.id
        this.$http({
          url: '/news/comment',
          method: 'post',
          data: {
            xwdm: id,
            zw: comment
          },
          transformRequest: [function (data) {
            // Do whatever you want to transform the data
            let ret = ''
            for (let it in data) {
              ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
            }
            return ret
          }],
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }).then((res) => {
          res = res.data
          this.openCommentPage()
          if (res.error === 0) {
            this.$toast.success('评论成功')
          } else {
            this.$toast.error('评论失败')
          }
        }).catch()
      },
      // 获取点赞数
      getPraise() {
        let id = this.id
        this.$http.get('/news/praise/getNewsPraiseNum', {
          params: {
            newsId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.praiseNum = res.data
          }
        }).catch()
      },
      // 对新闻点赞
      praise() {
        if (this.praised) {
          this.$toast.info('你已经点过赞咯')
          return
        }
        let id = this.id
        this.$http.get('/news/praise/getNewsPraise', {
          params: {
            newsId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.$toast.success('点赞成功！')
          } else if (res.error === 202) {
            this.$toast.info('你已经点过赞咯')
          }
          this.praised = true // 本地存一个变量避免用户大量点赞发送http请求
        }).catch()
      },
      // 打开评论面板
      openCommentPage() {
        if (!this.commentPage) {
          this.commentPage = true
        }
        this.commentPageShow = !this.commentPageShow
      },
      // 打开评论列表
      openCommentList() {
        if (!this.commentList) {
          this.commentList = true
        }
        this.commentListShow = !this.commentListShow
      },
      back() {
        this.$emit('off-show')
      },
      scrollTo() {
        this.needTop = false
        this.$refs.scroll.scrollTo(0, 0, 500)
      },
      scroll(pos) {
        this.scrollY = pos.y
      }
    },
    watch: {
      scrollY(newY, oldY) {
        if (newY < oldY && newY < -40 && !this.istranslateUp) {
          this.header.style[transform] = `translate3d(0,-${this.headerHeight}px,0)`
          this.comment.style[transform] = `translate3d(0,${this.commentHeight}px,0)`
          this.istranslateUp = true
          this.needTop = false
          this.isNeedTop = false
        } else if (newY > oldY + 5 && this.istranslateUp) {
          this.header.style[transform] = `translate3d(0,0,0)`
          this.comment.style[transform] = `translate3d(0,0,0)`
          this.istranslateUp = false
          if ((-newY >= this.innerHeight) && (!this.isNeedTop)) {
            this.isNeedTop = true
            this.needTop = true
          }
        }
      }
    },
    components: {
      Scroll,
      Page,
      List,
      Commontitle
    },
    computed: {
      ...mapGetters({
        newsId: 'newsId'
      })
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .new-detail
    position: fixed
    top: 0
    left: 0
    width: 100%
    height: 100%
    overflow: hidden
    font-size: 0.3rem
    background-color: #fff
    .detail-wrapper
      position: absolute
      width: 100%
      height: 100%
      overflow: hidden
      .new-header
        position: absolute
        width: 100%
        height: 0.8rem
        z-index: 1000
        text-align: center
        border-radius: 0.06rem
        overflow: hidden
        background: #ee2728
        box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
        transition: all 0.3s
      .new-wrapper
        position: absolute
        bottom: 0.72rem
        width: 100%
        height: 100%
        padding: 0 0.16rem
        .new-content
          height: 100%
          .new-content-body
            padding-bottom: 1rem
          .top
            height: 1.6rem
          .new-title
            width: 100%
            line-height: 1.25
            font-size 0.46rem
            font-weight: 700
          .new-info
            height: 0.6rem
            margin-bottom: 0.16rem
            border-1px(rgba(7, 17, 27, 0.4))
            div
              display: inline-block
              overflow: hidden
              color: #6b737c
              font-size: 0.28rem
            .read-num
              float: right
            .praise-num
              float: right
              padding-left: 0.3rem
              .thumb
                vertical-align: middle
                font-size: 0.34rem
          .new-body
            padding-bottom: 0.7rem
            white-space: pre-wrap
            word-break: break-all
            font-size: 0
          .new-comment
            padding: 0 0.06rem
            .new-comment-title
              padding: 0.16rem
            .comment-item
              display: flex
              position: relative
              font-size: 0.3rem
              border-1px(rgba(1, 17, 27, 0.1))
              .avatar
                flex: 0 0 0.56rem
                width: 0.56rem
                margin-right: 0.24rem
      .comment
        position: absolute
        display: flex
        z-index: 1000
        width: 100%
        height: 0.84rem
        bottom: 0
        left: 0
        z-index: 1000
        background: #fff
        box-shadow: 0 0 0.4rem rgba(0, 0, 0, .2)
        transition: all 0.3s
        .comment-left
          flex: 1 0
          margin: 0.12rem 0 0 0.25rem
          #input
            border-radius: 24px
            border: 1px solid #bfcbd9
            box-sizing: border-box
            color: #1f2d3d
            font-size: 0.28rem
            width: 3.8rem
            height: 0.62rem
            vertical-align: middle
            line-height: 0.62rem
            outline: 0
            padding: 0.06rem 0.2rem
            caret-color: red
            background-color: #f8f8f8
            &:focus
              border: 1px solid red
        .comment-right
          flex: 1 0 3.3rem
          margin-top: 0.08rem
          padding-left: 0.4rem
          font-size: 0
          .mu-button
            height: 0.7rem
            width: 0.7rem
            display: inline-block
            margin-right: 0.2rem
            vertical-align: top
            font-size: 0.42rem

  .mu-button
    box-shadow: none

  .icon-top
    position: fixed
    right: 5%
    bottom: 30%
    color: #fff;
    display: flex
    width: 0.84rem
    height: 0.84rem
    justify-content: center
    align-items: center;
    background-color: rgba(238, 39, 40, 0.9)
    .iconfont
      font-size: 0.5rem

  .top-enter-active, .top-leave-active
    transition: all 0.2s linear

  .top-enter, .top-leave-to
    transform: translate3d(0.9rem, 0, 0)

  .common-title
    width: 100%
    height: 0.8rem
    line-height: 1
    z-index: 1000
    text-align: center
    border-radius: 0.06rem 0.06rem 0 0
    font-size: 0
    background: #ee2728
    .wrapper
      position: absolute
      top: 0rem
      left: 0.2rem
      overflow: hidden
      box-shadow: none
      height: 0.8rem
    .title
      display: block
      width: 100%
      padding: 0.24rem 0
      letter-spacing: 0.04rem
      color: #FFFFFF
      font-family: 'Microsoft YaHei'
      font-size: 0.32rem

</style>

<template>
  <transition name="slide">
    <div class="page" v-show="showit">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">评论</span>
      </div>
      <mu-appbar style="width: 100%;" :title="title" class="page-title"></mu-appbar>
      <div class="page-content">
        <mu-text-field v-model="comment"
                       placeholder="评论将由管理员筛选后显示，对所有人可见"
                       multi-line :rows="4"
                       :rows-max="6"
                       class="field">
        </mu-text-field>
        <div class="button">
          <mu-button full-width color="primary" @click="submit">提交</mu-button>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {
        comment: ''
      }
    },
    props: {
      showit: {
        type: Boolean,
        default() {
          return false
        }
      },
      title: {
        type: String,
        default() {
          return '桂林理工大学新闻'
        }
      }
    },
    methods: {
      back() {
        this.$emit('off-show')
      },
      submit() {
        if (this.comment !== '') {
          this.$emit('submit-comment', this.comment)
        } else {
          this.$toast.error('评论不能为空')
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  .page
    position: fixed
    left: 0
    top: 0
    bottom: 48px
    z-index: 1000
    width: 100%
    height: 100%
    background: #f5f5f4
    .common-title
      width: 100%
      height: 0.8rem
      line-height: 1
      z-index: 1000
      text-align: center
      border-radius: 0.06rem 0.06rem 0 0
      font-size: 0
      background: #ee2728
      .wrapper
        position: absolute
        top: 0rem
        left: 0.2rem
        overflow: hidden
        box-shadow: none
        height: 0.8rem
      .title
        display: block
        width: 100%
        padding: 0.24rem 0
        letter-spacing: 0.04rem
        color: #FFFFFF
        font-family: 'Microsoft YaHei'
        font-size: 0.32rem
    .page-title
      height: 0.8rem
      font-size: 0.3rem
      div
        height: 0.8rem
        font-size: 0.3rem
    .page-content
      width: 100%
      .field
        width: 100%
        padding: 0 0.15rem
        background: #fff
      .button
        padding: 0 0.15rem
      .mu-input
        padding-bottom: 0

</style>

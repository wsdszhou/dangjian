<template>
  <div class="newremind">
    <scroll class="remind-content"
            :showItem="showItem"
            :itemsLoaded="itemsLoaded"
            :exceedHeight="exceedHeight"
            :pullUploading="pullUploading"
            :notPullUploadOver="notPullUploadOver"
            :loading="loading"
            :scrollbar="scrollbar"
            :pullUpLoad="pullUpLoad"
            @clickrefresh="refresh"
            @pullingUp="onPullingUp"
            ref="scroll">
      <div>
        <div class="info-wrapper">
          <div class="item-wrapper" v-for="(item) in items" :key="item.name" @click="getDetail(item.tzId)">
            <div class="item-title">
              {{item.tzBt}}
            </div>
            <mu-ripple
              color="#9e9e9e"
              :opacity="0.6"
              class="item mu-ripple">
              <div class="numi">
                <mu-icon value="assignment" size="10px" class="icon" color="pink"></mu-icon>
                通知内容：{{item.tzNr}}
              </div>
              <div class="date-time">
                <mu-icon value="person" size="10px" class="icon" color="#43a047"></mu-icon>
                发布人：{{item.fbrxm}}
              </div>
              <div class="date-time">
                <mu-icon value="access_time" size="10px" class="icon" color="orange"></mu-icon>
                发布时间：{{item.tzFbsj}}
              </div>
            </mu-ripple>
          </div>
        </div>
      </div>
    </scroll>
  </div>
</template>

<script>
  import Scroll from 'base/scrollmore/scrollmore'
  import Loader from 'base/loader/loader'

  const NOITEMS = 1 // 成功获取数据但没有通知
  const ITEMSFAILED = 2 // 获取数据失败

  export default {
    data() {
      return {
        items: [],
        page: 1,
        limit: 5,
        honorShow: false,
        honorDetail: {},
        showItem: '', // 数据获取情况
        loading: false,
        itemsLoaded: false,
        itemsStatus: 0,
        exceedHeight: false,
        notPullUploadOver: true,
        pullUploading: false,
        scrollbar: {
          fade: true
        },
        pullUpLoad: {
          threshold: -20
        }
      }
    },
    created() {
      this.getNoticePageList()
    },
    methods: {
      // 获取公告列表
      getNoticePageList() {
        this.$http.get('notice/getNoticePageList', {
          params: {
            page: this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) { // 判断数据长度
              this.items = res.data
            } else {
              this.itemsStatus = NOITEMS
            }
            this.itemsLoaded = true
          }
          if (this.items.length >= this.limit) {
            this.exceedHeight = true
          } else {
            this.notPullUploadOver = false
          }
          this.showStatus()
        }).catch(() => {
          if (this.itemsStatus !== NOITEMS) {
            this.itemsStatus = ITEMSFAILED
          }
          this.showStatus()
        })
      },
      // 加载更多提醒
      getMoreNotice() {
        this.$http.get('notice/getNoticePageList', {
          params: {
            page: ++this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            if (res.data.length) {
              Array.prototype.push.apply(this.items, res.data)
            } else {
              this.notPullUploadOver = false
            }
            this.pullUploading = false
          }
        })
      },
      // 获取公告详情
      getDetail(id) {
        this.$router.push({name: 'detail', params: {id: id}})
      },
      // 根据数据状态显示信息
      showStatus() {
        if (this.itemsStatus === NOITEMS) {
          this.showItem = '暂无最新消息'
        } else if (this.itemsStatus === ITEMSFAILED) {
          this.showItem = '获取数据失败'
        }
      },
      // 上拉加载更多
      onPullingUp() {
        if (this.notPullUploadOver) {
          this.pullUploading = true
          this.getMoreNotice()
          this.$refs.scroll.finishPullUp()
          this.$refs.scroll.refresh()
        }
      },
      // 刷新页面
      refresh() {
        this.showItem = ''
        this.itemsStatus = 0
        this.itemsLoaded = false
        this.getNoticePageList()
      }
    },
    components: {
      Scroll,
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin"
  .newremind
    width: 100%
    height: 100%
    position: absolute
    z-index: 10
    font-size: 0
    .remind-content
      height: 100%
      overflow: hidden
      .info-wrapper
        box-sizing: border-box
        width: 100%
        height: 100%
        overflow: hidden
        .item-wrapper
          margin-top: 0.2rem
          .item-title
            min-height: 0.56rem
            margin: 0 0.12rem
            font-size: 0.3rem
            line-height: 0.56rem
            padding-left: 0.2rem
            border-radius: 0.1rem 0.1rem 0 0
            color: rgba(255, 255, 255, .95)
            background: #e22b19
          .item
            margin: 0 0.12rem 0.2rem 0.12rem
            padding: 0.2rem
            box-sizing: border-box
            border-radius: 0 0 0.1rem 0.1rem
            box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12)
            background: #fff
            .numi
              overflow: hidden
              text-overflow:ellipsis
              white-space: nowrap
              max-height: 0.56rem
            div
              border-1px(rgba(7, 17, 27, 0.1))
          .mu-ripple
            position: relative
            padding-top: 0.32rem
            display: inline-block
            width: 7.25rem
            div
              min-height: 0.5rem
              line-height: 0.5rem
              font-size: 0.3rem
              font-family: 'Microsoft YaHei'
              .icon
                vertical-align: bottom
                padding-bottom: 0.06rem
    .loader-container
      position: absolute
      width: 100%
      top: 50%
      transform: translateY(-50%)
    .show-item
      position: absolute
      width: 100%
      top: 40%
      transform: translateY(-40%)
      text-align: center
      font-size: 0.3rem
      color #484848
      .show-item-msg
        padding-bottom: 0.2rem
        border-bottom: solid 1px #ce285d
      .refresh
        margin: 6rem auto 0.2rem auto
        text-align: center
        font-size: 0.34rem
</style>

<template>
  <div class="onexam">
    <div class="onexam-title">
      <mu-button color="#ee2728" @click="back" class="mu-button-wrapper" small>
        <mu-icon value="arrow_back" left></mu-icon>
        退出考试
      </mu-button>
      <div class="title-right">
        <div class="list-timer">
          <mu-button class="list" @click="_showList" color="#00bcd4">
            <mu-icon value="format_list_numbered" right></mu-icon>
          </mu-button>
          <div class="timer">
            <mu-icon value="timer"></mu-icon>
            <span class="time">{{hr}}:{{min}}:{{sec}}</span></div>
        </div>
      </div>
    </div>
    <exam-slide v-if="examsLoaded" class="exam-slide" ref="slide" @index-change="indexChange">
      <Single v-if="exams.single"
              v-for="(item,index) in exams.single"
              :key="item.id"
              :exam="item"
              :index="index + 1"
              :length="examsLength"
              :id="item.seq"
              :answer="item.reAnswer"
              @showList="_showList"
              @restartsin="reStartSin"
              @single-choosed="firstStartSin"></Single>
      <multiple v-if="exams.multiple"
                v-for="(item,index) in exams.multiple"
                :key="item.seq"
                :exam="item"
                :index="singleLength + index + 1"
                :length="examsLength"
                :id="item.seq"
                :curoption="item.reAnswer"
                @showList="_showList"
                @multiple-choosed="multipleChoosed"></multiple>
    </exam-slide>
    <div class="onexam-bottom">
      <div class="button" @click="prev">
        <mu-button color="#35a0ee" class="prev mu-ripple" small>{{currentIndex===1?'无':'上一题'}}</mu-button>
      </div>
      <div class="button" @click="next">
        <mu-button color="#35a0ee" class="next mu-ripple" small>下一题</mu-button>
      </div>
    </div>
    <div class="exam-list" v-show="showList">
      <div class="list-header">
        <div class="header-name">答题卡</div>
        <div class="header-num">
          <span class="num">
            已完成（{{choosedSingles + choosedMultiples}}/{{examsLength}}）
          </span>
        </div>
      </div>
      <div class="list-items">
        <div class="single-list elist" v-if="singleLength" ref="singleList">
          <div class="top"><span>单选题</span></div>
          <div
            class="item"
            v-for="i in singleLength"
            :key="i"
            @click="goTo(i)">
            {{i}}
          </div>
        </div>
        <div class="multiple-list elist" v-if="multipleLength" ref="multipleList">
          <div class="top"><span>多选题</span></div>
          <div
            class="item"
            v-for="i in multipleLength"
            :key="i"
            @click="goTo(i+singleLength)">
            {{i+singleLength}}
          </div>
        </div>
      </div>
      <mu-button class="list-submit" @click="submit" color="blue">提 交</mu-button>
    </div>
    <div v-show="!loaderdone" class="loader-container">
      <loader></loader>
    </div>
  </div>
</template>

<script>
  import Single from 'base/single/single'
  import Multiple from 'base/multiple/multiple'
  import ExamSlide from 'base/examslide/examslide'
  import {addClass, removeClass} from 'common/js/dom'
  import {mapActions, mapGetters} from 'vuex'
  import Loader from 'base/loader/loader'

  const FIRSTURL = '/exam/QuestionList/'
  const TESTINGURL = '/exam/getTestingQuestionList/'
  const NOLOGGED = 101 // 用户未登录
  const EXAMINTESTING = 310 // 用户所请求的是已在考试中的题目

  export default {
    data() {
      return {
        answers: {
          testpaperId: '', // 试卷ID
          isSubmit: 0, // 交卷时值为1
          answer: []
        },
        currentIndex: 1, // 页面的现在索引
        exams: {}, // 考试题目
        examsLoaded: false, // 试卷是否已经准备好
        examsLength: 0, // 考试题目总数
        loaderdone: false,
        singleLength: 0, // 单选题总数
        choosedSingles: 0, // 已选单选题总数
        multipleLength: 0, // 多选题总数
        choosedMultiples: 0, // 已选多选题总数
        judgementLength: 0, // 判断题总数
        choosedJudgement: 0, // 已选判断题总数
        singleAnswers: [], // 单选题答案
        multiAnswers: [], // 多选题答案
        judgementAnswers: [], // 判断题答案
        end: null, // 考试截止时间
        now: null, // 考试现在时间
        fived: false, // 剩余5分钟时间判断
        showList: false, // 答题卡显示判断
        countTimer: 0,
        answerTimer: 0,
        hr: 0,
        min: 0,
        sec: 0
      }
    },
    created() {
      this._getStart()
      this.answers.testpaperId += this.examId
    },
    computed: {
      ...mapGetters(['examId'])
    },
    methods: {
      ...mapActions({
        setExamId: 'SET_EXAMID'
      }),
      // 开始考试
      _getStart() {
        let curId = parseInt(this.$route.path.split('/')[2])
        if (curId && this.examId === 0) {
          this.setExamId(curId)
        }
        if (this.$route.query.restart === '1') {
          this._getTesting()
        } else {
          this._getFirstExam()
        }
      },
      _getFirstExam() {
        let url = FIRSTURL
        this._getExam(url, false)
      },
      _getTesting() {
        let url = TESTINGURL
        this.$message.confirm('是否载入为您保存的已做答案？', '考试中心')
          .then((val) => {
            if (val.result) {
              this._getExam(url, true)
            } else {
              this._getExam(url, false)
            }
          })
      },
      // 读取之前中途保存的答案
      _restart() {
        this.answers.answer = JSON.parse(window.localStorage.answers)
        this.answers.answer.forEach((firItem) => {
          if (this.exams.single) {
            this.exams.single.forEach((secItem) => {
              if (firItem.questionId === secItem.id) {
                secItem.reAnswer = firItem.studentAnswer
              }
            })
          }
          if (this.exams.multiple) {
            this.exams.multiple.forEach((secItem) => {
              if (firItem.questionId === secItem.id) {
                secItem.reAnswer = firItem.studentAnswer
              }
            })
          }
        })
      },
      _getExam(url, reTest) {
        this.$http.post(`${url}${this.examId}`)
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              this.exams = res.data
              this.end = Date.parse(new Date(this.exams.testInfo.endTime))
              this.examsLength = this.exams.testpaperInfo.questionNumber
              this.singleLength = this.exams.single.length
              this.multipleLength = this.exams.multiple.length
              this.judgementLength = this.exams.judgement.length
              this.examsLoaded = true // 试卷已经准备完成
              this.init()
              if (reTest && this.examsLoaded) {
                this._restart()
              }
              // 保证题目已经渲染
              if (this.examsLoaded) {
                this.$nextTick(() => {
                  setTimeout(() => {
                    this.$refs.slide.refresh()
                    this.endTimeInit()
                  }, 1000)
                })
              }
            } else if (res.error === NOLOGGED) {
              this.$login()
            } else if (res.error === EXAMINTESTING) { // 用户刷新试题
              this.$router.push('/onexam/' + this.examId + '?restart=1')
              this._getTesting()
            } else {
              this.$toast.error(res.msg)
            }
            this.loaderdone = true
          })
          .catch(() => {
          })
      },

      // 设置获取页面失去焦点，多于3次影响成绩

      endTimeInit() {
        this.countDown()
        this.timeSave()
      },
      countDown() {
        const now = Date.parse(new Date())
        this.now = now
        const msec = this.end - now
        if (msec < 0) {
          this.submit()
          return
        }
        if (msec < 300000 && !this.fived) {
          this.fived = true
          this.$message.alert('时间剩余仅有5分钟，请注意', '请注意')
        }
        let hr = Math.floor(msec / 1000 / 60 / 60 % 24)
        let min = Math.floor(msec / 1000 / 60 % 60)
        let sec = Math.floor(msec / 1000 % 60)
        this.hr = hr > 9 ? hr : '0' + hr
        this.min = min > 9 ? min : '0' + min
        this.sec = sec > 9 ? sec : '0' + sec
        this.countTimer = window.setTimeout(() => {
          this.countDown()
        }, 1000)
      },
      // 单选
      reStartSin(item) {
        this.singleChoosed(item)
      },
      firstStartSin(item) {
        this.singleChoosed(item)
        this.$refs.slide.next()
      },
      singleChoosed(item) {
        let target = this.singleAnswers
        for (let i = 0, len = target.length; i < len; i++) {
          let key = Object.keys(target[i])[0] // 获取每个单选题对象的键
          let itemKey = Object.keys(item)[0] // 获取当前所选答案的健
          if (key === itemKey) {
            target[i][key] = item[itemKey]
            return
          }
        }
        target.push(item)
        this.choosedSingles = target.length
        this.checkAnswers(target, 'singleList', 0)
      },
      // 多选
      multipleChoosed(item) {
        let target = this.multiAnswers
        for (let i = 0, len = target.length; i < len; i++) {
          let key = Object.keys(target[i])
          if (key[0] === Object.keys(item)[0]) {
            // 如果多选题取消所有答案
            if (item[key].length === 0) {
              this.checkAnswers(target, 'multipleList', this.singleLength, key[0])
            }
            this.checkAnswers(target, 'multipleList', this.singleLength)
            return
          }
        }
        target.push(item)
        this.choosedMultiples = target.length
        this.checkAnswers(target, 'multipleList', this.singleLength)
      },
      // 遍历已选答案，添加active类
      checkAnswers(answers, ref, index, remove) {
        let lists = this.$refs[ref].children
        for (let i = 0, len = answers.length; i < len; i++) {
          // -index是为了使lists[item]从0开始遍历
          if (remove) {
            let item = parseInt(remove) - index
            removeClass(lists[item], 'active')
            return
          }
          let item = parseInt(Object.keys(answers[i])[0]) - index
          if (ref === 'multipleList') {
            if (answers[i][Object.keys(answers[i])[0]].length === 0) {
              removeClass(lists[item], 'active')
              continue
            }
            addClass(lists[item], 'active')
          } else {
            addClass(lists[item], 'active')
          }
        }
      },
      // 提交答案
      submit() {
        let len = this.singleAnswers.length + this.multiAnswers.length // 加上判断题
        if (len !== this.examsLength) {
          this.$message.confirm('题目还未做完，确定提交？', '提交试卷')
            .then((val) => {
              if (val.result) {
                this.sendAnswer()
              }
            })
        } else {
          this.sendAnswer()
        }
      },
      sendAnswer() {
        this.convert()
        this.answers.isSubmit = 1
        let answers = this.answers
        this.$http({
          method: 'post',
          url: '/exam/AnswerQuestion',
          data: answers
        })
          .then((res) => {
            res = res.data
            if (res.error === 0) {
              this.$router.push({name: 'exam-tested'})
              this.setExamId(0) // 将用户正在考试中的试卷置为0
            } else {
              this.$toast.error(res.msg)
            }
            this.$message.alert('试卷提交成功', '考试完成')
          })
          .catch(() => {
          })
      },
      // 将用seq排序的答案转化并赋值给data的answers
      convert() {
        let temSinAnswers = []
        let temMulAnswers = []
        let temMulAnswersIndex = this.singleLength
        // let temJudAnswers = []

        if (this.singleAnswers.length) {
          this.singleAnswers.forEach((obj) => {
            let item = this.exams.single[Object.keys(obj)[0] - 1]
            let id = item.id
            let tempObj = {
              questionId: id,
              studentAnswer: obj[[Object.keys(obj)[0]]]
            }
            temSinAnswers.push(tempObj)
          })
        }

        if (this.multiAnswers.length) {
          this.multiAnswers.forEach((obj) => {
            let item = this.exams.multiple[Object.keys(obj)[0] - 1 - temMulAnswersIndex]
            let str = ''
            obj[Object.keys(obj)[0]].forEach((obj) => {
              str += obj
            })
            let id = item.id
            let tempObj = {
              questionId: id,
              studentAnswer: str
            }
            temMulAnswers.push(tempObj)
          })
        }
        let tempAnswers = temSinAnswers.concat(temMulAnswers)
        this.answers.answer = tempAnswers
      },
      goTo(index) {
        index--
        this._showList()
        this.currentIndex = index
        this.$refs.slide.goToPage(index, 0, 0)
      },
      // 返回考试列表
      back() {
        this.$router.push({name: 'exam'})
      },
      // 跳转上一页
      prev() {
        if (this.currentIndex === 1) {
          return
        } else {
          this.currentIndex--
        }
        this.$refs.slide.prev()
      },
      // 跳转下一页
      next() {
        if (this.currentIndex === this.examsLength) {
          this._showList()
        } else {
          this.currentIndex++
        }
        this.$refs.slide.next()
      },
      // 索引跟踪
      indexChange(index) {
        if (this.currentIndex !== index) {
          this.currentIndex = index
        }
      },
      // 打开或关闭答题卡
      _showList() {
        this.showList = !this.showList
      },
      // 试题乱序
      shuffle(arr) {
        let len = arr.length
        for (var i = 0; i < len - 1; i++) {
          var idx = Math.floor(Math.random() * (len - i))
          var temp = arr[idx]
          arr[idx] = arr[len - i - 1]
          arr[len - i - 1] = temp
        }
        return arr
      },
      // 对试题进行乱序排序并加上序列号
      init() {
        this.shuffle(this.exams.single)
        this.shuffle(this.exams.multiple)
        // this.shuffle(this.exams.single) // 记得改为判断题
        this.exams.single.forEach((arr, index) => {
          arr.seq = index + 1
        })
        this.exams.multiple.forEach((arr, index) => {
          arr.seq = index + this.singleLength + 1
        })
        this.exams.judgement.forEach((arr, index) => {
          arr.seq = index + 1 + this.singleLength + this.multipleLength + 1
        })
      },
      // 设置定时器每5分钟保存一次答案
      timeSave() {
        this.answerTimer = window.setTimeout(() => {
          this.saveAnswer()
          window.setTimeout(this.timeSave(), 1000)
        }, 300000)
      },
      // 将答案存放在localStorage以便用户中途进试卷可以重新获取答案
      saveAnswer() {
        this.convert()
        if (this.answers.answer) {
          let answers = JSON.stringify(this.answers.answer)
          window.localStorage.answers = ''
          window.localStorage.answers = answers
        }
      }
    },
    // 在组件销毁前清除定时器
    beforeDestroy() {
      window.clearTimeout(this.countTimer)
      window.clearTimeout(this.answerTimer)
    },
    // 离开当前考试时路由守卫，确定用户是否确认离开
    beforeRouteLeave(to, from, next) {
      if (this.answers.isSubmit === 0) {
        this.$confirm('试卷还未提交，确认离开考试？', '正在考试中')
          .then((val) => {
            if (val.result) {
              this.saveAnswer()
              next()
            } else {
              next(false)
            }
          })
      } else {
        next()
      }
    },
    components: {
      Single,
      Multiple,
      ExamSlide,
      Loader
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin.styl"
  .onexam
    font-size: 0
    background: #FFFFFF
    .onexam-title
      position: absolute
      display: flex
      width: 100%
      height: 0.9rem
      z-index: 1000
      border-radius: 0.06rem
      font-size: 0
      background: #35a0ee
      .title-right
        position: relative
        flex: 1 0
        line-height: 0.9rem
        color: #fff
        .list-timer
          position: absolute
          height: 100%
          left: 0.36rem
          font-size: 0.35rem
          .list
            display: inline-block
            height: 100%
            width: 1rem
          .timer
            display: inline-block
            vertical-align: top
            font-size: 0.35rem
            .mu-icon
              display: inline-block
              padding-top: 0.15rem
            .time
              vertical-align: top
              padding-left: 0.1rem
      .mu-button-wrapper
        height: 100%
        width: 2.5rem
    .exam-slide
      position: absolute
      top: 0.9rem
      width: 100%
      height: 11.59rem
      background-color: white
    .onexam-bottom
      position: absolute
      bottom: 0
      left: 0
      height: 0.75rem
      width: 100%
      text-align: center
      color: #fff
      .button
        display: inline-block
        width: 50%
        .mu-ripple
          position: relative
          height: 100%
          width: 100%
          font-size: 0.4rem
    .submit
      position: fixed
      border-radius: 0.2rem
      width: 1.5rem
      height: 0.6rem
      line-height: 0.6rem
      text-align: center
      color #187fcd
      background-color: #28343a
      font-size: 0.4rem
      bottom: 1.8rem
      left: 3rem
    .exam-list
      position: absolute
      z-index: 100
      top: 0
      padding-top: 0.9rem
      width: 100%
      height: 100%
      box-sizing: border-box
      background: #fff
      .list-header
        position: relative
        height: 0.7rem
        border: 1px solid #ececec
        font-size: 0.28rem
        color: rgb(33, 150, 243)
        font-size: 0.28rem
        .header-name
          display: inline-block
          width: 5rem
          padding-left: 0.35rem
          line-height: 0.7rem
          overflow: hidden
        .header-num
          display: inline-block
          position: absolute
          right: 0.36rem
          line-height: 0.7rem
      .list-items
        width: 100%
        box-sizing: border-box
        padding: 0 0.2rem
        .elist
          margin-top: 0.2rem
          border-1px(rgba(7, 17, 27, 0.1))
          .top
            height: 0.3rem
            width: 100%
            line-height: 0.3rem
            span
              display: block
              height: 0.4rem
              width: 1rem
              text-align: center
              line-height: 0.4rem
              border-radius: 0.4rem
              font-size: 0.24rem
              color: #fff
              background: rgb(33, 150, 243)
          .item
            display: inline-block
            width: 0.51rem
            height: 0.51rem
            line-height: 0.51rem
            margin: 0.2rem 0.2rem 0.2rem 0
            border-radius: 50%
            border: 1px solid #9c9c9c
            font-size: 0.25rem
            color: #9c9c9c
            text-align: center
            &.active
              color: #fff
              background: rgb(33, 150, 243)
      .list-submit
        position: absolute
        bottom: 0
        left: 0
        width: 100%
        height: 0.7rem
        line-height: 0.7rem
        text-align: center
        font-size: 0.3rem
        color: #fff
        background: #ee2728

  .loader-container
    position: absolute
    width: 100%
    top: 50%
    transform: translateY(-50%)
</style>

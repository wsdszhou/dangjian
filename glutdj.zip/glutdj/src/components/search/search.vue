<template>
  <transition name="slide">
    <div class="page">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">搜索</span>
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {
        content: '' // 搜索内容
      }
    },
    methods: {
      back() {
        this.$router.back()
      },
      // 全局搜索新闻
      searchNews() {
        this.news = null
        this.newsLoaded = false
        this.loading = true
        this.exceedHeight = false
        this.page = 1 // 保证在当前页面首次加载为第一页
        this.$http.get('/news/column', {
          params: {
            page: this.page,
            limit: this.limit
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.news = res.data
            this.loading = false
            this.newsLoaded = true
          }
          if (this.news.length >= this.limit) {
            this.exceedHeight = true
          }
        }).catch(() => {
          this.loading = false
        })
      },
      search() {
        if (this.content !== '') {
          console.log(this.content)
        } else {
          this.$toast.error('内容不能为空')
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  .page
    position: fixed
    left: 0
    top: 0
    bottom: 48px
    z-index: 1000
    width: 100%
    height: 100%
    .common-title
      width: 100%
      height: 0.8rem
      line-height: 1
      z-index: 1000
      text-align: center
      border-radius: 0.06rem 0.06rem 0 0
      font-size: 0
      background: #ee2728
      .wrapper
        position: absolute
        top: 0rem
        left: 0.2rem
        overflow: hidden
        box-shadow: none
        height: 0.8rem
      .title
        display: block
        width: 100%
        padding: 0.24rem 0
        letter-spacing: 0.04rem
        color: #FFFFFF
        font-family: 'Microsoft YaHei'
        font-size: 0.32rem
    .page-content
      width: 100%
      .field
        width: 100%
        padding: 0 0.15rem
      .button
        padding: 0 0.15rem
      .mu-input
        padding-bottom: 0
        margin-bottom: 0

</style>

<template>
  <div class="tab-wrapper">
    <div class="line border-1px"></div>
    <div class="tab">
      <mu-container class="container">
        <mu-bottom-nav color="red" class="mu-bottom-nav" :value="bottomNav">
          <mu-bottom-nav-item title="首页" to="/home" icon="home" value="home"></mu-bottom-nav-item>
          <mu-bottom-nav-item title="最新消息" to="/newremind" icon="info" value="newremind"></mu-bottom-nav-item>
          <mu-bottom-nav-item title="个人中心" to="/mine" icon="person_pin" value="mine"></mu-bottom-nav-item>
        </mu-bottom-nav>
      </mu-container>
    </div>
  </div>
</template>
<!--<mu-bottom-nav-item title="视频专区" to="/video" icon="video_library" value="video"></mu-bottom-nav-item>-->
<script>
  export default {
    data() {
      return {
        bottomNav: 'home'
      }
    },
    created() {
      this.changeNav()
    },
    methods: {
      changeNav() {
        let path = this.$route.path.split('/')
        this.bottomNav = path[1]
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~common/stylus/mixin.styl"
  .tab-wrapper
    position: absolute
    left: 0
    bottom: 0
    z-index: 50
    width: 100%
    background: #fff
    .line
      border-1px(rgba(7, 17, 27, 0.1))
    .tab
      width: 100%
      height: 1rem
      line-height: 0.24rem
      .container
        height: 100%
        padding: 0
        .mu-bottom-nav
          height: 1rem
</style>

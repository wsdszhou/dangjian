<template>
  <transition name="slide">
    <div class="video">
      <common-title title="党员教育" :backPath="backPath" class="title"></common-title>
      <div class="divider"></div>
      <mu-container class="container">
        <mu-load-more @refresh="refresh"
                      :refreshing="refreshing"
                      :loading="loading"
                      :loaded-all="loaded"
                      @load="load">
          <mu-row gutter>
            <mu-col span="6" v-for="(item,index) in videoList" :key="index" @click="toPlay(item.spId,item.spSlt)">
              <div class="grid-cell">
                <img :src="url + item.spSlt" onerror="this.src='static/2.jpg'" class="img">
                <div class="name">{{item.spMc}}</div>
              </div>
            </mu-col>
          </mu-row>
        </mu-load-more>
      </mu-container>
      <videoplay v-if="showVideo"
                 class="videoplay"
                 :slt="slt"
                 :videoId="videoId" @back="toPlay"></videoplay>
    </div>
  </transition>
</template>
<script>
  import CommonTitle from 'base/common-title/common-title'
  import videoplay from './videoplay/videoplay'
  import {URL} from 'common/js/config'

  export default {
    data() {
      return {
        videoList: [],
        slt: '',
        showVideo: false,
        backPath: {name: 'home'},
        src: '',
        videoId: '',
        refreshing: false,
        loading: false,
        loaded: false,
        url: URL
      }
    },
    created() {
      this.getVideoList()
    },
    methods: {
      // 分页查询网络党校视频
      getVideoList(refresh) {
        this.$http.get('/video/videoPageList', {
          params: {
            page: 1,
            limit: 10
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.videoList = res.data
            if (refresh) {
              this.refreshing = false
            }
          }
        }).catch(() => {
          if (refresh) {
            this.refreshing = false
          }
        })
      },
      refresh() {
        this.refreshing = true
        this.getVideoList(1)
      },
      load() {
        this.loading = true
        setTimeout(() => {
          this.loading = false
          this.videoList += 10
        }, 2000)
        if (this.videoList > 30) {
          this.loaded = true
        }
      },
      toPlay(id, slt) {
        this.videoId = id
        this.slt = URL + slt
        this.showVideo = !this.showVideo
      }
    },
    components: {
      CommonTitle,
      videoplay
    }
  }
</script>

<style scoped lang="stylus">
  .video
    position: absolute
    width: 100%
    background-color: #f5f5f4
    .title
      position: fixed
    .divider
      position: relative
      width: 100%
      margin: auto
      padding-top: 0.8rem
    .container
      position: relative
      padding-top: 0.1rem
      .grid-cell
        margin-bottom: 0.2rem
        .name
          padding: 0.05rem 0 0.15rem 0
          border-radius: 0 0 5px 5px
          background-color: white
          font-size: 0.25rem
          color: #212121
          letter-spacing: 0
        .img
          width: 100%
          height: 2rem
          display: block
          border-radius: 5px 5px 0 0
    .videoplay
      position: fixed
      width: 100%
      z-index: 1000
      top: 0
      left: 0
</style>

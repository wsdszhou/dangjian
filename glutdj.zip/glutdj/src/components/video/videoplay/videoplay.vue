<template>
  <transition name="slide">
    <div class="videoplay">
      <div class="common-title">
        <mu-button fab small class="wrapper" @click="back" color="#ee2728">
          <mu-icon value="arrow_back" size="24"></mu-icon>
        </mu-button>
        <span class="title">视频播放</span>
      </div>
      <div class="container">
        <div class="player">
          <video-player class="video-player vjs-custom-skin"
                        v-if="videoUrl"
                        ref="videoPlayer"
                        :playsinline="true"
                        :options="playerOptions"
                        @play="onPlayerPlay($event)"
                        @pause="onPlayerPause($event)"
          >
          </video-player>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  import CommonTitle from 'base/common-title/common-title'
  import {URL} from 'common/js/config'
  import {videoPlayer} from 'vue-video-player'
  import 'video.js/dist/video-js.css'

  export default {
    data() {
      return {
        videoUrl: '',
        playerOptions: {
//        playbackRates: [0.7, 1.0, 1.5, 2.0], //播放速度
          autoplay: false, // 如果true,浏览器准备好时开始回放。
          muted: false, // 默认情况下将会消除任何音频。
          loop: false, // 导致视频一结束就重新开始。
          preload: 'auto', // 建议浏览器在<video>加载元素后是否应该开始下载视频数据。auto浏览器选择最佳行为,立即开始加载视频（如果浏览器支持）
          language: 'zh-CN',
          aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
          fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
          sources: [{
            type: 'video/mp4',
            src: '' // 你的m3u8地址（必填）
          }],
          poster: '', // 你的封面地址
          width: document.documentElement.clientWidth,
          notSupportedMessage: '此视频暂无法播放，请稍后再试', // 允许覆盖Video.js无法播放媒体源时显示的默认信息。
          controlBar: {
            timeDivider: true,
            durationDisplay: true,
            remainingTimeDisplay: false,
            fullscreenToggle: true // 全屏按钮
          }
        }
      }
    },
    props: ['videoId', 'slt'],
    components: {
      videoPlayer,
      CommonTitle
    },
    created() {
      this.playerOptions.poster = this.slt
      this.getSingleVideo()
    },
    methods: {
      // 查询网络党校视频
      getSingleVideo() {
        let id = this.videoId
        this.$http.get('/video/getSingleVideo', {
          params: {
            videoId: id
          }
        }).then((res) => {
          res = res.data
          if (res.error === 0) {
            this.videoUrl = res.data.spLj
            let url = this.videoUrl
            url = url.replace(/\\/g, '/')
            url = url.replace(/\/\//g, '/')
            this.playerOptions.sources[0].src = URL + url
          }
        }).catch()
      },
      back() {
        this.$emit('back')
      },
      onPlayerPlay(e) {
        console.log('Play')
      },
      onPlayerPause(e) {
        console.log('Pause')
      }
    },
    computed: {
      player() {
        return this.$refs.videoPlayer.player
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus" scoped>
  .videoplay
    position: relative
    width: 100%
    height: 100%
    background-color: #f5f5f4
    .common-title
      width: 100%
      height: 0.8rem
      line-height: 1
      z-index: 1000
      text-align: center
      border-radius: 0.06rem 0.06rem 0 0
      font-size: 0
      background: #ee2728
      .wrapper
        position: absolute
        top: 0rem
        left: 0.2rem
        overflow: hidden
        box-shadow: none
        height: 0.8rem
      .title
        display: block
        width: 100%
        padding: 0.24rem 0
        letter-spacing: 0.04rem
        color: #FFFFFF
        font-family: 'Microsoft YaHei'
        font-size: 0.32rem

  .container
    position: absolute
    padding-top: 0.15rem
    background-color: #efefef

  .vjs-big-play-button
    position: absolute
    left: 50%
    top: 50%

  .video-player
    button
      top: 1rem
      left: 1rem
</style>

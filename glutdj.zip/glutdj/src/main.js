import Vue from 'vue'
import App from './App'
import fastclick from 'fastclick'
import router from './router'
import store from './store'
import './common/stylus/index.styl'
import axios from 'axios'
import Helpers from 'muse-ui/lib/Helpers'
import VueLazyLoad from 'vue-lazyload'

import MuseUI from 'muse-ui'
import 'muse-ui/dist/muse-ui.css'
import './common/material-icons/material-icons.css'
import 'muse-ui-message/dist/muse-ui-message.css'
import 'muse-ui-progress/dist/muse-ui-progress.css'
import 'muse-ui-loading/dist/muse-ui-loading.css'
import Toast from 'muse-ui-toast'
import Message from 'muse-ui-message'
import NProgress from 'muse-ui-progress'
import Loading from 'muse-ui-loading'

Vue.use(Loading)
Vue.use(NProgress, {
  zIndex: 2000, // progress z-index
  top: 0, // position fixed top
  speed: 300, // progress speed
  color: '#00e5ff', // color
  size: 2, // progress size
  className: '' // progress custom class
})
Vue.use(Message)
Vue.use(Toast, {
  position: 'top', // 弹出的位置
  time: 2000, // 显示的时长
  closeIcon: 'close', // 关闭的图标
  close: true, // 是否显示关闭按钮
  successIcon: 'check_circle', // 成功信息图标
  infoIcon: 'info', // 信息信息图标
  warningIcon: 'priority_high', // 提醒信息图标
  errorIcon: 'warning' // 错误信息图标
})

Vue.use(MuseUI)
Vue.use(Helpers)

fastclick.attach(document.body)
Vue.config.productionTip = false
Vue.prototype.$http = axios
axios.defaults.withCredentials = true
axios.defaults.baseURL = 'http://111.231.76.233:8080/dangjian-controller/mobile'
// axios.defaults.baseURL = 'http://192.168.0.102:8080/dangjian-controller/mobile'
// axios.defaults.baseURL = 'http://localhost:8090/dangjian-controller/mobile'

axios.interceptors.request.use(function (config) {
  NProgress.start()
  // Do something before request is sent
  return config
}, function (error) {
  NProgress.done()
  // Do something with request error
  return Promise.reject(error)
})

// Add a response interceptor
axios.interceptors.response.use(function (response) {
  NProgress.done()
  // Do something with response data
  return response
}, function (error) {
  NProgress.done()
  // Do something with response error
  return Promise.reject(error)
})

Vue.use(VueLazyLoad, {
  loading: require('common/image/loading.gif'),
  lazyComponent: true
})

// 定义全局确认跳转至登录页面，用户未登录，让用户确认是否跳转到登录页面
Vue.prototype.$login = function () {
  Vue.prototype.$confirm('是否跳转到登录页面', '请先登录哦')
    .then((val) => {
      if (val.result) {
        this.$router.push({name: 'login'})
      }
    })
}

Vue.config.productionTip = false

// 简单的浏览器历史管理
const history = window.sessionStorage
history.clear()
let historyCount = history.getItem('count') * 1 || 0
history.setItem('/home', 0)
router.beforeEach((to, from, next) => {
  // 判断当前切换是forward还是后退reverse
  const toIndex = history.getItem(to.path)
  const fromIndex = history.getItem(from.path)
  // 出发页
  if (toIndex) {
    // 再次访问目标页toIndex
    if (toIndex > fromIndex || !fromIndex || (toIndex === '0' && fromIndex === '0')) {
      store.commit('SET_DIRECTION', 'forward')
    } else {
      store.commit('SET_DIRECTION', 'reverse')
    }
  } else {
    // 第一次访问目标页toIndex
    ++historyCount
    history.setItem('count', historyCount)
    to.path !== '/home' && history.setItem(to.path, historyCount)
    store.commit('SET_DIRECTION', 'forward')
  }
  // 限制未登录用户只能进入三个页面
  let toPath = to.path
  if (toPath !== '/' && toPath !== '/home' && toPath !== '/mine' && toPath !== '/mine/login') {
    if (window.localStorage.token !== 'logged') {
      Vue.prototype.$confirm('检测到您未登录，是否跳转到登录页面', '请先登录哦')
        .then((val) => {
          if (val.result) {
            next({path: '/mine/login'})
          }
        })
    } else {
      next()
    }
  } else {
    next()
  }
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})

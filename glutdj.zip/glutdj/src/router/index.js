import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  linkActiveClass: 'active',
  base: '/dangjian',
  routes: [
    {
      path: '/',
      component: () => import('components/index/index'),
      children: [
        {
          path: '/',
          redirect: '/home'
        },
        {
          path: '/home',
          name: 'home',
          component: () => import('components/home/home')
        },
        {
          path: '/newremind',
          name: 'newremind',
          component: () => import('components/newremind/newremind')
        },
        {
          path: '/mine',
          name: 'mine',
          component: () => import('components/mine/mine')
        }
      ]
    },
    {
      path: '/exam',
      component: () => import('components/exam/exam'),
      children: [
        {
          path: '/exam',
          name: 'exam',
          redirect: '/exam/index'
        },
        {
          path: '/exam/index',
          component: () => import('components/exam/index/index'),
          meta: {noKeepAlive: true}
        },
        {
          path: '/exam/testing',
          name: 'exam-testing',
          component: () => import('components/exam/testing/testing'),
          meta: {noKeepAlive: true}
        },
        {
          path: '/exam/tested',
          name: 'exam-tested',
          component: () => import('components/exam/tested/tested'),
          meta: {noKeepAlive: true}
        }
      ]
    },
    {
      path: '/onexam/:id',
      component: () => import('components/onexam/onexam'),
      meta: {noKeepAlive: true}
    },
    {
      path: '/dyjy',
      name: 'dyjy',
      component: () => import('components/video/video'),
      meta: {noKeepAlive: true}
    },
    {
      path: '/mine/info',
      component: () => import('components/mine/info/info')
    },
    {
      path: '/mine/modifier',
      component: () => import('components/mine/modifier/modifier')
    },
    {
      path: '/mine/branch',
      component: () => import('components/mine/branch/branch')
    },
    {
      path: '/mine/branchuser',
      component: () => import('components/mine/branchuser/branchuser')
    },
    {
      path: '/mine/dep',
      component: () => import('components/mine/dep/dep')
    },
    {
      path: '/mine/party',
      component: () => import('components/mine/party/party')
    },
    {
      path: '/mine/upload',
      component: () => import('components/mine/upload/upload')
    },
    {
      path: '/mine/login',
      name: 'login',
      component: () => import('components/mine/login/login'),
      meta: {noKeepAlive: true}
    },
    {
      path: '/new-detail/:newsid',
      name: 'newDetail',
      component: () => import('components/new-detail/new-detail'),
      meta: {noKeepAlive: true}
    },
    {
      path: '/detail/:id',
      name: 'detail',
      component: () => import('base/detail/detail'),
      meta: {noKeepAlive: true}
    },
    {
      path: '/djmh',
      component: () => import('components/djmh/djmh'),
      redirect: '/djmh/5',
      name: 'djmh',
      meta: {noKeepAlive: true},
      children: [
        {
          path: ':id',
          component: () => import('components/djmh/item/item'),
          meta: {noKeepAlive: true}
        }
      ]
    },
    {
      path: '/dygz',
      component: () => import('components/dygz/dygz'),
      redirect: '/dygz/getPartyNoticePageList',
      meta: {noKeepAlive: true},
      children: [
        {
          path: '/dygz/getPartyNoticePageList',
          component: () => import('components/dygz/dwsp/dwsp'),
          meta: {noKeepAlive: true}
        },
        {
          path: '/dygz/getNewsNoticePageList',
          component: () => import('components/dygz/xwsp/xwsp'),
          meta: {noKeepAlive: true}
        },
        {
          path: '/dygz/getNewsCommentNoticePageList',
          component: () => import('components/dygz/plsp/plsp'),
          meta: {noKeepAlive: true}
        }
      ]
    }
  ]
})

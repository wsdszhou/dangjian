import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    token: false,
    direction: 'forward',
    allMessage: 0,
    allspMessage: 0,
    avatar: '',
    examId: 0,
    username: ''
  },
  getters: {
    token(state) {
      return state.token
    },
    direction(state) {
      return state.direction
    },
    allMessage(state) {
      return state.allMessage
    },
    allspMessage(state) {
      return state.allspMessage
    },
    avatar(state) {
      return state.avatar
    },
    username(state) {
      return state.username
    },
    examId(state) {
      return state.examId
    }
  },
  mutations: {
    // 设置路由跳转时页面切换方向
    SET_DIRECTION: (state, val) => {
      state.direction = val
    },
    // 设置用户头像
    SET_AVATAR: (state, val) => {
      state.avatar = val
    },
    // 设置提醒总数
    SET_ALLMESSAGE: (state, val) => {
      state.allMessage = val
    },
    // 设置审批总数
    SET_ALLSPMESSAGE: (state, val) => {
      state.allspMessage = val
    },
    // 减少审批总数
    DECREASE_ALLSPMESSAGE: (state) => {
      state.allspMessage--
    },
    // 设置登录状态为已登陆
    SET_TOKEN: (state) => {
      state.token = true
    },
    // 设置登录状态为未登陆
    DELETE_TOKEN: (state) => {
      state.token = false
    },
    // 设置用户名
    SET_USERNAME: (state, val) => {
      state.username = val
    },
    // 用户登录状态失效删除用户名
    DELETE_USERNAME: (state) => {
      state.username = ''
    },
    // 设置试题ID
    SET_EXAMID: (state, val) => {
      state.examId = val
    }
  },
  actions: {
    SET_AVATAR({commit}, val) {
      commit('SET_AVATAR', val)
    },
    SET_ALLMESSAGE({commit}, val) {
      commit('SET_ALLMESSAGE', val)
    },
    SET_ALLSPMESSAGE({commit}, val) {
      commit('SET_ALLSPMESSAGE', val)
    },
    DECREASE_ALLSPMESSAGE({commit}) {
      commit('DECREASE_ALLSPMESSAGE')
    },
    SET_TOKEN({commit}) {
      commit('SET_TOKEN')
    },
    DELETE_TOKEN({commit}) {
      commit('DELETE_TOKEN')
    },
    SET_USERNAME({commit}, val) {
      commit('SET_USERNAME', val)
    },
    DELETE_USERNAME({commit}) {
      commit('DELETE_USERNAME')
    },
    SET_EXAMID({commit}, val) {
      commit('SET_EXAMID', val)
    }
  }
})

export default store
